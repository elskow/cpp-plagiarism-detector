#include <iostream>
#include <fstream>
#include <iomanip>
#include <ctime>

using namespace std;

// Struct untuk data pemesanan
struct Pemesanan {
    string nama;
    string namaKamar;
    int hargaKamar;
    int durasiInap;
    int jumlahOrang;
    int maksimalOrang;
    int kamardipesan;
    int jumlahKamar;
    int ruangkamar;
};

// Prototipe fungsi
void tampilkanMenu();
void pesanHotel(Pemesanan* pesanan);
void tampilkanPemesanan(const Pemesanan& pesanan);
void simpanPemesananKeFile(const Pemesanan& pesanan);
void bacaPemesananDariFile();

int main() {
    int pilihan;

    do {
        tampilkanMenu();
        cout << "Masukkan pilihan (1-3): ";
        cin >> pilihan;

        switch (pilihan) {
            case 1:
                pesanHotel(new Pemesanan);
                break;
            case 2:
                bacaPemesananDariFile();
                break;
            case 3:
                cout << "Terima kasih. Program selesai." << endl;
                break;
            default:
                cout << "Pilihan tidak valid. Silakan coba lagi." << endl;
        }

    } while (pilihan != 3);

    return 0;
}

void tampilkanMenu() {
 cout << "\033[1;36m===== Program Pemesanan Hotel Idaman =====\033[0m" << endl;    
    cout << "\033[1;33m1. Pesan Hotel\033[0m" << endl; 
    cout << "\033[1;33m2. Tampilkan Pemesanan dari File\033[0m" << endl; 
    cout << "\033[1;31m3. Keluar\033[0m" << endl; 
}

int Deluxe = 20;
int Suite = 20;
int Presidential = 10;

void pesanHotel(Pemesanan* pesanan) {
    cout << "Masukkan nama Anda: ";
    cin.ignore();  
    getline(cin, pesanan->nama);

    cout << "Pilih nama kamar (Deluxe/Suite/Presidential): ";
    getline(cin, pesanan->namaKamar);

    // Menetapkan harga kamar berdasarkan pilihan
    if (pesanan->namaKamar == "Deluxe") {
        pesanan->hargaKamar = 100;
        pesanan->maksimalOrang = 2;
        pesanan->jumlahKamar = Deluxe;

    } else if (pesanan->namaKamar == "Suite") {
        pesanan->hargaKamar = 150;
        pesanan->maksimalOrang = 2;
        pesanan->jumlahKamar = Suite;
    } else if (pesanan->namaKamar == "Presidential") {
        pesanan->hargaKamar = 200;
        pesanan->maksimalOrang = 4;
        pesanan->jumlahKamar = Presidential;
    } else {
        cout << "Nama kamar tidak valid. pesanan tidak diterima" << endl; 
        delete pesanan;
        return;
    }

    //pengecekan jumlah kamar 

     if (pesanan->jumlahKamar == 0) {
        cout << "Maaf, unit " << pesanan->namaKamar << " penuh. Silakan pilih jenis kamar lain atau coba lagi nanti." << endl;
        delete pesanan;
        return;
     }
    cout << "Masukkan durasi inap (hari): ";
    cin >> pesanan->durasiInap;

        //jumlah orang yang akan menginap
        cout << "Masukkan Jumlah Orang Yang akan menginap pada kamar " << pesanan->namaKamar << ", maksimal orang menginap sebanyak " << pesanan->maksimalOrang<< " orang " << endl;
        cin >> pesanan->jumlahOrang;

        //pengecekan apabila jumlah orang sesuai dengan limit perkamar
        if (pesanan->jumlahOrang >= 1 && pesanan->jumlahOrang <= pesanan->maksimalOrang){
        }

        else {
            cout << "orang melebihi kapasitas kamar, Pesanan tidak diterima" << endl;
            delete pesanan;
            return;
        }
    
    cout << "Masukkan jumlah kamar " << pesanan->namaKamar << ", pada unit tersebut tersedia " << pesanan->jumlahKamar << " jumlah kamar unit tersedia" << endl;
    cin >> pesanan->kamardipesan;

    do {
    if (pesanan->kamardipesan >= 1 && pesanan->kamardipesan <= pesanan->jumlahKamar) {
        cout << "pesanan diterima, berikut data pemesanan anda" << endl;

         // Mengurangkan jumlah kamar yang tersedia
            if (pesanan->namaKamar == "Deluxe") {
                Deluxe -= pesanan->kamardipesan;
            } else if (pesanan->namaKamar == "Suite") {
                Suite -= pesanan->kamardipesan;
            } else if (pesanan->namaKamar == "Presidential") {
                Presidential -= pesanan->kamardipesan;
            }

    } else {
        cout << "pesanan anda tidak dapat diterima" << endl;

          // Tampilkan pesan jika unit kamar penuh
        if (pesanan->namaKamar == "Deluxe" && Deluxe == 0) {
            cout << "Maaf, unit Deluxe penuh. Silakan pilih jenis kamar lain atau coba lagi nanti." << endl;
        } else if (pesanan->namaKamar == "Suite" && Suite == 0) {
            cout << "Maaf, unit Suite penuh. Silakan pilih jenis kamar lain atau coba lagi nanti." << endl;
        } else if (pesanan->namaKamar == "Presidential" && Presidential == 0) {
            cout << "Maaf, unit Presidential penuh. Silakan pilih jenis kamar lain atau coba lagi nanti." << endl;
        } else {
            cout << "Silakan coba lagi." << endl;
        }

        // Meminta input untuk memesan kembali atau tidak
        char pesanKembali;
        cout << "Apakah Anda ingin memesan kembali? (y/n): ";
        cin >> pesanKembali;

        if (pesanKembali == 'y') {
            delete pesanan;
            pesanHotel(new Pemesanan);
        }

        else {
            delete pesanan;
            return;
        }
}
    }while (pesanan->kamardipesan < 1 || pesanan->kamardipesan > pesanan->jumlahKamar);
    // Tampilkan ringkasan pemesanan
    tampilkanPemesanan(*pesanan);

    // Simpan pemesanan ke file
    simpanPemesananKeFile(*pesanan);

    // Hapus memori yang dialokasikan untuk objek Pemesanan
    delete pesanan;
    cout << "Kembali ke menu utama dalam 3 detik..." << endl;
}

void tampilkanPemesanan(const Pemesanan& pesanan) {
    //fungsi untuk menghitung tgl check in check out
    time_t now = time(nullptr);
    tm checkInTime = *localtime(&now);
    tm checkOutTime = checkInTime;
    checkOutTime.tm_mday += pesanan.durasiInap;
    mktime(&checkOutTime);

    cout << "\n\033[1;32m===== Ringkasan Pemesanan =====\033[0m" << endl;
    cout << "\033[1mNama:\033[0m " << pesanan.nama << endl;
    cout << "\033[1mNama Kamar:\033[0m " << pesanan.namaKamar << endl;
    cout << "\033[1mHarga Kamar:\033[0m $" << fixed << setprecision(2) << pesanan.hargaKamar << endl;
    cout << "\033[1mDurasi Inap:\033[0m " << pesanan.durasiInap << " hari" << endl;
    cout << "\033[Tanggal Check-In:\033[0m " << put_time(&checkInTime, "%d-%m-%Y") << endl;
    cout << "\033[Tanggal Check-Out:\033[0m " << put_time(&checkOutTime, "%d-%m-%Y") << endl; 
    cout << "\033[1mJumlah Orang:\033[0m " << pesanan.jumlahOrang << " orang" << endl;
    cout << "\033[1mTotal Biaya:\033[0m $" << fixed << setprecision(2) << (pesanan.hargaKamar * pesanan.durasiInap * pesanan.kamardipesan) << endl;
    cout << "\033[1;32m===============================\033[0m" << endl; 
}

void simpanPemesananKeFile(const Pemesanan& pesanan) {
    ofstream file("pemesanan.txt", ios::app);
    if (file.is_open()) {

        // Menghitung tanggal check-out
        time_t now = time(nullptr);
        tm checkOutTime = *localtime(&now);
        checkOutTime.tm_mday += pesanan.durasiInap;
        mktime(&checkOutTime);

        file << "\n===== Pemesanan Baru =====" << endl;
        file << "Nama: " << pesanan.nama << endl;
        file << "Nama Kamar: " << pesanan.namaKamar << endl;
        file << "Jumlah Kamar: " << pesanan.jumlahKamar << endl;
        file << "Harga Kamar: $" << fixed << setprecision(2) << pesanan.hargaKamar << endl;
        file << "Durasi Inap: " << pesanan.durasiInap << " hari" << endl;
        file << "Tanggal Check-In: " << put_time(&checkOutTime, "%d-%m-%Y") << endl;
        file << "Tanggal Check-Out: " << put_time(&checkOutTime, "%d-%m-%Y") << endl; 
        file << "Jumlah Orang: " << pesanan.jumlahOrang << " orang" << endl;
        file << "Total Biaya: $" << fixed << setprecision(2) << (pesanan.hargaKamar * pesanan.durasiInap * pesanan.kamardipesan) << endl;
        file << "===============================" << endl;
        file.close();
        cout << "Pemesanan berhasil disimpan ke file." << endl;
    } else {
        cout << "Gagal membuka file untuk penyimpanan." << endl;
    }
}

void bacaPemesananDariFile() {
    ifstream file("pemesanan.txt");
    if (file.is_open()) {
        string line;
        cout << "\n===== Daftar Pemesanan =====" << endl;
        while (getline(file, line)) {
            cout << line << endl;
        }
        cout << "=============================" << endl;
        file.close();
    } else {
        cout << "Belum ada pemesanan yang tersimpan." << endl;
    }
}