#include <iostream>
#include <string>
#include <windows.h> // Supaya Sleep() berjalan
#include <fstream>
#include <conio.h> // Suapaya _getch() berjalan


using namespace std;

// Struktur untuk mempresentasikan buku
struct Book {
    string title;
    string author;
    int publication;
    bool available;  // Status ketersediaan buku
};

// Array untuk mempresentasikan buku-buku dan memanfaatkan pointer untuk memori yang dinamis
const int MAX_BOOKS = 100;
Book* library[MAX_BOOKS];
int totalBooks = 0;


// Fungsi untuk menambahkan buku baru
void addBook() {
    if (totalBooks < MAX_BOOKS) {
        library[totalBooks] = new Book(); // Menggunakan alokasi memori dinamis untuk buku
        cout << "Masukkan judul buku: ";
        cin.ignore();
        getline(cin, library[totalBooks]->title);

        cout << "Masukkan nama pengarang: ";
        getline(cin, library[totalBooks]->author);

        cout << "Masukkan tahun terbit: ";
        cin >> library[totalBooks]->publication;
        if (cin, library[totalBooks]->publication <= 0) {
            cout << "Tahun terbit tidak jelas. Mohon ulangi lagi dengan benar." << endl;
            cin.clear();
            cin.ignore(9999999, '\n');
            return;
        }

        library[totalBooks]->available = true;  // Buku baru tersedia
        totalBooks++;

        cout << "Buku berhasil ditambahkan!" << endl;
    } else {
        cout << "Maaf, perpustakaan sudah penuh." << endl;
    }
}

// Fungsi untuk mencari buku berdasarkan judul atau pengarang
void searchBook() {
    string searchTerm;
    cout << "Masukkan judul atau pengarang buku: ";
    cin.ignore();
    getline(cin, searchTerm);

    cout << "Hasil Pencarian:" << endl;
    Sleep(250);
    for (int i = 0; i < totalBooks; i++) {
        if (library[i]->title.find(searchTerm) != string::npos || library[i]->author.find(searchTerm) != string::npos) { // apakah substring(karakter) di inputan sesuai atau tidak 
            cout << "Judul: " << library[i]->title << ", Pengarang: " << library[i]->author << ", Tahun terbit: " << library[i]->publication;
            if (library[i]->available) {
                cout << " (Tersedia)" << endl;
            } else {
                cout << " (Buku sedang dipinjam)" << endl;
            }
            Sleep(250);
        } else {
            cout << "Buku tidak ditemukan!" << endl;
        }
    }
}

// Fungsi untuk menampilkan daftar buku yang tersedia
void displayAvailableBooks() {
    if (totalBooks == 0) {
        cout << "Tidak ada buku dalam perpustakaan." << endl;
        return;
    } else {
        cout << "Daftar Buku :" << endl;
        Sleep(500);
        for (int i = 0; i < totalBooks; i++) {
            cout << "Judul: " << library[i]->title << ", Pengarang: " << library[i]->author << ", Tahun terbit: " << library[i]->publication;
            if (library[i]->available) {
                cout << " (Tersedia)" << endl;
            } else {
                cout << " (Buku sedang dipinjam)" << endl;
            }
            Sleep(100);
        }
    }
}

// Fungsi untuk meminjam buku
void borrowBook() {
    string searchInput;
    cout << "Masukkan judul atau nama pengarang buku yang ingin dipinjam: ";
    cin.ignore();
    getline(cin, searchInput);

    // Menampilkan daftar buku yang sesuai dengan inputan
    cout << "Daftar Buku yang Sesuai dengan Pencarian:" << endl;
    int matchingBooks = 0;
    for (int i = 0; i < totalBooks; i++) {
        if (library[i]->title.find(searchInput) != string::npos || library[i]->author.find(searchInput) != string::npos) {
            cout << matchingBooks + 1 << ". Judul: " << library[i]->title << ", Pengarang: " << library[i]->author << ", Tahun terbit: " << library[i]->publication;
            matchingBooks++;
            
            if (library[i]->available) {
            cout << " (Tersedia)" << endl;
            } else {
                cout << " (Buku sedang dipinjam)" << endl;
            }
            Sleep(250);
        }
    }

    if (matchingBooks == 0) {
        cout << "Buku tidak ditemukan!" << endl;
        return;
    }

    // Memilih buku yang ingin dipinjam
    int selection;
    cout << "Masukkan nomor buku yang ingin dipinjam (1-" << matchingBooks << "): ";
    cin >> selection;

    if (selection < 1 || selection > matchingBooks) {
        cout << "Pilihan tidak valid." << endl;
        cin.clear();
        cin.ignore(9999999, '\n');
        return;
    }

    // Meminjam buku
    int selectedBookIndex = -1;
    for (int i = 0; i < totalBooks; i++) {
        if (library[i]->title.find(searchInput) != string::npos || library[i]->author.find(searchInput) != string::npos) {
            selection--;
            if (selection == 0) {
                selectedBookIndex = i; // Menyimpan index buku untuk dipinjam
                break;
            }
        }
    }

    if (selectedBookIndex != -1) {
        if (library[selectedBookIndex]->available) {
            // Mark buku sebagai tidak tersedia
            library[selectedBookIndex]->available = false;
            cout << "Buku berhasil dipinjam. Tenggat pengembalian paling lambat ialah seminggu." << endl;
        } else {
            cout << "Buku tidak tersedia untuk dipinjam saat ini." << endl;
        }
    }
}

// Fungsi untuk mengembalikan buku
void returnBook() {
    string searchToReturn;
    cout << "Masukkan judul atau nama pengarang buku yang ingin dikembalikan: ";
    cin.ignore();
    getline(cin, searchToReturn);
    
    cout << "Daftar buku yang sesuai dengan pencarian:" << endl;
    bool bookFound = false;
    int matchingBooks = 0;
    for (int i = 0; i < totalBooks; i++) {
        if (library[i]->title.find(searchToReturn) != string::npos || library[i]->author.find(searchToReturn) != string::npos) {
            if (!library[i]->available) {
                cout << matchingBooks + 1 << ". Judul: " << library[i]->title << ", Pengarang: " << library[i]->author << ", Tahun terbit: " << library[i]->publication << endl;
                matchingBooks++;
                Sleep(250);
            }
        }
    }

    if (matchingBooks == 0) {
    cout << "Buku tidak ditemukan!" << endl;
    return;
    }

    int selection;
    cout << "Masukkan nomor buku yang ingin dikembalikan (1-" << matchingBooks << "): ";
    cin >> selection;

    if (selection < 1 || selection > matchingBooks) {
        cout << "Pilihan tidak valid." << endl;
        cin.clear();
        cin.ignore(9999999, '\n');
        return;
    }

    int selectedBookIndex = -1;
    for (int i = 0; i < totalBooks; i++) {
        if (library[i]->title.find(searchToReturn) != string::npos || library[i]->author.find(searchToReturn) != string::npos) {
            selection--;
            if (selection == 0) {
                selectedBookIndex = i;
                break;
            }
        }
    }

    if (selectedBookIndex != -1) {
        if (!library[selectedBookIndex]->available) {
            // Mark buku sebagai tersedia
            library[selectedBookIndex]->available = true;
            cout << "Buku berhasil dikembalikan!" << endl;
            bookFound = true;
        }
    }

    if (!bookFound) {
        cout << "Buku tidak ditemukan atau buku tersebut tidak sedang dipinjam." << endl;
    }
}

// Fungsi untuk menghapus buku
void removeBook() {
    string searchToRemove;
    cout << "Masukkan judul atau nama pengarang buku yang ingin dihapus: ";
    cin.ignore();
    getline(cin, searchToRemove);

    cout << "Daftar Buku yang Sesuai dengan Pencarian:" << endl;
    int matchingBooks = 0;

    for (int i = 0; i < totalBooks; i++) {
        if (library[i]->title.find(searchToRemove) != string::npos || library[i]->author.find(searchToRemove) != string::npos) {
            if (library[i]->available) {
                cout << matchingBooks + 1 << ". Judul: " << library[i]->title << ", Pengarang: " << library[i]->author << ", Tahun terbit : " << library[i]->publication << endl;
                matchingBooks++;
                Sleep(250);
            }
        }
    }

    if (matchingBooks == 0) {
        cout << "Buku tidak ditemukan!" << endl;
        return;
    }

    int selection;
    cout << "Masukkan nomor buku yang ingin dihapus (1-" << matchingBooks << "): ";
    cin >> selection;

    if (selection < 1 || selection > matchingBooks) {
        cout << "Pilihan tidak valid." << endl;
        cin.clear();
        cin.ignore(9999999, '\n');
        return;
    }

    int selectedBookIndex = -1;
    for (int i = 0; i < totalBooks; i++) {
        if (library[i]->title.find(searchToRemove) != string::npos || library[i]->author.find(searchToRemove) != string::npos) {
            selection--;
            if (selection == 0) {
                selectedBookIndex = i;
                break;
            }
        }
    }

    if (selectedBookIndex != -1) {
        // Menggeser buku-buku lain untuk mengisi kekosongan
        for (int i = selectedBookIndex; i < totalBooks - 1; i++) {
            library[i] = library[i + 1];
        }

        totalBooks--;
        cout << "Buku berhasil dihapus." << endl;
    }
}

// Fungsi untuk mencetak daftar buku ke dalam file riwayatDaftarBuku.txt
void printHistory(ostream& os) {
    if (totalBooks == 0) {
        os << "Tidak ada buku dalam perpustakaan." << endl;
        return;
    } else {
        os << "Daftar Buku:" << endl;
        for (int i = 0; i < totalBooks; i++) {
            os << "Judul: " << library[i]->title << ", Pengarang: " << library[i]->author << ", Tahun terbit: " << library[i]->publication;
            if (library[i]->available) {
                os << " (Tersedia)" << endl;
            } else {
                os << " (Buku sedang dipinjam)" << endl;
            }
        }
    }
}

// Fungsi untuk membebaskan memori dari buku agar memori aman dan lancar
void deleteBooks() {
    for (int i = 0; i < totalBooks; ++i) {
        delete library[i];
    }
}


int main() {

string unlock = "perpus123";

    while (true) {
        cout << "Masukkan password: ";

        // Menggunakan _getch() untuk menyembunyikan input kecuali enter
        char karakter;
        string password = "";
        while ((karakter = _getch()) != '\r') { 
            if (karakter == '\b') {
                // Mencegah backspace berlebih
                if (!password.empty()) {
                    cout << "\b \b";
                    password.pop_back();
                }
            } else {
                cout << '*'; // Mengganti nya dengan karakter itu
                password += karakter;
            }
        }

        if (password == unlock) {
            break;
        } else {
            cout << "\nPassword salah. Silakan coba lagi." << endl;
        }
    }

    int choice;

    do {
        cout << "\n===== Perpustakaan =====" << endl;
        Sleep(150); // Memberikan waktu delay dalam eksekusinya
        cout << "1. Tambah Buku" << endl;
        Sleep(150);
        cout << "2. Cari Buku" << endl;
        Sleep(150);
        cout << "3. Tampilkan Daftar Buku" << endl;
        Sleep(150);
        cout << "4. Pinjam Buku" << endl;
        Sleep(150);
        cout << "5. Pengembalian Buku" << endl;
        Sleep(150);
        cout << "6. Hapus Buku" << endl;
        Sleep(150);
        cout << "7. Cetak Riwayat" << endl;
        Sleep(150);
        cout << "8. Keluar" << endl;
        Sleep(150);
        cout << "Pilihan Anda: ";
        Sleep(150);
        cin >> choice;

        switch (choice) {
            case 1:
                addBook();
                break;
            case 2:
                searchBook();
                break;
            case 3:
                displayAvailableBooks();
                break;
            case 4:
                borrowBook();
                break;
            case 5:
                returnBook();
                break;
            case 6:
                removeBook();
                break;
            case 7:
                {
                    ofstream outputFile("riwayatDaftarBuku.txt");
                    if (outputFile.is_open()) {
                        printHistory(outputFile);
                        outputFile.close();
                        cout << "Riwayat daftar buku berhasil dicetak ke dalam file riwayatDaftarBuku.txt" << endl;
                    } else {
                        cout << "Gagal membuka file!" << endl;
                    }
                }
                break;
            case 8:
                cout << "Terima kasih!" << endl;
                break;
            default:
                cout << "Pilihan tidak valid. Silakan coba lagi." << endl;
                cin.clear(); // Mengembalikan status cin ke normal
                cin.ignore(9999999, '\n'); // Membersihkan buffer masukan.
                break;
        }
      } while (choice != 8);

    deleteBooks();

    return 0;
}