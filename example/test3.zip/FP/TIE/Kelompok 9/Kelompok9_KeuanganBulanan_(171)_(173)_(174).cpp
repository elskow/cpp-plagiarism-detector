#include <iostream>
#include <fstream>
using namespace std;

double total, danadarurat, bukuTabungan, jumlah, sum=0;

struct thing {
    string namaBarang;
    double hargaBarang;
};

int fungsidanadarurat(int total);
double rencana();
void bacaWish();
void inputWishlist(thing wishlist[], int i, int N);
double tabungan();
void bacaTab(int &hitung);
double jumlahPengeluaran();
void inputPengeluaran(thing pengeluaran[], int i, int N);
void bacaBiaya();
void info(double *cash);

int main(){
    cout<<"=================================="<<endl; 
    cout<<"   MANAJEMEN KEUANGAN MAHASISWA   "<<endl;
    cout<<"=================================="<<endl;
    cout<<"Masukkan uang bulanan anda : Rp ";
    cin>>total;

    fungsidanadarurat(total);

    total*=0.8;
    cout <<"Total sisa uang anda = Rp "<<total<<endl<<endl;

    char choose;
    do{
        cout << "Pilihan penggunaan : \n";
        cout << "a. Catatan pengeluaran\n";
        cout << "b. Tabungan\n";
        cout << "c. Wishlist\n";
        cout << "d. Info\n";
        cout << "e. Exit\n";
        cout << "Masukkan pilihan (a/b/c/d/e) : ";
        cin >> choose;
        switch(choose) {
         case 'a' :
         cout<<"Wooosshhh\n";
         jumlahPengeluaran();
         break;

         case 'b' :
         cout<<"Wooosshhh\n";
         tabungan();
         break;

         case 'c' :
         cout<<"Wooosshhh\n";
         rencana();
         break;

         case 'd' :
         cout<<"Wooosshhh\n";
         info(&total);
         break;

         case 'e' :
         cout << "Anda keluar dari program\n";
         cout << "==TERIMAKASIH==";
         break;

         default :
         cout << "Tidak ada pilihan tersebut\n" << '\n';
        }
    } while (choose !='e');

    return 0;
}
int fungsidanadarurat(int total){
    danadarurat=total*0.2;
    cout<<"Sebagian uang anda telah disimpan sebagai dana darurat"<<endl;
    cout<<"(Dana darurat digunakan apabila terjadi biaya di luar dugaan)"<<endl;
    cout<<"Tersimpan sebanyak : Rp "<<danadarurat<<endl;
    cout<<endl;
    return 0;
}

double rencana() {
    int N;
    ofstream buka1("wishlist.txt", ios::app);
    sum = 0;
    bacaWish();
    cout << "Berapa banyak jumlah barang yang ingin anda tambahkan : ";
    cin >> N;
    thing wishlist[N];
    inputWishlist(wishlist, 0, N);
        for(int i = 0; i < N; i++) {
        buka1 << wishlist[i].namaBarang << " : Rp " << wishlist[i].hargaBarang << '\n';}
    buka1.close();
    cout << "Jadi total harga barang anda : Rp " << sum << "\n\n";
    return sum;
}
void bacaWish() {
    ifstream bacaList("wishlist.txt");
    if (!bacaList.fail()) {
        string baris;
        cout << "List barang sebelumnya :\n";
        while (getline(bacaList, baris)) {
            cout << baris << endl;
            size_t p = baris.rfind("p");
            if (p != string::npos) {
                string hargaWish = baris.substr(p + 2);
                sum += stod(hargaWish);
            }
        }
        bacaList.close();
    } else {
        cout << "File tidak dapat dibuka" << endl;
    }
}
double tabungan() {
    int hari;
    int counter;
    int hitung = 1;
    ofstream buka2("tabungan.txt", ios::app);
    bukuTabungan = 0;
    bacaTab(hitung);
        cout << "Masukkan jumlah tabungan anda pada hari ini " << ": ";
        cin >> counter;
        bukuTabungan += counter;
        buka2 << "Hari ke " << hitung << " : Rp " << counter << '\n';
    buka2.close(); 
    cout << "Jumlah tabungan anda dalam satu bulan : Rp " << bukuTabungan << "\n\n";
    return bukuTabungan;

} 
void bacaTab(int &hitung) {
        ifstream bacaTabu("tabungan.txt");
        if (!bacaTabu.fail()) {
            string baris;
            while (getline(bacaTabu, baris)) {
                size_t p = baris.rfind("p");
                if (p != string::npos) {
                    string tabunganStr = baris.substr(p + 2);
                    bukuTabungan += stod(tabunganStr);
                    hitung++;
                }
            }

            bacaTabu.close();
        }
        else {
        cout << "File tidak dapat dibuka" << endl;
    }
    }
    
double jumlahPengeluaran() {
    int N;
    ofstream buka1("catatan_pengeluaran.txt", ios::app);
    jumlah = 0;
    bacaBiaya();
    cout << "Berapa banyak pengeluaran yang ingin anda tambahkan : ";
    cin >> N;
    thing pengeluaran[N];
    inputPengeluaran(pengeluaran, 0, N);
    for(int i = 0; i < N; i++) {
        buka1 << pengeluaran[i].namaBarang << " : Rp " << pengeluaran[i].hargaBarang << '\n';
         }
    buka1.close();
    cout << "Jadi total pengeluaran anda : Rp " << jumlah << "\n\n";
    return jumlah;
}
void bacaBiaya() {
    ifstream bacaLuar("catatan_pengeluaran.txt");
    if (!bacaLuar.fail()) {
        string baris;
        cout << "List pengeluaran sebelumnya : \n";
        while (getline(bacaLuar, baris)) {
            cout << baris << endl;
            size_t p = baris.rfind("p");
            if (p != string::npos) {
                string hargaLuar = baris.substr(p + 2);
                jumlah += stod(hargaLuar);
            }
        }
        bacaLuar.close();
    } else {
        cout << "File tidak dapat dibuka" << endl;
    }
}
void info(double *cash) {
    sum = 0;
    bukuTabungan = 0;
    jumlah = 0;
    int hitung = 1;
    bacaBiaya();
    bacaWish();
    bacaTab(hitung);
    double sisa;
    sisa = *cash - bukuTabungan - jumlah;
    std::ofstream buka3("info.txt");
    float progress;
    progress = bukuTabungan/sum * 100;
    std::cout << "Anda sudah menabung sebanyak : Rp " << bukuTabungan << '\n';
    std::cout << "Progres anda telah mencapai : " << progress << "%\n";
    std::cout << "Saat ini anda sudah menghabiskan : Rp " << bukuTabungan + jumlah << '\n';
    std::cout << "Sisa uang anda : Rp " << sisa << '\n' << '\n';

    buka3 << "Anda sudah menabung sebanyak : Rp " << bukuTabungan << '\n';
    buka3 << "Progres anda telah mencapai : " << progress << "%" << '\n';
    buka3 << "Saat ini anda sudah menghabiskan : Rp " << bukuTabungan + jumlah << '\n';
    buka3 << "Sisa uang anda : Rp " << sisa << '\n';
    buka3.close();
}
void inputWishlist(thing wishlist[], int i, int N) {
    if (i < N) {
        cout << "Masukkan nama barang ke " << i + 1 << ": ";
        cin >> wishlist[i].namaBarang;
        cout << "Masukkan harga barang ke " << i + 1 << ": ";
        cin >> wishlist[i].hargaBarang;
        sum += wishlist[i].hargaBarang;

        inputWishlist(wishlist, i + 1, N);
    }
}
void inputPengeluaran(thing pengeluaran[], int i, int N) {
    if (i < N) {
        cout << "Masukkan nama barang ke " << i + 1 << ": ";
        cin >> pengeluaran[i].namaBarang;
        cout << "Masukkan harga barang ke " << i + 1 << ": ";
        cin >> pengeluaran[i].hargaBarang;
        jumlah += pengeluaran[i].hargaBarang;

        inputPengeluaran(pengeluaran, i + 1, N);
    }
}

