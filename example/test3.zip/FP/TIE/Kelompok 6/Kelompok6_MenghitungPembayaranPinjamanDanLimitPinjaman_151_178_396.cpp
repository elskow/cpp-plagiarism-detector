#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
using namespace std;

const int Max = 1000;

struct Hutang
{
    string nama[Max];
    string status_peminjam[Max];
    string kurs;
    int banyak_peminjam;
    int bulan[Max];
    double persentase_limit = 0.30;
    double persentase_limit2 = 0.40;
    double uang_pinjaman[Max];
    double uang_pengembalian;
    double cicilan_perbulan;
    double gaji[Max];
    double limit_pinjaman;
    double bunga[Max];
};
void limit_pinjaman(Hutang &);
void pembayaran_hutang(Hutang &);
void file_pembayaran_pinjaman(Hutang);
void file_limitpinjaman(Hutang);
int main()
{
    Hutang hutang;
    int pilihan;
    char pilihan2 = 'Y';
    do
    {
        cout << "===================================================" << endl;
        cout << "                   MENU APLIKASI                   " << endl;
        cout << "===================================================" << endl;
        cout << "1. Limit Pinjaman(perorangan/bank)" << endl;
        cout << "2. Pembayaran Pinjaman(perorangan/bank)" << endl;
        cout << "3. Exit" << endl;
        cout << "Masukkan Pilihan: ";
        cin >> pilihan;
        if (pilihan < 3)
        {
            switch (pilihan)
            {
            case 1:
                limit_pinjaman(hutang);
                file_limitpinjaman(hutang);
                break;
            case 2:
                pembayaran_hutang(hutang);
                file_pembayaran_pinjaman(hutang);
                break;
            default:
                cout << "Pilihan tidak tersedia" << endl;
                break;
            }
            cout << "Apakah Anda Ingin Lanjut? (Y/N): ";
            cin >> pilihan2;
        }
        else if (pilihan == 3)
        {   
            pilihan2 = 'n';
            cout << endl;
            cout << "Anda Memilih Keluar" << endl;
        }
        cout << endl;
    }while((pilihan2 == 'Y') || (pilihan2 == 'y'));
    cout << "Terima Kasih Telah Menggunakan Layanan Kami" << endl;
    return 0;
}
void limit_pinjaman(Hutang &hutang)
{
    cout << endl;
    cout << "Masukkan Jumlah Peminjam: ";
    cin >> hutang.banyak_peminjam;
    cout << "Masukkan Simbol Kurs Yang Akan Digunakan: ";
    cin >> hutang.kurs;
    cout << endl;
    if (hutang.banyak_peminjam > 1)
    {
        for (int i = 0; i < hutang.banyak_peminjam; i++)
        {
            cin.ignore();
            cout << "Masukkan Nama Peminjam ke-" << i + 1 << ": ";
            getline(cin, hutang.nama[i]);
            cout << "Masukkan Status Peminjam ke-" << i + 1 << " (Berkelurga/Single): ";
            getline(cin, hutang.status_peminjam[i]);
            cout << "Masukkan Gaji Peminjam ke-" << i + 1 << ": " << hutang.kurs;
            cin >> hutang.gaji[i];
            cout << "Masukkan Nominal Pinjaman Peminjam ke-" << i + 1 << ": " << hutang.kurs;
            cin >> hutang.uang_pinjaman[i];
            cout << "Masukkan Lama (Bulan) Pengembalian Peminjam ke-" << i + 1 << ": ";
            cin >> hutang.bulan[i];
            if (hutang.status_peminjam[i] == "B" || hutang.status_peminjam[i] == "Berkeluarga" || hutang.status_peminjam[i] == "b" || hutang.status_peminjam[i] == "berkeluarga")
            {
                hutang.limit_pinjaman = hutang.persentase_limit * hutang.gaji[i] * hutang.bulan[i];
                cout << endl;
            }
            else if (hutang.status_peminjam[i] == "S" || hutang.status_peminjam[i] == "s" || hutang.status_peminjam[i] == "Single" || hutang.status_peminjam[i] == "single")
            {
                hutang.limit_pinjaman = hutang.persentase_limit2 * hutang.gaji[i] * hutang.bulan[i];
                cout << endl;
            }
        }

        cout << "=====================================================================" << endl;
        cout << "                   INI ADALAH DATA LIMIT PINJAMAN                    " << endl;
        cout << "=====================================================================" << endl;

        for (int i = 0; i < hutang.banyak_peminjam; i++)
        {
            cout << i + 1 << ". Nama Peminjam ke-" << i + 1 << ": ";
            cout << hutang.nama[i] << endl;
            cout << "   Status Peminjam ke-" << i + 1 << ": ";
            cout << hutang.status_peminjam[i] << endl;
            cout << "   Gaji Peminjam ke-" << i + 1 << ": " << hutang.kurs;
            cout << fixed << setprecision(2) << hutang.gaji[i] << endl;
            cout << "   Nominal Pinjaman Peminjam ke-" << i + 1 << ": " << hutang.kurs;
            cout << fixed << setprecision(2) << hutang.uang_pinjaman[i] << endl;
            cout << "   lama (Bulan) Pengembalian Peminjam ke-" << i + 1 << ": ";
            cout << hutang.bulan[i] << " Bulan" << endl;
            
            if (hutang.status_peminjam[i] == "B" || hutang.status_peminjam[i] == "Berkeluarga" || hutang.status_peminjam[i] == "b" || hutang.status_peminjam[i] == "berkeluarga")
            {
                hutang.limit_pinjaman = hutang.persentase_limit * hutang.gaji[i] * hutang.bulan[i];
                cout << "   Limit Pinjaman Peminjam ke-" << i + 1 << ": " << fixed << setprecision(2) << hutang.kurs << hutang.limit_pinjaman << endl;
                cout << endl;
                if (hutang.limit_pinjaman >= hutang.uang_pinjaman[i])
                {
                    cout << "   PINJAMAN DALAM BATAS LIMIT" << endl;
                    cout << "   PINJAMAN DISETUJUI" << endl;
                }
                else if (hutang.limit_pinjaman <= hutang.uang_pinjaman[i])
                {
                    cout << "   PINJAMAN MELEBIHI LIMIT" << endl;
                    cout << "   PINJAMAN TIDAK DISETUJUI" << endl;
                }
            }
            else if (hutang.status_peminjam[i] == "S" || hutang.status_peminjam[i] == "s" || hutang.status_peminjam[i] == "Single" || hutang.status_peminjam[i] == "single")
            {
                hutang.limit_pinjaman = hutang.persentase_limit2 * hutang.gaji[i] * hutang.bulan[i];
                cout << "   Limit Pinjaman Peminjam ke-" << i + 1 << ": " << fixed << setprecision(2) << hutang.kurs << hutang.limit_pinjaman << endl;
                cout << endl;
                if (hutang.limit_pinjaman >= hutang.uang_pinjaman[i])
                {
                    cout << "   PINJAMAN DALAM BATAS LIMIT" << endl;
                    cout << "   PINJAMAN DISETUJUI" << endl;
                }
                else if (hutang.limit_pinjaman <= hutang.uang_pinjaman[i])
                {
                    cout << "   PINJAMAN MELEBIHI LIMIT" << endl;
                    cout << "   PINJAMAN TIDAK DISETUJUI" << endl;
                }
            }
            cout << endl;
        }
    }
    else
    {
        cin.ignore();
        cout << "Masukkan Nama Peminjam: ";
        getline(cin, hutang.nama[1]);
        cout << "Masukkan Status Peminjam (Berkelurga/Single): ";
        getline(cin, hutang.status_peminjam[1]);
        cout << "Masukkan Gaji Peminjam: " << hutang.kurs;
        cin >> hutang.gaji[1];
        cout << "Masukkan Nominal Yang Ingin Dipinjam: " << hutang.kurs;
        cin >> hutang.uang_pinjaman[1];
        cout << "Masukkan Lama (Bulan) Pengembalian: ";
        cin >> hutang.bulan[1];
       
        if (hutang.status_peminjam[1] == "B" || hutang.status_peminjam[1] == "Berkeluarga" || hutang.status_peminjam[1] == "b" || hutang.status_peminjam[1] == "berkeluarga")
        {
            hutang.limit_pinjaman = hutang.persentase_limit * hutang.gaji[1] * hutang.bulan[1];
            cout << endl;
        }
        else if (hutang.status_peminjam[1] == "S" || hutang.status_peminjam[1] == "s" || hutang.status_peminjam[1] == "Single" || hutang.status_peminjam[1] == "single")
        {
            hutang.limit_pinjaman = hutang.persentase_limit2 * hutang.gaji[1] * hutang.bulan[1];
            cout << endl;
        }

        cout << "=====================================================================" << endl;
        cout << "                   INI ADALAH DATA LIMIT PINJAMAN                    " << endl;
        cout << "=====================================================================" << endl;

        cout << "Nama Peminjam: ";
        cout << hutang.nama[1] << endl;
        cout << "Status Peminjam (Berkelurga/Single): ";
        cout << hutang.status_peminjam[1] << endl;
        cout << "Gaji Peminjam: " << hutang.kurs;
        cout << fixed << setprecision(2) << hutang.gaji[1] << endl;
        cout << "Masukkan Jumlah Yang Ingin Anda Pinjam: " << hutang.kurs;
        cout << fixed << setprecision(2) << hutang.uang_pinjaman[1] << endl;
        cout << "Lama (Bulan) Pengembalian: ";
        cout << hutang.bulan[1] << " Bulan" << endl;
        
        if (hutang.status_peminjam[1] == "B" || hutang.status_peminjam[1] == "Berkeluarga" || hutang.status_peminjam[1] == "b" || hutang.status_peminjam[1] == "berkeluarga")
        {
            hutang.limit_pinjaman = hutang.persentase_limit * hutang.gaji[1] * hutang.bulan[1];
            cout << "Limit Pinjaman: " << hutang.kurs << fixed << setprecision(2) << hutang.limit_pinjaman << endl;
        }
        else if (hutang.status_peminjam[1] == "S" || hutang.status_peminjam[1] == "s" || hutang.status_peminjam[1] == "Single" || hutang.status_peminjam[1] == "single")
        {
            hutang.limit_pinjaman = hutang.persentase_limit2 * hutang.gaji[1] * hutang.bulan[1];
            cout << "Limit Pinjaman: " << hutang.kurs << fixed << setprecision(2) << hutang.limit_pinjaman << endl;
        }

        cout << endl;

        if (hutang.limit_pinjaman >= hutang.uang_pinjaman[1])
        {
            cout << "PINJAMAN DALAM BATAS LIMIT" << endl;
            cout << "PINJAMAN DISETUJUI" << endl;
        }
        else if (hutang.limit_pinjaman <= hutang.uang_pinjaman[1])
        {
            cout << "PINJAMAN MELEBIHI LIMIT" << endl;
            cout << "PINJAMAN TIDAK DISETUJUI" << endl;
        }
        cout << endl;
    }
    cout << "Data Ini Telah Di Simpan Di 'file_Limit_Pinjaman.txt'" << endl;
    cout << endl;
}

void file_limitpinjaman(Hutang hutang)
{
    ofstream coutfile;
    coutfile.open("file_Limit_Pinjaman.txt");
    coutfile << "=====================================================================" << endl;
    coutfile << "                   INI ADALAH DATA LIMIT PINJAMAN                    " << endl;
    coutfile << "=====================================================================" << endl;
    if (hutang.banyak_peminjam > 1)
    {
        for (int i = 0; i < hutang.banyak_peminjam; i++)
        {
            coutfile << i + 1 << ". Nama Peminjam ke-" << i + 1 << ": ";
            coutfile << hutang.nama[i] << endl;
            coutfile << "   Status Peminjam ke-" << i + 1 << ": ";
            coutfile << hutang.status_peminjam[i] << endl;
            coutfile << "   Gaji Peminjam ke-" << i + 1 << ": " << hutang.kurs;
            coutfile << fixed << setprecision(2) << hutang.gaji[i] << endl;
            coutfile << "   Nominal Pinjaman Peminjam ke-" << i + 1 << ": " << hutang.kurs;
            coutfile << fixed << setprecision(2) << hutang.uang_pinjaman[i] << endl;
            coutfile << "   Lama (Bulan) Pengembalian Peminjam ke-" << i + 1 << ": ";
            coutfile << hutang.bulan[i] << " Bulan" << endl;
            
            if (hutang.status_peminjam[i] == "B" || hutang.status_peminjam[i] == "Berkeluarga" || hutang.status_peminjam[i] == "b" || hutang.status_peminjam[i] == "berkeluarga")
            {
                hutang.limit_pinjaman = hutang.persentase_limit * hutang.gaji[i] * hutang.bulan[i];
                coutfile << "   Limit Pinjaman Peminjam ke-" << i + 1 << ": " << fixed << setprecision(2) << hutang.kurs << hutang.limit_pinjaman << endl;
            }
            else if (hutang.status_peminjam[i] == "S" || hutang.status_peminjam[i] == "s" || hutang.status_peminjam[i] == "Single" || hutang.status_peminjam[i] == "single")
            {
                hutang.limit_pinjaman = hutang.persentase_limit2 * hutang.gaji[i] * hutang.bulan[i];
                coutfile << "   Limit Pinjaman Peminjam ke-" << i + 1 << ": " << fixed << setprecision(2) << hutang.kurs <<  hutang.limit_pinjaman << endl;
            }

            coutfile << endl;

            if (hutang.limit_pinjaman >= hutang.uang_pinjaman[i])
            {
                coutfile << "   PINJAMAN DALAM BATAS LIMIT" << endl;
                coutfile << "   PINJAMAN DISETUJUI" << endl;
            }
            else if (hutang.limit_pinjaman <= hutang.uang_pinjaman[i])
            {
                coutfile << "   PINJAMAN MELEBIHI LIMIT" << endl;
                coutfile << "   PINJAMAN TIDAK DISETUJUI" << endl;
            }
            coutfile << endl;
        }
    }
    else
    {
        coutfile << "Nama Peminjam: ";
        coutfile << hutang.nama[1] << endl;
        coutfile << "Status Peminjam (Berkeluarga/Single): ";
        coutfile << hutang.status_peminjam[1] << endl;
        coutfile << "Gaji Peminjam: " << hutang.kurs;
        coutfile << fixed << setprecision(2) << hutang.gaji[1] << endl;
        coutfile << "Masukkan Jumlah Yang Ingin Anda Pinjam: " << hutang.kurs;
        coutfile << fixed << setprecision(2) << hutang.uang_pinjaman[1] << endl;
        coutfile << "Lama (Bulan) Pengembalian: ";
        coutfile << hutang.bulan[1] << " Bulan" << endl;
        
        if (hutang.status_peminjam[1] == "B" || hutang.status_peminjam[1] == "Berkeluarga" || hutang.status_peminjam[1] == "b" || hutang.status_peminjam[1] == "berkeluarga")
        {
            hutang.limit_pinjaman = hutang.persentase_limit * hutang.gaji[1] * hutang.bulan[1];
            coutfile << "Limit Pinjaman: " << hutang.kurs << fixed << setprecision(2) << hutang.limit_pinjaman << endl;
        }
        else if (hutang.status_peminjam[1] == "S" || hutang.status_peminjam[1] == "s" || hutang.status_peminjam[1] == "Single" || hutang.status_peminjam[1] == "single")
        {
            hutang.limit_pinjaman = hutang.persentase_limit2 * hutang.gaji[1] * hutang.bulan[1];
            coutfile << "Limit Pinjaman: " << hutang.kurs << fixed << setprecision(2) << hutang.limit_pinjaman << endl;
        }

        coutfile << endl;

        if (hutang.limit_pinjaman >= hutang.uang_pinjaman[1])
        {
            coutfile << "PINJAMAN DALAM BATAS LIMIT" << endl;
            coutfile << "PINJAMAN DISETUJUI" << endl;
        }
        else if (hutang.limit_pinjaman <= hutang.uang_pinjaman[1])
        {
            coutfile << "PINJAMAN MELEBIHI LIMIT" << endl;
            coutfile << "PINJAMAN TIDAK DISETUJUI" << endl;
        }
    }
    coutfile.close();
}
void pembayaran_hutang(Hutang &hutang)
{
    cout << endl;
    cout << "Masukkan Jumlah Peminjam: ";
    cin >> hutang.banyak_peminjam;
    cout << "Masukkan Simbol Kurs Yang Akan Digunakan: ";
    cin >> hutang.kurs;
    cout << endl;
    if (hutang.banyak_peminjam > 1)
    {
        for (int i = 0; i < hutang.banyak_peminjam; i++)
        {
            cin.ignore();
            cout << "Masukkan Nama Peminjam ke-" << i + 1 << ": ";
            getline(cin, hutang.nama[i]);
            cout << "Masukkan Nominal Uang Pinjaman Peminjam ke-" << i + 1 << ": " << hutang.kurs;
            cin >> hutang.uang_pinjaman[i];
            cout << "Masukkan Lama (Bulan) Pembayaran Peminjam ke-" << i + 1 << ": ";
            cin >> hutang.bulan[i];
            cout << "Masukkan Persentase Bunga Tahunan Peminjam ke-" << i + 1 << ": ";
            cin >> hutang.bunga[i];
            cout << endl;
        }

        cout << "=======================================================================" << endl;
        cout << "                   INI ADALAH DATA PEMBAYARAN PINJAMAN                 " << endl;
        cout << "=======================================================================" << endl;

        for (int i = 0; i < hutang.banyak_peminjam; i++)
        {
            cout << i + 1 << ". Nama Peminjam ke-" << i + 1 << ": ";
            cout << hutang.nama[i] << endl;
            cout << "   Nominal Uang Pinjaman Peminjam ke-" << i + 1 << ": " << hutang.kurs;
            cout << fixed << setprecision(2) << hutang.uang_pinjaman[i] << endl;
            cout << "   Lama (Bulan) Pembayaran Peminjam ke-" << i + 1 << ": ";
            cout << hutang.bulan[i] << " Bulan" << endl;
            cout << "   Persentase Bunga Tahunan Peminjam ke-" << i + 1 << ": ";
            cout << hutang.bunga[i] << "%" << endl;
            hutang.uang_pengembalian = ((((hutang.bunga[i] / 100) / 12) * hutang.bulan[i] * hutang.uang_pinjaman[i]) + (hutang.uang_pinjaman[i]));
            cout << "   Total Yang Harus Dibayar Peminjam ke-" << i + 1 << ": " << fixed << setprecision(2) << hutang.kurs << hutang.uang_pengembalian << endl;
            hutang.cicilan_perbulan = hutang.uang_pengembalian / hutang.bulan[i];
            cout << "   Cicilan Per-bulan Peminjam ke-" << i + 1 << ": " << fixed << setprecision(2) << hutang.kurs << hutang.cicilan_perbulan << "/Bulan" << endl;
            cout << endl;
        }
    }
    else
    {
        cin.ignore();
        cout << "Masukkan Nama Peminjam: ";
        getline(cin, hutang.nama[1]);
        cout << "Masukkan Nominal Uang Pinjaman: " << hutang.kurs;
        cin >> hutang.uang_pinjaman[1];
        cout << "Masukkan Lama (Bulan) Pembayaran Peminjam: ";
        cin >> hutang.bulan[1];
        cout << "Masukkan Persentase Bunga Tahunan Peminjam: ";
        cin >> hutang.bunga[1];
        cout << endl;
        
        cout << "========================================================================" << endl;
        cout << "                   INI ADALAH DATA PEMBAYARAN PINJAMAN                  " << endl;
        cout << "========================================================================" << endl;

        cout << "Nama Peminjam: ";
        cout << hutang.nama[1] << endl;
        cout << "Nominal Uang Pinjaman: " << hutang.kurs;
        cout << fixed << setprecision(2) << hutang.uang_pinjaman[1] << endl;
        cout << "Lama (Bulan) Pembayaran Peminjam: ";
        cout << hutang.bulan[1] << " Bulan" << endl; 
        cout << "Persentase Bunga Tahunan Peminjam: ";
        cout << hutang.bunga[1] << "%" << endl;
        hutang.uang_pengembalian = (((hutang.bunga[1] / 100) / 12) * hutang.bulan[1] * hutang.uang_pinjaman[1]) + (hutang.uang_pinjaman[1]);
        cout << "Total Yang Harus Dibayar Peminjam: " << hutang.kurs << fixed << setprecision(2) << hutang.uang_pengembalian << endl;
        hutang.cicilan_perbulan = hutang.uang_pengembalian / hutang.bulan[1];
        cout << "Cicilan Per-bulan Peminjam: " << hutang.kurs << fixed << setprecision(2) << hutang.cicilan_perbulan  << "/Bulan" << endl;
        cout << endl;
    }
    cout << "Data Ini Telah Di Simpan Di 'file_Pembayaran_Pinjaman.txt'" << endl;
    cout << endl;
}
void file_pembayaran_pinjaman(Hutang hutang)
{
    ofstream outfile;
    outfile.open("file_Pembayaran_Pinjaman.txt");
    outfile << "========================================================================" << endl;
    outfile << "                    INI ADALAH DATA PEMBAYARAN PINJAMAN                 " << endl;
    outfile << "========================================================================" << endl;
    if (hutang.banyak_peminjam > 1)
    {
        for (int i = 0; i < hutang.banyak_peminjam; i++)
        {
            outfile << i + 1 << ". Nama Peminjam ke-" << i + 1 << ": ";
            outfile << hutang.nama[i] << endl;
            outfile << "   Nominal Uang Pinjaman Peminjam ke-" << i + 1 << ": " << hutang.kurs;
            outfile << fixed << setprecision(2) << hutang.uang_pinjaman[i] << endl;
            outfile << "   Lama (Bulan) Pembayaran Peminjam ke-" << i + 1 << ": ";
            outfile << hutang.bulan[i] << " Bulan" << endl;
            outfile << "   Persentase Bunga Tahunan Peminjam ke-" << i + 1 << ": ";
            outfile << hutang.bunga[i] << "%" << endl;
            hutang.uang_pengembalian = ((((hutang.bunga[i] / 100) / 12) * hutang.bulan[i] * hutang.uang_pinjaman[i]) + (hutang.uang_pinjaman[i]));
            outfile << "   Total Yang Harus Dibayar Peminjam ke-" << i + 1 << ": " << fixed << setprecision(2) << hutang.kurs << hutang.uang_pengembalian << endl;
            hutang.cicilan_perbulan = hutang.uang_pengembalian / hutang.bulan[i];
            outfile << "   Cicilan Per-bulan Peminjam ke-" << i + 1 << ": " << fixed << setprecision(2) << hutang.kurs << hutang.cicilan_perbulan << "/Bulan" << endl;
            outfile << endl;
        }
    }
    else
    {
        outfile << "Nama Peminjam: ";
        outfile << hutang.nama[1] << endl;
        outfile << "Nominal Uang Pinjaman: " << hutang.kurs;
        outfile << fixed << setprecision(2) << hutang.uang_pinjaman[1] << endl;
        outfile << "Lama (Bulan) Pembayaran Peminjam: ";
        outfile << hutang.bulan[1] << " Bulan" << endl;
        outfile << "Persentase Bunga Tahunan Peminjam: ";
        outfile << hutang.bunga[1] << "%" << endl;
        hutang.uang_pengembalian = (((hutang.bunga[1] / 100) / 12) * hutang.bulan[1] * hutang.uang_pinjaman[1]) + (hutang.uang_pinjaman[1]);
        outfile << "Total Yang Harus Dibayar Peminjam: " << hutang.kurs << fixed << setprecision(2) << hutang.uang_pengembalian << endl;
        hutang.cicilan_perbulan = hutang.uang_pengembalian / hutang.bulan[1];
        outfile << "Cicilan Per-bulan Peminjam: " << hutang.kurs << fixed << setprecision(2) << hutang.cicilan_perbulan << "/Bulan" << endl;
        outfile << endl;
    }
    outfile.close();
}