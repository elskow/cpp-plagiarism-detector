#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

// Struktur untuk merepresentasikan makanan
struct Makanan {
    char nama[50];
    int harga;
};

// Fungsi untuk menampilkan menu
void tampilkanMenu() {
    cout << "Menu Pilihan Makanan:" << endl;
    cout << "       1. Nasi Goreng" << endl;
    cout << "       2. Mie Goreng" << endl;
    cout << "       3. Ayam Bakar" << endl;
    cout << "       4. Soto Ayam" << endl;
    cout << "       5. Bakso" << endl;
    cout << "Menu Pilihan Minuman:" << endl;
    cout << "       6. Air Putih Kemasan" << endl;
    cout << "       7. Es Teh" << endl;
    cout << "       8. Teh Hangat" << endl;
    cout << "       9. Es Kopi" << endl;
    cout << "       10. Kopi Hangat" << endl;
    cout << "       11. Es Jeruk" << endl;
    cout << "       12. Jeruk Hangat" << endl;
    cout << "       13. Es Milo" << endl;
    cout << "       14. Es Campur" << endl;
    cout << "       15. Selesai Memesan" << endl;
    cout << "Pilih menu (1-15): ";
}

// Fungsi untuk menampilkan pesanan
void tampilkanPesanan(Makanan* pesanan, int jumlahPesanan) {
    cout << "Pesanan Anda:" << endl;
    for (int i = 0; i < jumlahPesanan; ++i) {
        cout << i + 1 << ". " << pesanan[i].nama << " - Rp. " << pesanan[i].harga << endl;
    }
}

int main() {
    // Deklarasi variabel
    const int MAX_PESANAN = 10;
    Makanan menu[] = {
        {"Nasi Goreng", 15000}, {"Mie Goreng", 12000}, {"Ayam Bakar", 25000}, {"Soto Ayam", 15000}, {"Bakso", 10000}, {"Air Putih Kemasan", 5000}, {"Es Teh", 8000}, {"Teh Hangat", 6000}, {"Es Kopi", 8000}, {"Kopi Hangat", 6000}, {"Es Jeruk", 8000}, {"Jeruk Hangat", 6000}, {"Es Milo", 8000}, {"Es Campur", 12000}
        
    };
    Makanan pesanan[MAX_PESANAN];
    int jumlahPesanan = 0;
    int totalHargaSebelumDiskon = 0;
    int pilihan;

    cout << "Selamat datang di Kafe Perival" << endl;
    cout << endl;
    cout << "                                           PROMO SPESIAL!!!        " << endl;
    cout << "   1. Dapatkan diskon sebesar 20% dengan pembelian 3 porsi Nasi Goreng dan 2 porsi Mie Goreng" << endl;
    cout << "   2. Dapatkan diskon sebesar 10% dengan pembelian Paket Bakso, terdiri dari 1 porsi Bakso dan 1 gelas Es Teh" << endl;
    cout << "   3. Dapatkan Es Teh secara gratis dengan pembelian 2 porsi Ayam Bakar (Pastikan menambahkan Es Teh ke dalam keranjang)" << endl;
    cout << endl;

    do {
        // Menampilkan menu
        tampilkanMenu();

        // Menerima input pilihan menu
        cin >> pilihan;
        cout << endl;

        if (pilihan >= 1 && pilihan <= 14) {
        // Menambahkan makanan ke pesanan
        pesanan[jumlahPesanan] = menu[pilihan - 1];
        jumlahPesanan++;
        // Menghitung total harga sebelum diskon
        totalHargaSebelumDiskon += menu[pilihan - 1].harga;
        cout << "Pesanan ditambahkan ke keranjang." << endl;
        cout << "Mau memesan makanan / minuman lagi? (Tekan 15 jika selesai memesan)" << endl;
        cout << endl;
        } else if (pilihan == 15) {
            // Menampilkan pesanan dan total harga
            tampilkanPesanan(pesanan, jumlahPesanan);
            int totalHarga = 0;
            for (int i = 0; i < jumlahPesanan; ++i) {
                totalHarga += pesanan[i].harga;
            }
            cout << "Total Harga: Rp " << totalHarga << endl;
            
            // Mengecek jumlah Nasi Goreng dan Mie Goreng dalam pesanan
            int jumlahNasiGoreng = 0;
            int jumlahMieGoreng = 0;
            
            for (int i = 0; i < jumlahPesanan; ++i) {
                if (strcmp(pesanan[i].nama, "Nasi Goreng") == 0) {
                    jumlahNasiGoreng++;
                } else if (strcmp(pesanan[i].nama, "Mie Goreng") == 0) {
                    jumlahMieGoreng++;
                }
            }
            
            // Memberikan diskon 20% jika ada 3 Nasi Goreng dan 2 Mie Goreng
            if (jumlahNasiGoreng >= 3 && jumlahMieGoreng >= 2) {
                cout << "Anda mendapatkan diskon 20% untuk 3 Nasi Goreng dan 2 Mie Goreng!" << endl;
                float diskon = 0.2 * (menu[0].harga * 3 + menu[1].harga * 2); // Diskon total dari 3 Nasi Goreng dan 2 Mie Goreng
                totalHarga -= static_cast<int>(diskon); // Mengurangi total harga dengan diskon
                cout << "Total Harga (setelah diskon): Rp " << totalHarga << endl; // Menampilkan total harga setelah diskon
            }

            // Mengecek jumlah Bakso dan Es Teh dalam pesanan
            int jumlahBakso = 0;
            int jumlahEsTeh = 0;
            
            for (int i = 0; i < jumlahPesanan; ++i) {
                if (strcmp(pesanan[i].nama, "Bakso") == 0) {
                    jumlahBakso++;
                } else if (strcmp(pesanan[i].nama, "Es Teh") == 0) {
                    jumlahEsTeh++;
                }
            }

            // Memberikan diskon 10% jika memesan paket bakso
            if (jumlahBakso >= 1 && jumlahEsTeh >= 1) {
                cout << "Anda mendapatkan diskon 10% untuk Paket Bakso!" << endl;
                int hargaBakso = 0;
                int hargaEsTeh = 0;
                for (int i = 0; i < jumlahPesanan; ++i) {
                    if (strcmp(pesanan[i].nama, "Bakso") == 0) {
                        hargaBakso = pesanan[i].harga;
                    } else if (strcmp(pesanan[i].nama, "Es Teh") == 0) {
                        hargaEsTeh = pesanan[i].harga;
                    }
                }
            float diskon = 0.1 * (hargaBakso + hargaEsTeh); // Diskon total dari Paket Bakso
            totalHarga -= static_cast<int>(diskon); // Mengurangi total harga dengan diskon
            cout << "Total Harga (setelah diskon): Rp " << totalHarga << endl; // Menampilkan total harga setelah diskon
            }
            
            // Mengecek jumlah Ayam Bakar dan Es Teh dalam pesanan
            int jumlahAyamBakar = 0;
            int jesteh = 0;
            
            for (int i = 0; i < jumlahPesanan; ++i) {
                if (strcmp(pesanan[i].nama, "Ayam Bakar") == 0) {
                    jumlahAyamBakar++;
                } else if (strcmp(pesanan[i].nama, "Es Teh") == 0) {
                    jesteh++;
                }
            }

            // 2 ayam bakar grats es teh
            if (jumlahAyamBakar >= 2 && jesteh >= 1) {
                cout << "Anda mendapatkan Es Teh gratis!" << endl;
                int hargaEsTeh = 0;
                for (int i = 0; i < jumlahPesanan; ++i) {
                    if (strcmp(pesanan[i].nama, "Es Teh") == 0) {
                        hargaEsTeh = pesanan[i].harga;
                    }
                }
            totalHarga -= hargaEsTeh; // Mengurangi total harga dengan harga Es Teh
            cout << "Total Harga (setelah diskon): Rp " << totalHarga << endl; // Menampilkan total harga setelah diskon
            }       

            // Simpan pesanan ke file
            ofstream fileOutput("pesanan.txt");
            fileOutput << "Pesanan Anda:" << endl;
            for (int i = 0; i < jumlahPesanan; ++i) {
                fileOutput << i + 1 << ". " << pesanan[i].nama << " -   Rp." << pesanan[i].harga << endl;
            }
            // output total harga sebelum diskon dalam file
            fileOutput << "Total Harga sebelum diskon               : Rp " << totalHargaSebelumDiskon << endl;
            fileOutput << "Total Harga setelah diskon (jika ada)    : Rp " << totalHarga << endl; // Menampilkan total harga setelah diskon
            fileOutput << endl << endl;
            fileOutput << "             Terima Kasih Atas Kunjungan Anda❤️" << endl;
            fileOutput.close();

            cout << "Pesanan Anda telah disimpan dalam file pesanan.txt." << endl;
        } else {
            // Pilihan menu tidak valid
            cout << "Pilihan tidak valid. Silakan pilih kembali." << endl;
            cout << endl;
        }

    } while (pilihan != 15);

    return 0;
}