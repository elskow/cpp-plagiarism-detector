#include <iostream>
#include <fstream>

using namespace std;

struct Suhu {
    double celsius;
    double reamur;
    double fahrenheit;
};

void konversiSuhu(Suhu &data, double suhu, const char satuan) {
    if (satuan == 'C' || satuan == 'c') {
        data.celsius = suhu;
        data.reamur = 0.8 * suhu;
        data.fahrenheit = (suhu * 9 / 5) + 32;
    } else if (satuan == 'R' || satuan == 'r') {
        data.celsius = 1.25 * suhu;
        data.reamur = suhu;
        data.fahrenheit = (1.25 * suhu * 9 / 5) + 32;
    } else if (satuan == 'F' || satuan == 'f') {
        data.celsius = (suhu - 32) * 5 / 9;
        data.reamur = (suhu - 32) * 5 / 9 * 0.8;
        data.fahrenheit = suhu;
    } else if (satuan == 'K' || satuan == 'k') {
        data.celsius = suhu - 273.15;
        data.reamur = (suhu - 273.15) * 0.8;
        data.fahrenheit = (suhu - 273.15) * 9 / 5 + 32;
    } else {
        cout << "Satuan suhu tidak valid." << endl;
        exit(1);
    }
}

int main() {
    const char stringArray[] = "Converter Suhu";

    const char *stringPointer = stringArray;

    cout << "operasi ";
    while (*stringPointer) {
        cout << *stringPointer;
        stringPointer++;
    }

    cout << "\n";

    double suhu;
    char satuan;

    cout << "Pilih satuan suhu (C/Celsius, R/Reamur, F/Fahrenheit, K/Kelvin): ";
    cin >> satuan;

    cout << "Masukkan suhu: ";
    cin >> suhu;

    Suhu dataSuhu;

    konversiSuhu(dataSuhu, suhu, satuan);

    cout << "\nHasil Konversi:\n";
    cout << "Celsius   : " << dataSuhu.celsius << endl;
    cout << "Reamur    : " << dataSuhu.reamur << endl;
    cout << "Fahrenheit: " << dataSuhu.fahrenheit << endl;
    cout << "Kelvin    : " << dataSuhu.celsius + 273.15 << endl;

    ofstream file("hasil_konversi.txt");
    if (file.is_open()) {
        file << "Hasil Konversi:\n";
        file << "Celsius   : " << dataSuhu.celsius << endl;
        file << "Reamur    : " << dataSuhu.reamur << endl;
        file << "Fahrenheit: " << dataSuhu.fahrenheit << endl;
        file << "Kelvin    : " << dataSuhu.celsius + 273.15 << endl;
        file.close();
        cout << "\nData berhasil disimpan dalam file 'hasil_konversi.txt'\n";
    } else {
        cout << "\nGagal menyimpan data ke file\n";
    }

    return 0;
}
