#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

struct Pakaian {
    int id;
    string jenis;
    string warna;
    string ukuran;
    int stok;
    double harga;
};

struct Pelanggan {
    int id;
    string nama;
    string alamat;
    double totalBelanja;
};

class ManajemenPakaian {
private:
    vector<Pakaian> daftarPakaian;
    vector<Pelanggan> daftarPelanggan;
    int idPelangganTerakhir;

public:
    ManajemenPakaian() : idPelangganTerakhir(1000) {}

    void tambahPakaian(int id, const string& jenis, const string& warna, const string& ukuran, int stok, double harga) {
    Pakaian pakaian;
    pakaian.id = id;
    pakaian.jenis = jenis;
    pakaian.warna = warna;
    pakaian.ukuran = ukuran;
    pakaian.stok = stok;
    pakaian.harga = harga;

    daftarPakaian.push_back(pakaian);
    cout << "Pakaian berhasil ditambahkan.\n";
}

void cariStokBerdasarkanID(int idCari) {
        auto itPakaian = find_if(daftarPakaian.begin(), daftarPakaian.end(), [idCari](const Pakaian& p) {
            return p.id == idCari;
        });

        if (itPakaian != daftarPakaian.end()) {
            cout << "Pakaian dengan ID " << idCari << " ditemukan.\n";
            cout << "Jenis: " << itPakaian->jenis << "\n";
            cout << "Warna: " << itPakaian->warna << "\n";
            cout << "Ukuran: " << itPakaian->ukuran << "\n";
            cout << "Stok: " << itPakaian->stok << "\n";
            cout << "Harga: " << itPakaian->harga << "\n";
        } else {
            cout << "Pakaian dengan ID " << idCari << " tidak ditemukan.\n";
        }
    }

    void transaksi() {
        int idPelanggan, idPakaian, jumlahBeli;
        cout << "Masukkan ID pelanggan: ";
        cin >> idPelanggan;

        auto itPelanggan = find_if(daftarPelanggan.begin(), daftarPelanggan.end(), [idPelanggan](const Pelanggan& p) {
            return p.id == idPelanggan;
        });

        if (itPelanggan == daftarPelanggan.end()) {
            cout << "Pelanggan tidak ditemukan. Silakan daftar sebagai pelanggan terlebih dahulu.\n";
            return;
        }

        cout << "Masukkan ID pakaian yang dibeli: ";
        cin >> idPakaian;

        auto itPakaian = find_if(daftarPakaian.begin(), daftarPakaian.end(), [idPakaian](const Pakaian& p) {
            return p.id == idPakaian;
        });

        if (itPakaian != daftarPakaian.end()) {
            cout << "Masukkan jumlah pakaian yang dibeli: ";
            cin >> jumlahBeli;

            if (itPakaian->stok >= jumlahBeli) {
                itPakaian->stok -= jumlahBeli;

                // Tambahkan perhitungan diskon dan tax
                double totalHarga = itPakaian->harga * jumlahBeli;
                double diskon = 0.1; // Misalnya diskon 10%
                double pajak = 0.05; // Misalnya pajak 5%

                totalHarga = totalHarga - (totalHarga * diskon);
                totalHarga = totalHarga + (totalHarga * pajak);

                cout << "Total harga (setelah diskon dan pajak): " << totalHarga << endl;

                // Pilihan pembayaran
                int metodePembayaran;
                cout << "Pilih metode pembayaran (1. Tunai, 2. Non-Tunai): ";
                cin >> metodePembayaran;

                if (metodePembayaran == 1) {
                    cout << "Pembayaran dengan tunai\n";
                    // Proses pembayaran dengan tunai
                    itPelanggan->totalBelanja += totalHarga;

                } else if (metodePembayaran == 2) {
                    cout << "Pembayaran dengan QRIS (non-tunai)\n";
                    // Proses pembayaran dengan QRIS
                    itPelanggan->totalBelanja += totalHarga;
                } else {
                    cout << "Metode pembayaran tidak valid.\n";
                    return;
                }

                // Menampilkan informasi transaksi
                cout << "Transaksi berhasil!\n";
                cout << "Pelanggan: " << itPelanggan->nama << " (ID: " << itPelanggan->id << ")\n";
                cout << "Pakaian: " << itPakaian->jenis << " (ID: " << itPakaian->id << ")\n";
                cout << "Jumlah dibeli: " << jumlahBeli << "\n";
                cout << "Total Harga: " << totalHarga << "\n";
                cout << "Sisa Stok: " << itPakaian->stok << "\n";
                cout << "Total Belanja Pelanggan: " << itPelanggan->totalBelanja << "\n";

                // Menampilkan struk pembelian
                cetakStruk(itPelanggan->nama, itPakaian->jenis, jumlahBeli, totalHarga);

            } else {
                cout << "Stok tidak mencukupi.\n";
            }
        } else {
            cout << "Pakaian tidak ditemukan.\n";
        }
    }

    void cetakStruk(const string& namaPelanggan, const string& jenisPakaian, int jumlahBeli, double totalHarga) {
        cout << "\n===== Struk Pembelian =====\n";
        cout << "Pelanggan: " << namaPelanggan << "\n";
        cout << "Pakaian: " << jenisPakaian << "\n";
        cout << "Jumlah dibeli: " << jumlahBeli << "\n";
        cout << "Total Harga: " << totalHarga << "\n";
        cout << "Terima kasih atas pembelian Anda!\n";
        cout << "=============================\n";
    }

    void daftarPelangganBaru() {
        Pelanggan pelanggan;
        pelanggan.id = ++idPelangganTerakhir;

        cout << "Masukkan nama pelanggan: ";
        cin.ignore(); // Membersihkan buffer keyboard
        getline(cin, pelanggan.nama);

        cout << "Masukkan alamat pelanggan: ";
        getline(cin, pelanggan.alamat);

        pelanggan.totalBelanja = 0.0;

        daftarPelanggan.push_back(pelanggan);
        cout << "Pelanggan baru berhasil didaftarkan dengan ID: " << pelanggan.id << "\n";
    }

    void tampilkanDataPelanggan() {
        if (daftarPelanggan.empty()) {
            cout << "Belum ada pelanggan terdaftar.\n";
        } else {
            cout << "\n===== Daftar Pelanggan =====\n";
            for (const auto& pelanggan : daftarPelanggan) {
                cout << "ID: " << pelanggan.id << ", Nama: " << pelanggan.nama << ", Alamat: " << pelanggan.alamat
                          << ", Total Belanja: " << pelanggan.totalBelanja << "\n";
            }
            cout << "============================\n";
        }
    }

    void simpanDataKeJSON(const string& namaFile) {
        ofstream file(namaFile);

        if (file.is_open()) {
            file << "{\n";
            file << "  \"Pakaian\": [\n";

            for (size_t i = 0; i < daftarPakaian.size(); ++i) {
                file << "    {\"id\": " << daftarPakaian[i].id
                     << ", \"jenis\": \"" << daftarPakaian[i].jenis
                     << "\", \"warna\": \"" << daftarPakaian[i].warna
                     << "\", \"ukuran\": \"" << daftarPakaian[i].ukuran
                     << "\", \"stok\": " << daftarPakaian[i].stok
                     << ", \"harga\": " << daftarPakaian[i].harga
                     << "}";
                if (i != daftarPakaian.size() - 1) {
                    file << ",";
                }
                file << "\n";
            }

            file << "  ],\n";
            file << "  \"Pelanggan\": [\n";

            for (size_t i = 0; i < daftarPelanggan.size(); ++i) {
                file << "    {\"id\": " << daftarPelanggan[i].id
                     << ", \"nama\": \"" << daftarPelanggan[i].nama
                     << "\", \"alamat\": \"" << daftarPelanggan[i].alamat
                     << "\", \"totalBelanja\": " << daftarPelanggan[i].totalBelanja
                     << "}";
                if (i != daftarPelanggan.size() - 1) {
                    file << ",";
                }
                file << "\n";
            }

            file << "  ]\n";
            file << "}\n";

            file.close();
            cout << "Data berhasil disimpan ke file JSON.\n";
        } else {
            cout << "Gagal membuka file JSON.\n";
        }
    }

    void bacaDataDariJSON(const string& namaFile) {
        ifstream file(namaFile);

        if (file.is_open()) {
            // Baca file JSON
            string jsonContent((istreambuf_iterator<char>(file)), istreambuf_iterator<char>());

            // Proses parsing JSON secara manual (tanpa library)
            size_t pos = jsonContent.find("\"Pakaian\": [");
            if (pos != string::npos) {
                pos += 12; // Panjang string "\"Pakaian\": ["
                size_t endPos = jsonContent.find("]", pos);

                if (endPos != string::npos) {
                    string pakaianData = jsonContent.substr(pos, endPos - pos);

                    size_t start = 0;
                    do {
                        // Cari data pakaian
                        size_t idPos = pakaianData.find("\"id\": ", start);
                        if (idPos == string::npos) {
                            break;
                        }

                        size_t idEndPos = pakaianData.find(",", idPos);
                        if (idEndPos == string::npos) {
                            break;
                        }

                        int id = stoi(pakaianData.substr(idPos + 6, idEndPos - idPos - 6));

                        size_t jenisPos = pakaianData.find("\"jenis\": \"", idEndPos);
                        if (jenisPos == string::npos) {
                            break;
                        }

                        size_t jenisEndPos = pakaianData.find("\",", jenisPos);
                        if (jenisEndPos == string::npos) {
                            break;
                        }

                        string jenis = pakaianData.substr(jenisPos + 9, jenisEndPos - jenisPos - 9);

                                               // ... (Lakukan hal yang sama untuk atribut lainnya)

                        Pakaian pakaian;
                        pakaian.id = id;
                        pakaian.jenis = jenis;

                        // ... (Ambil atribut lainnya seperti warna, ukuran, stok, dan harga)

                        size_t stokPos = pakaianData.find("\"stok\": ", jenisEndPos);
                        if (stokPos == string::npos) {
                            break;
                        }

                        size_t stokEndPos = pakaianData.find(",", stokPos);
                        if (stokEndPos == string::npos) {
                            break;
                        }

                        pakaian.stok = stoi(pakaianData.substr(stokPos + 8, stokEndPos - stokPos - 8));

                        size_t hargaPos = pakaianData.find("\"harga\": ", stokEndPos);
                        if (hargaPos == string::npos) {
                            break;
                        }

                        size_t hargaEndPos = pakaianData.find("}", hargaPos);
                        if (hargaEndPos == string::npos) {
                            break;
                        }

                        pakaian.harga = stod(pakaianData.substr(hargaPos + 9, hargaEndPos - hargaPos - 9));

                        // Tambahkan pakaian ke daftarPakaian
                        daftarPakaian.push_back(pakaian);

                        // Pindah posisi start untuk pencarian selanjutnya
                        start = hargaEndPos;
                    } while (start != string::npos);
                }
            }

            // ... (Lakukan hal yang sama untuk bagian "Pelanggan")

            file.close();
            cout << "Data berhasil dimuat dari file JSON.\n";
        } else {
            cout << "Gagal membuka file JSON.\n";
        }
    }
};

int main() {
    ManajemenPakaian manajemen;

    // Membaca data dari file JSON (jika ada)
    manajemen.bacaDataDariJSON("data_pakaian.json");

    int pilihan;
    do {
        cout << "\n===== Aplikasi Manajemen Pakaian =====\n";
        cout << "1. Tambah Pakaian\n";
        cout << "2. Transaksi\n";
        cout << "3. Daftar Pelanggan Baru\n";
        cout << "4. Tampilkan Data Pelanggan\n";
        cout << "5. Cari Stok Berdasarkan ID\n";
        cout << "6. Simpan Data ke database\n";
        cout << "7. Keluar\n";
        cout << "Pilih menu: ";
        cin >> pilihan;

        switch (pilihan) {
            case 1: {
                int id, stok;
                string jenis, warna, ukuran;
                double harga;

                cout << "Masukkan ID pakaian: ";
                cin >> id;
                cout << "Masukkan jenis pakaian: ";
                cin >> jenis;
                cout << "Masukkan warna pakaian: ";
                cin >> warna;
                cout << "Masukkan ukuran pakaian: ";
                cin >> ukuran;
                cout << "Masukkan stok pakaian: ";
                cin >> stok;
                cout << "Masukkan harga pakaian: ";
                cin >> harga;

                manajemen.tambahPakaian(id, jenis, warna, ukuran, stok, harga);
                break;
            }
            case 2:
                manajemen.transaksi();
                break;
            case 3:
                manajemen.daftarPelangganBaru();
                break;
            case 4:
                manajemen.tampilkanDataPelanggan();
                break;
            case 5: {
                int idCari;
                cout << "Masukkan ID pakaian yang ingin dicari: ";
                cin >> idCari;
                manajemen.cariStokBerdasarkanID(idCari);
                break;
            }
            case 6:
                manajemen.simpanDataKeJSON("data_pakaian.json");
                break;
            case 7:
                cout << "Keluar dari program.\n";
                break;
            default:
                cout << "Pilihan tidak valid.\n";
        }

    } while (pilihan != 7);

return 0;
}