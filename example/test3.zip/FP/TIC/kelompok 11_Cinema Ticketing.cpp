#include <iostream>
#include <iomanip>
#include <string>
using namespace std;


struct Film
{
    string judul;
    string genre;
    int harga;
    string jamTayang[4];
};

struct Tiket
{
    Film filmdibeli;
    int noKursi;
};


void tampilkanDaftarFilm(Film daftarFilm[], int jumlahFilm)
{
    cout << "\n"
         << "Daftar Film yang Tersedia:\n";
    cout << "\n"
         << setw(15) << "Judul" << setw(10) << "Genre" << setw(10) << "Harga" << setw(20) << "Jam Tayang" << endl;

    for (int i = 0; i < jumlahFilm; ++i)
    {
        cout << setw(15) << daftarFilm[i].judul
             << setw(10) << daftarFilm[i].genre
             << setw(10) << daftarFilm[i].harga
             << setw(30) << daftarFilm[i].jamTayang[0] + ", " + daftarFilm[i].jamTayang[1] + ", " + daftarFilm[i].jamTayang[2] + ", " + daftarFilm[i].jamTayang[3] << endl;
    }
    cout << endl;
}

void pembayaran(Tiket tiketPembeli[], int totalHarga, int jumlahBeli)
{
    int pilihMetode;
    string metodePembayaran;

metode:
    
    cout << "\nPilih Metode Pembayaran:\n";
    cout << "1. Kartu Kredit\n";
    cout << "2. Transfer Bank\n";
    cout << "3. E-wallet\n";
    cout << "Pilih Metode (1-3): ";
    cin >> pilihMetode;

    switch (pilihMetode)
    {
    case 1:
        metodePembayaran = "Kartu Kredit\n";
        break;
    case 2:
        metodePembayaran = "Transfer Bank\n";
        break;
    case 3:
        metodePembayaran = "E-wallet\n";
        break;
    default:
        cout << "Metode pembayaran tidak valid\n";
        goto metode;
    }

    
    cout << "\nDetail Tiket Pemesanan:\n";

    for (int i = 1; i <= jumlahBeli; i++)
    {
        cout << "Tiket" << i << endl;
        cout << "Judul: "<<tiketPembeli[i-1].filmdibeli.judul<<endl;
        cout << "No Kursi: " << tiketPembeli[i - 1].noKursi<< endl;
    }

    cout << "\nTerima kasih atas pemesanan Anda!\n";
}

void kursi(int jumlahBeli, Film filmdibeli, int totalHarga)
{
    const int jumlahKursi = 32;
    int nomorKursi;
    Tiket tiketPembeli[jumlahBeli];


    cout << "Daftar Kursi:\n";
    for (int i = 1; i <= jumlahKursi; ++i)
    {
        if (i >= 1 && i <= 9)
        {
            cout << "[0" << i << "]";
        }
        else
        {
            cout << "[" << i << "]";
        }

        if (i % 4 == 0)
        {
            if (i % 8 == 0)
            {
                cout << endl;
            }
            else
            {
                cout << " ";
            }
        }
    }
    cout<<"================================="<<endl;
    cout<<"--------------Layar--------------"<<endl;
    cout<<"================================="<<endl;
    cout<<endl<<endl;

    
    for (int i = 1; i <= jumlahBeli; i++)
    {
    pilihtiket:
        cout << "Pilih kursi tiket ke-" << i << ":";
        cin >> nomorKursi;
        if (nomorKursi <= 0 || nomorKursi > 32)
        {
            cout << "kursi tidak valid";
            goto pilihtiket;
        }
        tiketPembeli[i - 1].filmdibeli = filmdibeli;
        tiketPembeli[i - 1].noKursi = nomorKursi;
    }

    pembayaran(tiketPembeli, totalHarga, jumlahBeli);
}


void pesanTiket(Film daftarFilm[], int jumlahFilm)
{
    string judulPilihan;
    int jamTayangPilihan, jumlahTiket;

    cout << "\n"
         << "Masukkan judul film yang ingin dipesan: ";
    getline(cin, judulPilihan);

    int indeksFilm = -1;
    for (int i = 0; i < jumlahFilm; ++i)
    {
        if (judulPilihan == daftarFilm[i].judul)
        {
            indeksFilm = i;
            break;
        }
    }

    if (indeksFilm == -1)
    {
        cout << "Film dengan judul tersebut tidak ditemukan.\n";
        return;
    }

    cout << "Pilih jam tayang (1-4) untuk film " << daftarFilm[indeksFilm].judul << ": ";
    cin >> jamTayangPilihan;

    if (jamTayangPilihan < 1 || jamTayangPilihan > 4)
    {
        cout << "jam tayang tidak valid.\n";
        return;
    }

    cout << "Masukkan jumlah tiket yang ingin dipesan: ";
    cin >> jumlahTiket;

    
    int totalHarga = jumlahTiket * daftarFilm[indeksFilm].harga;

    
    cout << "\n--- Informasi Pemesanan ---\n";
    cout << "Judul Film: " << daftarFilm[indeksFilm].judul << endl;
    cout << "Genre: " << daftarFilm[indeksFilm].genre << endl;
    cout << "Jam Tayang: " << daftarFilm[indeksFilm].jamTayang[jamTayangPilihan - 1] << endl;
    cout << "Jumlah Tiket: " << jumlahTiket << endl;
    cout << "Total Harga: " << totalHarga << endl;
    kursi(jumlahTiket, daftarFilm[indeksFilm], totalHarga);
}

void tiket()
{
    const int jumlahFilm = 5; 
    Film daftarFilm[jumlahFilm] = {
        {"Qodrat", "Horor", 25000, {"12:00", "15:30", "18:45", "22:15"}},
        {"172 Days", "Drama", 25000, {"13:00", "16:30", "19:45", "22:00"}},
        {"Sijjin", "Horor", 15000, {"14:00", "17:30", "20:45", "23:15"}},
        {"Budi pekerti", "Drama", 20000, {"12:30", "14:15", "17:00", "21:10"}},
        {"Waktu maghrib", "Horor", 20000, {"13:30", "15:00", "18:15", "21:00"}}};

    int pilihanMenu;

    do
    {
        cout << "Menu Pemesanan Tiket Film\n";
        cout << "(1) Tampilkan Daftar Film\n";
        cout << "(2) Pesan Tiket\n";
        cout << "Pilih nomor menu : ";
        cin >> pilihanMenu;
        cin.ignore(); 

        switch (pilihanMenu)
        {
        case 1:
            tampilkanDaftarFilm(daftarFilm, jumlahFilm);
            break;
        case 2:
            pesanTiket(daftarFilm, jumlahFilm);
            break;
        default:
            cout << "Pilihan tidak valid. Silakan coba lagi.\n";
        }
    } while (pilihanMenu != 2);
}

int main()
{
    int menu;

    do
    {
        cout << "==========Bioskop===========" << endl;
        cout << "Menu: " << endl;
        cout << "1. Pembelian" << endl;
        cout << "2. Exit" << endl;
        cout << "Pilih Menu: ";
        cin >> menu;

        system("cls");
        switch (menu)
        {
        case 1:
            tiket();
            break;
        case 2:
            break;
        default:
            cout << "Pilihan tidak valid" << endl
                 << endl;
            break;
        }
    } while (menu != 2);
    system("cls");
    cout << "Terima kasih";
}
