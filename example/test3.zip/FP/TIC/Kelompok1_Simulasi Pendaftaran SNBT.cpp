#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>

using namespace std;

int main() {
    srand(time(0));

    
    cout << "===================================\n";
    cout << "||            SNPMB              ||\n";
    cout << "||    KARTU PESERTA UTBK-SNBT    ||\n";
    cout << "||          TAHUN 2023           ||\n";
    cout << "===================================\n";



    cout << "Nomor Peserta: " << rand() % 100000000 << endl;

    cout << "Nama Peserta: ";
    string namaPeserta;
    cin.ignore(); 
    getline(cin, namaPeserta);

    cout << "Tanggal Lahir (dd-mm-yyyy): ";
    string tanggalLahir;
    getline(cin, tanggalLahir);

    cout << "Asal Sekolah: ";
    string asalSekolah;
    getline(cin, asalSekolah);

    cout << "NISN: ";
    string nisn;
    cin >> nisn;

    cout << "NPSN: ";
    string npsn;
    cin >> npsn;

    
    cout << "\nJADWAl UTBK\n";
    cout << "============\n";
    cout << "HARI & TANGGAL: ";
    int randomHARI = rand() % 3;
    switch (randomHARI) {
        case 0:
            cout << "Senin,8 Mei 2023\n";
            break;
        case 1:
            cout << "Selasa,9 Mei 2023\n";
            break;
        case 2:
            cout << "Rabu,10 Mei 2023\n";
            break;
        case 3:   
            cout << "Kamis,11 Mei 2023\n";
            break;   
        case 5:
            cout << "Jumat,12 Mei 2023\n";
            break;
        case 6:
            cout << "Sabtu,13 Mei 2023\n";
            break;
    }          
    cout << "JAM: ";
    int randomJam = rand() % 3;
    switch (randomJam) {
        case 0:
            cout << "10:00-12:00\n";
            break;
        case 1:
            cout << "12:00-14:00\n";
            break;
        case 2:
            cout << "14:00-16:00\n";
            break;
    }

    cout << "\nLOKASI UTBK\n";
    cout << "==============\n";
    cout << "PUSAT UTBK: ";
    string PUSATUTBK;
    cin >> PUSATUTBK;
    cout << "LOKASI:";
    int randomLOKASI = rand() % 3;
    switch (randomLOKASI) {
        case 0:
            cout << "Gedung ICT center\n";
            break;
        case 1:
            cout << "Gedung Fakultas teknik\n";
            break;
        case 2:
            cout << "Gedung FMIPA\n";
            break;
    }
    cout << "RUANG:";
    int randomRUANG = rand() % 6;
    switch (randomRUANG) {
        case 0:
            cout << "LAB multiguna lantai 1\n";
            break;
        case 1:
            cout << "LAB multiguna lantai 2\n";
            break;
        case 2:
            cout << "LAB multiguna lantai 3\n";
            break;
            case 3:
            cout << "LAB komputer lantai 1\n";
            break;
        case 4:
            cout << "LAB komputer lantai 2\n";
            break;
        case 5:
            cout << "LAB komputer lantai 3\n";
            break;
    }
    cout << "ALAMAT: " << PUSATUTBK <<endl;

    // Prodi
    cout << "\nPRODI\n";
    cout << "=======\n";
    cout << "Universitas Pilihan 1: ";
    string universitasPilihan1;
    cin.ignore();
    getline(cin, universitasPilihan1);

    cout << "Pilihan 1: ";
    string prodiPilihan1;
    getline(cin, prodiPilihan1);

    cout << "Universitas Pilihan 2: ";
    string universitasPilihan2;
    getline(cin, universitasPilihan2);

    cout << "Pilihan 2: ";
    string prodiPilihan2;
    getline(cin, prodiPilihan2);

   cout << "\n1. PERLENGKAPAN YANG HARUS DIBAWA PADA SAAT UJIAN:"<<endl;
   cout << "==================================================="<<endl;
   cout << "    - Kartu Tanda Peserta UTBK-SNBT 2023"<<endl;
   cout << "    - Bagi Angkatan 2023: Surat Keterangan Kelas 12 asli yang ditandatangani oleh Kepala Sekolah serta berisi nama siswa, NISN siswa, NPSN sekolah, dan paspoto siswa terbaru(3 bulan terakhir)"<<endl;
   cout << "    - Bagi lulusan 2021 dan 2022: Ijazah/Lega3lisir Ijazah"<<endl;
   cout << "    - Identitas diri lain seperti KTP atau SIM"<<endl;
   cout << "2. LOKASI UTBK HARUS DILIHAT SATU HARI SEBELUM PELAKSANAAN UJIAN."<<endl;
   cout << "==============================================================="<<endl;
   cout << "3. MENGENAKAN MASKER PADA SAAT BERADA DI LOKASI UJIAN."<<endl;
   cout << "===================================================="<<endl;
   cout << "4. PESERTA HARUS DALAM KONDISI SEHAT"<<endl;
   cout << "==================================="<<endl;




    return 0;
}
