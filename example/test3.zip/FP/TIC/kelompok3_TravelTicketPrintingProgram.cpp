#include <iostream>
#include <fstream>
#include <string>
using namespace std;

// PROGRAM FUNGSI

struct identitas {
    string nama;
    string noTelepon;
    int umur;
};

struct date {
    int tanggal;
    int bulan;
    int tahun;
};

struct dataTravel {
    identitas customer;
    int noTicket;
    int biayaPerhari;
    date berangkat;
    date pulang;
    string jamBerangkat;
    string titikAwal;
    string tujuanWisata;
    int durasiTravel;
};

int biaya(int durasi, int biaya) {
    int total = biaya * durasi;
    return total;
}

int hitungBiayaTotal(dataTravel pelanggan[], int index, int jumlahTiket, int totalBiaya) {
    if (index == jumlahTiket) {
        return totalBiaya;
    }

    int biayaPerjalanan = biaya(pelanggan[index].durasiTravel, pelanggan[index].biayaPerhari);
    totalBiaya += biayaPerjalanan;

    return hitungBiayaTotal(pelanggan, index + 1, jumlahTiket, totalBiaya);
}


string bulan(int a) {
    string b;
    switch (a) {
        case 1 :
            b = "Januari";
            break;
        case 2 :
            b = "Februari";
            break;
        case 3 :
            b = "Maret";
            break;
        case 4 :
            b = "April";
            break;
        case 5 :
            b = "Mei";
            break;
        case 6 :
            b = "Juni";
            break;
        case 7 :
            b = "Juli";
            break;
        case 8 :
            b = "Agustus";
            break;
        case 9 :
            b = "September";
            break;
        case 10 :
            b = "Oktober";
            break;
        case 11 :
            b = "November";
            break;
        case 12 :
            b = "Desember";
            break;
    }
    return b;
}

// PROGRAM INPUT

int main() {
    ofstream outputFile("output.txt");

    int ptrawal;

    cout << "Masukkan Jumlah Orang : ";
    int jumlahTiket;
    cin >> jumlahTiket;

    dataTravel pelanggan[jumlahTiket];

    for (int i = 0; i < jumlahTiket; i++) {
        cout << endl;
        cout << "===================================" << endl;
        cout << "          DATA ORANG KE " << i + 1 << endl;
        cout << "===================================" << endl;

        cin.ignore();
        cout << "Nama          : ";
        getline(cin,pelanggan[i].customer.nama);

        cout << "No. Telpon    : ";
        cin >> pelanggan[i].customer.noTelepon;

        cout << endl;
        cout << "- Tarif Perhari Berdasarkan Umur -" << endl;
        cout << "0 - 10 tahun  = Rp 20.000" << endl;
        cout << "11 - 17 tahun = Rp 50.000" << endl;
        cout << "18 keatas     = Rp 80.000" << endl;
        cout << endl;

        cout << "Masukkan Umur : ";
        cin >> pelanggan[i].customer.umur;

        while (true) {
            if (cin.fail() || pelanggan[i].customer.umur < 0) {
                cin.clear();
                cin.ignore();
                cout << "Umur tidak valid, harap masukkan ulang : ";
                cin >> pelanggan[i].customer.umur;
            } else if (pelanggan[i].customer.umur < 11) {
                pelanggan[i].biayaPerhari = 20000;
                break;
            } else if (pelanggan[i].customer.umur < 18) {
                pelanggan[i].biayaPerhari = 50000;
                break;
            } else {
                pelanggan[i].biayaPerhari = 80000;
                break;
            }
        }

        cout << endl;

        if (i == 0) {
            int inputtanggal, inputbulan, inputtahun;

            cout << "Tahun Keberangkatan [2023 - 2025] : ";
            cin >> inputtahun;

            while (cin.fail() || inputtahun < 2023 || inputtahun > 2025) {
                cin.clear();
                cin.ignore();
                cout << "Input tahun salah, harap masukkan ulang : ";
                cin >> inputtahun;
            }

            pelanggan[i].berangkat.tahun = inputtahun;
            pelanggan[i].pulang.tahun = pelanggan[i].berangkat.tahun;
            
            cout << endl;
            cout << "     - Pilihan Bulan Keberangkatan -     " << endl;
            cout << "1.Januari      2.Februari      3.Maret" << endl;
            cout << "4.April        5.Mei           6.Juni" << endl;
            cout << "7.Juli         8.Agustus       9.September" << endl;
            cout << "10.Oktober     11.November     12.Desember" << endl; 
            cout << endl;

            cout << "Pilih Bulan [1 - 12] : ";
            cin >> inputbulan;

            while (true) {
                if (cin.fail() || inputbulan < 1 || inputbulan > 12) {
                    cin.clear();
                    cin.ignore();
                    cout << "Input bulan salah, harap masukkan ulang : ";
                    cin >> inputbulan;
                } else if (inputbulan == 1 || inputbulan == 3 || inputbulan == 5 || inputbulan == 7 || inputbulan == 8 || inputbulan == 10 || inputbulan == 12) {
                    pelanggan[i].berangkat.bulan = inputbulan;

                    cout << "Pilih Tanggal [1 - 31] : ";
                    cin >> inputtanggal;
                    while (true) {
                        if (cin.fail() || inputtanggal < 1 || inputtanggal > 31) {
                            cin.clear();
                            cin.ignore();
                            cout << "Input tanggal salah, harap masukkan ulang : ";
                            cin >> inputtanggal;
                        } else {
                            pelanggan[i].berangkat.tanggal = inputtanggal;
                            break;
                        }
                    }
                    break;
                } else if (inputbulan == 4 || inputbulan == 6 || inputbulan == 9 || inputbulan == 11) {
                    pelanggan[i].berangkat.bulan = inputbulan;

                    cout << "Pilih Tanggal [1 - 30] : ";
                    cin >> inputtanggal;
                    while (true) {
                        if (cin.fail() || inputtanggal < 1 || inputtanggal > 30) {
                            cin.clear();
                            cin.ignore();
                            cout << "Input tanggal salah, harap masukkan ulang : ";
                            cin >> inputtanggal;
                        } else {
                            pelanggan[i].berangkat.tanggal = inputtanggal;
                            break;
                        }
                    }
                    break;
                } else if (inputbulan == 2) {
                    pelanggan[i].berangkat.bulan = inputbulan;
                    
                    if (inputtahun % 4 == 0) {
                        cout << "Pilih Tanggal [1 - 29] : ";
                        cin >> inputtanggal;
                        while (true) {
                            if (cin.fail() || inputtanggal < 1 || inputtanggal > 29) {
                            cin.clear();
                            cin.ignore();
                            cout << "Input tanggal salah, harap masukkan ulang : ";
                            cin >> inputtanggal;
                        } else {
                            pelanggan[i].berangkat.tanggal = inputtanggal;
                            break;
                        }
                        }
                        break;
                    } else {
                        cout << "Pilih Tanggal [1 - 28] : ";
                        cin >> inputtanggal;
                        while (true) {
                            if (cin.fail() || inputtanggal < 1 || inputtanggal > 28) {
                            cin.clear();
                            cin.ignore();
                            cout << "Input tanggal salah, harap masukkan ulang : ";
                            cin >> inputtanggal;
                        } else {
                            pelanggan[i].berangkat.tanggal = inputtanggal;
                            break;
                        }
                        }
                        break;
                    }
                }
            }

            pelanggan[i].pulang.bulan = pelanggan[i].berangkat.bulan;

            cout << endl;
            cout << "- Pilihan Jam Keberangkatan -" << endl;
            cout << "1. Pukul 09:00 WIB" << endl;
            cout << "2. Pukul 12:00 WIB" << endl;
            cout << "3. Pukul 15:00 WIB" << endl;
            cout << "4. Pukul 18:00 WIB" << endl; 
            cout << endl;

            cout << "Masukkan Pilihan [1 - 4]: ";
            int masukkanangka;
            cin >> masukkanangka;

            while (true) {
                if (cin.fail() || masukkanangka < 1 || masukkanangka > 4) {
                    cin.clear();
                    cin.ignore();
                    cout << "Input salah, harap masukkan ulang : ";
                    cin >> masukkanangka;
                } else if (masukkanangka == 1) {
                    pelanggan[i].jamBerangkat = "09:00 WIB";
                    break;
                } else if (masukkanangka == 2) {
                    pelanggan[i].jamBerangkat = "12:00 WIB";
                    break;
                } else if (masukkanangka == 3) {
                    pelanggan[i].jamBerangkat = "15:00 WIB";
                    break;
                } else if (masukkanangka == 4) {
                    pelanggan[i].jamBerangkat = "18:00 WIB";
                    break;
                }
            }
            
            cout << endl;
            cout << "- Pilihan Lokasi Awal -" << endl;
            cout << "1.Batu         2.Blitar          3.Kediri" << endl;
            cout << "4.Madiun       5.Malang          6.Mojokerto" << endl;
            cout << "7.Pasuruan     8.Probolinggo     9.Surabaya" << endl;
            cout << endl;

            cout << "Lokasi Awal    : ";
            int titikawal;
            cin >> titikawal;

            while (true) {
                if (cin.fail() || titikawal < 1 || titikawal > 9) {
                    cin.clear();
                    cin.ignore();
                    cout << "Input tidak valid, harap masukkan ulang : ";
                    cin >> titikawal;
                } else {
                    if (titikawal == 1) {
                        pelanggan[i].titikAwal = "Batu";
                        break;
                    } else if (titikawal == 2) {
                        pelanggan[i].titikAwal = "Blitar";
                        break;
                    } else if (titikawal == 3) {
                        pelanggan[i].titikAwal = "Kediri";
                        break;
                    } else if (titikawal == 4) {
                        pelanggan[i].titikAwal = "Madiun";
                        break;
                    } else if (titikawal == 5) {
                        pelanggan[i].titikAwal = "Malang";
                        break;
                    } else if (titikawal == 6) {
                        pelanggan[i].titikAwal = "Mojokerto";
                        break;
                    } else if (titikawal == 7) {
                        pelanggan[i].titikAwal = "Pasuruan";
                        break;
                    } else if (titikawal == 8) {
                        pelanggan[i].titikAwal = "Probolinggo";
                        break;
                    } else if (titikawal == 9) {
                        pelanggan[i].titikAwal = "Surabaya";
                        break;
                    }   
                }
            }

            ptrawal = titikawal;

            cout << endl;
            cout << "- Pilihan Lokasi Akhir -" << endl;
            cout << "1.Batu         2.Blitar          3.Kediri" << endl;
            cout << "4.Madiun       5.Malang          6.Mojokerto" << endl;
            cout << "7.Pasuruan     8.Probolinggo     9.Surabaya" << endl;
            cout << endl;
            
            cout << "Tujuan Wisata  : ";
            int titikakhir;
            cin >> titikakhir;

            while (true) {
                if (cin.fail() || titikakhir < 1 || titikakhir > 9) {
                    cin.clear();
                    cin.ignore();
                    cout << "Input tidak valid, harap masukkan ulang : ";
                    cin >> titikakhir;
                } else if (titikakhir == titikawal) {
                    cout << "Tujuan wisata tidak boleh sama dengan titik awal, masukkan lagi : ";
                    cin >> titikakhir;
                } else {
                    if (titikakhir == 1) {
                        pelanggan[i].tujuanWisata = "Batu";
                        break;
                    } else if (titikakhir == 2) {
                        pelanggan[i].tujuanWisata = "Blitar";
                        break;
                    } else if (titikakhir == 3) {
                        pelanggan[i].tujuanWisata = "Kediri";
                        break;
                    } else if (titikakhir == 4) {
                        pelanggan[i].tujuanWisata = "Madiun";
                        break;
                    } else if (titikakhir == 5) {
                        pelanggan[i].tujuanWisata = "Malang";
                        break;
                    } else if (titikakhir == 6) {
                        pelanggan[i].tujuanWisata = "Mojokerto";
                        break;
                    } else if (titikakhir == 7) {
                        pelanggan[i].tujuanWisata = "Pasuruan";
                        break;
                    } else if (titikakhir == 8) {
                        pelanggan[i].tujuanWisata = "Probolinggo";
                        break;
                    } else if (titikakhir == 9) {
                        pelanggan[i].tujuanWisata = "Surabaya";
                        break;
                    }   
                }
            }
            
            cout << endl;
            cout << "Travel Berapa Hari [1 - 100] : ";
            cin >> pelanggan[i].durasiTravel;
            while (cin.fail() || pelanggan[i].durasiTravel < 1 || pelanggan[i].durasiTravel > 100) {
                cin.clear();
                cin.ignore();
                cout << "Input salah, harap masukkan ulang : ";
                cin >> pelanggan[i].durasiTravel;
            }

            cout << endl;
        } else {
            pelanggan[i].berangkat.tahun = pelanggan[0].berangkat.tahun;
            pelanggan[i].pulang.tahun = pelanggan[0].pulang.tahun;
            pelanggan[i].berangkat.bulan = pelanggan[0].berangkat.bulan;
            pelanggan[i].pulang.bulan = pelanggan[0].pulang.bulan;
            pelanggan[i].berangkat.tanggal = pelanggan[0].berangkat.tanggal;
            pelanggan[i].jamBerangkat = pelanggan[0].jamBerangkat;
            pelanggan[i].titikAwal = pelanggan[0].titikAwal;
            pelanggan[i].tujuanWisata = pelanggan[0].tujuanWisata;
            pelanggan[i].durasiTravel = pelanggan[0].durasiTravel;
        }
    }

    cout << "anda ingin merubah tujuan wisata? [Y / N] : ";
    char ubahTujuan;
    cin >> ubahTujuan;

    if (ubahTujuan == 'Y' || ubahTujuan == 'y') {
        string *ptrTujuan = &pelanggan[0].tujuanWisata;
        int ptrakhir;
        cout << "Mengubah Tujuan Wisata Ke : ";
        cin >> ptrakhir;

        while (true) {
            if (cin.fail() || ptrakhir < 1 || ptrakhir > 9) {
                cin.clear();
                cin.ignore();
                cout << "Input tidak valid, harap masukkan ulang : ";
                cin >> ptrakhir;
            } else if (ptrakhir == ptrawal) {
                cout << "Tujuan wisata tidak boleh sama dengan titik awal, masukkan lagi : ";
                cin >> ptrakhir;
            } else {
                if (ptrakhir == 1) {
                    *ptrTujuan = "Batu";
                    break;
                } else if (ptrakhir == 2) {
                    *ptrTujuan = "Blitar";
                    break;
                } else if (ptrakhir == 3) {
                    *ptrTujuan = "Kediri";
                    break;
                } else if (ptrakhir == 4) {
                    *ptrTujuan = "Madiun";
                    break;
                } else if (ptrakhir == 5) {
                    *ptrTujuan = "Malang";
                    break;
                } else if (ptrakhir == 6) {
                    *ptrTujuan = "Mojokerto";
                    break;
                } else if (ptrakhir == 7) {
                    *ptrTujuan = "Pasuruan";
                    break;
                } else if (ptrakhir == 8) {
                    *ptrTujuan = "Probolinggo";
                    break;
                } else if (ptrakhir == 9) {
                    *ptrTujuan = "Surabaya";
                    break;
                }   
            }
        }
        cout << endl << "program selsai";
    } else {
        cout << "program selsai";
    }

// PROGRAM OUTPUT

    for (int i = 0; i < jumlahTiket; i++) {
        outputFile << "===========================================================" << endl;
        outputFile << "                     - TRAVEL TICKET -                     " << endl;
        outputFile << "===========================================================" << endl << endl;
        outputFile << "Nama                     : " << pelanggan[i].customer.nama << endl;
        outputFile << "No. Telepon Pelanggan    : " << pelanggan[i].customer.noTelepon << endl;
        outputFile << "Umur Pelangan            : " << pelanggan[i].customer.umur << endl << endl;
        outputFile << "Rute Perjalanan          : " << pelanggan[i].titikAwal << " - " << pelanggan[i].tujuanWisata << endl;
        outputFile << "Nomor Tiket              : 0" << i + 1 << pelanggan[i].berangkat.tahun << pelanggan[i].berangkat.tanggal << pelanggan[i].berangkat.bulan << endl;
        outputFile << "Jadwal Keberangkatan     : " << pelanggan[i].berangkat.tanggal << " " << bulan(pelanggan[i].berangkat.bulan) << " " << pelanggan[i].berangkat.tahun << endl;
        outputFile << "Jam Keberangkatan        : " << pelanggan[i].jamBerangkat << endl << endl;

        if (pelanggan[i].berangkat.bulan == 1 || pelanggan[i].berangkat.bulan == 3 || pelanggan[i].berangkat.bulan == 5 || pelanggan[i].berangkat.bulan == 7 || pelanggan[i].berangkat.bulan == 8 || pelanggan[i].berangkat.bulan == 10 || pelanggan[i].berangkat.bulan == 12) {
            pelanggan[i].berangkat.tanggal += pelanggan[i].durasiTravel;
            if (pelanggan[i].berangkat.tanggal > 31) {
                pelanggan[i].pulang.tanggal = pelanggan[i].berangkat.tanggal - 31;
                pelanggan[i].pulang.bulan += 1;
            } else {
                pelanggan[i].pulang.tanggal = pelanggan[0].berangkat.tanggal;
            }
        } else if (pelanggan[i].berangkat.bulan == 4 || pelanggan[i].berangkat.bulan == 6 || pelanggan[i].berangkat.bulan == 9 || pelanggan[i].berangkat.bulan == 11) {
            pelanggan[i].berangkat.tanggal += pelanggan[i].durasiTravel;
            if (pelanggan[i].berangkat.tanggal > 30) {
                pelanggan[i].pulang.tanggal = pelanggan[i].berangkat.tanggal - 30;
                pelanggan[i].pulang.bulan += 1;
            } else {
                pelanggan[i].pulang.tanggal = pelanggan[0].berangkat.tanggal;
            }
        } else if (pelanggan[i].berangkat.bulan == 2) {
            pelanggan[i].berangkat.tanggal += pelanggan[i].durasiTravel;
            if (pelanggan[i].berangkat.tahun % 4 == 0) {
                if (pelanggan[i].berangkat.tanggal > 29) {
                pelanggan[i].pulang.tanggal = pelanggan[i].berangkat.tanggal - 29;
                pelanggan[i].pulang.bulan += 1;
                } else {
                    pelanggan[i].pulang.tanggal = pelanggan[0].berangkat.tanggal;
                }
            } else {
                if (pelanggan[i].berangkat.tanggal > 28) {
                pelanggan[i].pulang.tanggal = pelanggan[i].berangkat.tanggal - 28;
                pelanggan[i].pulang.bulan += 1;
                } else {
                    pelanggan[i].pulang.tanggal = pelanggan[0].berangkat.tanggal;
                }
            }
        }

        if (pelanggan[i].pulang.bulan > 12) {
            pelanggan[i].pulang.bulan = pelanggan[i].pulang.bulan - 12;
            pelanggan[i].pulang.tahun += 1;
        }

        outputFile << "Estimasi Pulang          : " << pelanggan[i].pulang.tanggal << " " << bulan(pelanggan[i].pulang.bulan) << " " << pelanggan[i].pulang.tahun << endl;

        outputFile << "Lama Perjalanan          : " << pelanggan[i].durasiTravel << " Hari" << endl;

        outputFile << "Biaya                    : Rp." << biaya(pelanggan[i].durasiTravel, pelanggan[i].biayaPerhari) << endl << endl;
    }

    outputFile << "===========================================================" << endl;
    outputFile << "Biaya Total              : Rp." << hitungBiayaTotal(pelanggan, 0, jumlahTiket, 0) << endl;
    outputFile << "===========================================================";

    outputFile.close();

    return 0;
}