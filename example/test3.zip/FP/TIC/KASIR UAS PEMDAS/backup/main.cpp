#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string>
#include <iomanip> // fixed << setprecision(3) --> menampilkan 3 angka dibelakang koma (line 111)

using namespace std;

const int TOTAL = 20;
int sizeMakanan, sizeMinuman, sizeSnack, sizeRiwayatTransaksi;
int cartSize = 0;
float totalAmount = 0;

string riwayatTransaksi[100];

struct dataBarang
{ // Menampung data barang (nama, kuantitas, harga)
    string namaBarang;
    int kuantitas;
    float harga;
};

dataBarang makanan[TOTAL], snack[TOTAL], minuman[TOTAL], cart[TOTAL]; // Array data barang

// Prototipe fungsi
void boot();                                                                                                           // Inisialisasi dan baca data awal
void login();                                                                                                          // login page
void adminInterface();                                                                                                 // Interface admin
void cekItems();                                                                                                       // cek items
void addItems();                                                                                                       // add items
void removeItems();                                                                                                    // remove items
int paymentOpt(int opt, int cartSize);                                                                                 // payment
void saveRiwayatTransaksi(int jarak, bool isOffline, int cartSize, dataBarang cart[], float pajak, float deliveryFee); // Save Riwayat Transaksi
void customerInterface();                                                                                              // interface customer

void saveData(); // Save Data

int main()
{
    boot(); // Jalankan fungsi inisialisasi
    system("cls");
    login(); // jalankan fungsi login page

    return 0;
}

void boot()
{ // Fungsi inisialisasi dan baca data
    system("cls");

    cout << "Booting.." << endl;

    // bacak SIZE MAKANAN, MINUMAN DAN SNACK

    ifstream SIZE("SIZE.txt");

    if (!SIZE.is_open())
    {
        cout << "\ngagal membuka database SIZE.." << endl;
        exit(EXIT_FAILURE);
    }

    SIZE >> sizeMakanan >> sizeMinuman >> sizeSnack >> sizeRiwayatTransaksi;

    SIZE.close();

    // Baca nama makanan dari file

    ifstream namaMakanan("makanan.txt");
    if (!namaMakanan.is_open())
    {
        cout << "\ngagal membuka database makanan.." << endl;
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < sizeMakanan; i++)
    {
        getline(namaMakanan, makanan[i].namaBarang);
    }
    namaMakanan.close();

    // Baca harga makanan dari file

    ifstream hargaMakanan("hargaMakanan.txt");
    if (!hargaMakanan.is_open())
    {
        cout << "\ngagal membuka database harga makanan.." << endl;
        exit(EXIT_FAILURE);
    }
    else
    {
        for (int i = 0; i < sizeMakanan; i++)
        {
            hargaMakanan >> makanan[i].harga;
        }
        hargaMakanan.close();
    }

    cout << "\nMAKANAN = DONE";

    ifstream namaMinuman("minuman.txt");
    if (!namaMinuman.is_open())
    {
        cout << "\ngagal membuka database minuman.." << endl;
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < sizeMinuman; i++)
    {
        getline(namaMinuman, minuman[i].namaBarang);
    }
    namaMinuman.close();

    ifstream hargaMinuman("hargaMinuman.txt");
    if (!hargaMinuman.is_open())
    {
        cout << "\ngagal membuka database harga minuman.." << endl;
        exit(EXIT_FAILURE);
    }
    else
    {
        for (int i = 0; i < sizeMinuman; i++)
        {
            hargaMinuman >> minuman[i].harga;
        }
        hargaMinuman.close();
    }

    cout << "\nMINUMAN = DONE";

    ifstream namaSnack("snack.txt");
    if (!namaSnack.is_open())
    {
        cout << "\ngagal membuka database snack.." << endl;
        exit(EXIT_FAILURE);
    }
    else
    {
        for (int i = 0; i < sizeSnack; i++)
        {
            getline(namaSnack, snack[i].namaBarang);
        }
        namaSnack.close();
    }

    // Baca harga snack dari file

    ifstream hargaSnack("hargaSnack.txt");
    if (!hargaSnack.is_open())
    {
        cout << "\ngagal membuka database harga snack.." << endl;
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < sizeSnack; i++)
    {
        hargaSnack >> snack[i].harga;
    }
    hargaSnack.close();

    cout << "\nSNACK = DONE";

    // baca file riwayat transaksi

    ifstream history("riwayatTransaksi.txt");
    if (!history.is_open())
    {
        cout << "\ngagal membuka database riwayat transaksi.." << endl;
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < TOTAL; i++)
    {
        getline(history, riwayatTransaksi[i]);
    }
    history.close();

    cout << "\nRIWAYAT TRANSAKSI = DONE\n";

    cout << "\nSuccess.." << endl;
    system("pause");
}

void login()
{
    system("cls");
    int opt = 0;
    do
    {
        cout << "\nLOG-IN AS: "; // Tampilkan menu login
        cout << "\n1. ADMIN";
        cout << "\n2. CUSTOMER";
        cout << "\n3. EXIT";
        cout << "\nOPTION (1 - 3): ";
        cin >> opt;

        switch (opt)
        {
        case 1:
            // Kode untuk fungsi admin
            adminInterface();
            break;
        case 2:
            // Kode untuk fungsi customer
            customerInterface();
            return;

        case 3:
            cout << "\nEXIT..";
            exit(EXIT_SUCCESS); // Keluar program

        default:
            system("cls");
            cout << "\n"
                 << opt << " is unavailable" << endl; // Pilihan invalid
            break;
        }
    } while (opt != 3);
}

void adminInterface()
{
    system("cls");
    int opt = 0;

    cout << "\n=== ADMIN MENU ==="; // Tampilkan menu login
    cout << "\n1. CEK ITEM";
    cout << "\n2. RIWAYAT TRANSAKSI";
    cout << "\n3. BACK";
    cout << "\nOPTION (1-3): ";
    cin >> opt;

    if (opt == 1)
    {
        cekItems();
    }
    else if (opt == 2)
    {
        system("cls");

        if (sizeRiwayatTransaksi == 0)
        {
            cout << "Belum ada transaksi..\n\n";
        }
        else
        {
            cout << "\n=============================== HISTORY ====================================\n";
            for (int i = 0; i < sizeRiwayatTransaksi; i++)
            {
                cout << riwayatTransaksi[i] << endl;
            }
        }

        system("pause");

        login();
    }
    else if (opt == 3)
    {
        login();
    }
    else
    {
        adminInterface();
    }
}

void cekItems()
{
    system("cls");
    int opt = 0;
    do
    {
        cout << "=== MAKANAN ===" << endl; // output makanan
        for (int i = 0; i < sizeMakanan; i++)
        {
            cout << i + 1 << ". " << makanan[i].namaBarang << fixed << setprecision(3) << " at Rp" << makanan[i].harga << endl;
        }

        cout << "\n=== MINUMAN ===" << endl; // output minuman
        for (int i = 0; i < sizeMinuman; i++)
        {
            cout << i + 1 << ". " << minuman[i].namaBarang << fixed << setprecision(3) << " at Rp" << minuman[i].harga << endl;
        }

        cout << "\n=== SNACK ===" << endl; // output snack
        for (int i = 0; i < sizeSnack; i++)
        {
            cout << i + 1 << ". " << snack[i].namaBarang << fixed << setprecision(3) << " at Rp" << snack[i].harga << endl;
        }

        cout << "\n=== ADMIN MENU ===";
        cout << "\n1. CARI ITEM";
        cout << "\n2. ADD ITEM";
        cout << "\n3. REMOVE ITEM";
        cout << "\n4. BACK";
        cout << "\nOPTION (1 - 4): ";

        cin >> opt;

        switch (opt)
        {
        case 1:
            // fitur search
            cout << "\nfitur search..";
            login();
            break;
        case 2:
            // ADD ITEM
            addItems();
            return;
            break;
        case 3:
            // REMOVE ITEM
            removeItems();
            return;
            break;
        case 4:
            cout << "\nGOING BACK..";
            adminInterface();
            break;
        default:
            system("cls");
            cout << "\n"
                 << opt << " is unavailable" << endl; // Pilihan invalid
            break;
        }

        cin >> opt;
    } while (opt != 4);
}

void addItems()
{
    // fungsi add items

    system("cls");

    int opt = 0;

    string makananBaru, snackBaru, minumanBaru;
    float hargaMakananBaru, hargaSnackBaru, hargaMinumanBaru;

    cout << "\n=== ADD ITEMS ===";
    cout << "\n1. MAKANAN";
    cout << "\n2. MINUMAN";
    cout << "\n3. SNACK";
    cout << "\n4. BACK";
    cout << "\nOPTION (1-4): ";
    cin >> opt;

    switch (opt)
    {
    case 1:

        // Tambah makanan baru

        cout << "\nMasukkan nama makanan: ";
        cin.ignore();
        getline(cin, makananBaru);

        cout << "Masukkan harga makanan: ";
        cin >> hargaMakananBaru;

        sizeMakanan++;
        makanan[sizeMakanan - 1].namaBarang = makananBaru;
        makanan[sizeMakanan - 1].harga = hargaMakananBaru;

        // savedata
        saveData();

        cout << "\nBerhasil menambahkan makanan" << endl;
        system("pause");

        return cekItems();
    case 2:
        cout << "\nMasukkan nama minuman: ";
        cin.ignore();
        getline(cin, minumanBaru);

        cout << "Masukkan harga minuman: ";
        cin >> hargaMinumanBaru;

        sizeMinuman++;
        minuman[sizeMinuman - 1].namaBarang = minumanBaru;
        minuman[sizeMinuman - 1].harga = hargaMinumanBaru;

        // savedata
        saveData();

        cout << "\nBerhasil menambahkan minuman" << endl;
        system("pause");

        return cekItems();
    case 3:

        // Tambah snack baru

        cout << "\nMasukkan nama snack: ";
        cin.ignore();
        getline(cin, snackBaru);

        cout << "Masukkan harga snack: ";
        cin >> hargaSnackBaru;

        sizeSnack++;
        makanan[sizeSnack - 1].namaBarang = snackBaru;
        makanan[sizeSnack - 1].harga = hargaSnackBaru;

        // savedata
        saveData();

        cout << "\nBerhasil menambahkan snack" << endl;
        system("pause");

        return cekItems();
    case 4:
        cout << "\nGOING BACK..";
        return cekItems();
    default:
        addItems();
    }
}

void removeItems()
{
    system("cls");

    int opt = 0;
    int del = 0;

    cout << "\n=== REMOVE ITEMS ===";
    cout << "\n1. MAKANAN";
    cout << "\n2. MINUMAN";
    cout << "\n3. SNACK";
    cout << "\n4. BACK";
    cout << "\nOPTION (1-4): ";
    cin >> opt;

    switch (opt)
    {
    case 1:
        system("cls");

        // menghapus makanan dari list

        cout << "=== MAKANAN ===" << endl; // output makanan
        for (int i = 0; i < sizeMakanan; i++)
        {
            cout << i + 1 << ". " << makanan[i].namaBarang << fixed << setprecision(3) << " at Rp" << makanan[i].harga << endl;
        }

        cout << "PILIH ITEM YANG INGIN DIHAPUS: ";
        cin >> del;

        for (int i = del; i < sizeMakanan; i++)
        {
            makanan[i - 1].namaBarang = makanan[i].namaBarang;
            makanan[i - 1].harga = makanan[i].harga;
        }

        sizeMakanan--;

        // savedata
        saveData();

        cout << "\nItems berhasil dihapus..";
        system("pause");

        return cekItems();
    case 2:
        cout << "=== MINUMAN ===" << endl; // output makanan
        for (int i = 0; i < sizeMinuman; i++)
        {
            cout << i + 1 << ". " << minuman[i].namaBarang << fixed << setprecision(3) << " at Rp" << minuman[i].harga << endl;
        }

        cout << "PILIH ITEM YANG INGIN DIHAPUS: ";
        cin >> del;

        for (int i = del; i < sizeMinuman; i++)
        {
            minuman[i - 1].namaBarang = minuman[i].namaBarang;
            minuman[i - 1].harga = minuman[i].harga;
        }

        sizeMinuman--;

        // savedata
        saveData();

        cout << "\nItems berhasil dihapus..";
        system("pause");
        return cekItems();
        break;
    case 3:
        system("cls");
        int del;

        // menghapus snack dari list

        cout << "=== SNACK ===" << endl; // output snack
        for (int i = 0; i < sizeSnack; i++)
        {
            cout << i + 1 << ". " << snack[i].namaBarang << fixed << setprecision(3) << " at Rp" << snack[i].harga << endl;
        }

        cout << "PILIH ITEM YANG INGIN DIHAPUS: ";
        cin >> del;

        for (int i = del; i < sizeSnack; i++)
        {
            snack[i - 1].namaBarang = snack[i].namaBarang;
            snack[i - 1].harga = snack[i].harga;
        }

        sizeSnack--;

        // savedata
        saveData();

        cout << "\nItems berhasil dihapus..";
        system("pause");

        return cekItems();
        break;
    case 4:
        cout << "\nGOING BACK..";
        return cekItems();
    default:
        addItems();
    }
}

void customerInterface()
{

    int cartSize = 0;
    float kuantitas = 0;
    int opt;
    totalAmount = 0;

    do
    {
        system("cls");
        kuantitas = 0;
        opt = 0;

        cout << "\n=== PILIH MENU === ";
        cout << "\n1. MAKANAN";
        cout << "\n2. MINUMAN";
        cout << "\n3. SNACK";
        cout << "\n4. VIEW CART";
        cout << "\n5. CHECK OUT";
        cout << "\n6. EXIT";
        cout << "\nOPTION (1-6): ";
        cin >> opt;

        switch (opt)
        {
        case 1: // Order makanan
            system("cls");
            cout << "\n=== MAKANAN ===\n";
            for (int i = 0; i < sizeMakanan; i++)
            {
                cout << i + 1 << ". " << makanan[i].namaBarang << " at Rp" << fixed << setprecision(3) << makanan[i].harga << endl;
            }

            cout << "\nMasukkan nomor makanan: ";
            cin >> opt;

            cout << "Masukkan berapa banyak: ";
            cin >> kuantitas;

            if (opt > 0 && opt <= sizeMakanan)
            {
                bool found = false;

                for (int i = 0; i < cartSize; i++)
                {
                    if (makanan[opt - 1].namaBarang == cart[i].namaBarang)
                    {
                        found = true;
                        // Jika makanan sudah ada dalam keranjang, tinggal tambahkan kuantitas
                        cart[i].kuantitas += kuantitas;
                        // KALKULASI TOTAL HARGA
                        totalAmount += cart[i].harga * kuantitas;
                        cout << "\nBerhasil menambahkan " << makanan[opt - 1].namaBarang << " ke keranjang.\n";
                        system("pause");
                        break;
                    }
                }

                if (!found)
                {
                    // Jika makanan belum ada dalam keranjang, tambahkan makanan baru
                    cart[cartSize].namaBarang = makanan[opt - 1].namaBarang;
                    cart[cartSize].harga = makanan[opt - 1].harga;
                    cart[cartSize].kuantitas = kuantitas;
                    cartSize++;

                    // KALKULASI TOTAL HARGA
                    totalAmount += cart[cartSize - 1].harga * kuantitas;

                    cout << "\nBerhasil menambahkan " << makanan[opt - 1].namaBarang << " ke keranjang.\n";
                    system("pause");
                }
            }
            else
            {
                cout << "\nInvalid option. Please select a valid food item number.\n";
            }
            break;
        case 2:
            system("cls");
            cout << "\n=== MINUMAN ===\n";
            for (int i = 0; i < sizeMinuman; i++)
            {
                cout << i + 1 << ". " << minuman[i].namaBarang << " at Rp" << fixed << setprecision(3) << minuman[i].harga << endl;
            }

            cout << "\nMasukkan nomor minuman: ";
            cin >> opt;

            cout << "Masukkan berapa banyak: ";
            cin >> kuantitas;

            if (opt > 0 && opt <= sizeMinuman)
            {
                bool found = false;

                for (int i = 0; i < cartSize; i++)
                {
                    if (minuman[opt - 1].namaBarang == cart[i].namaBarang)
                    {
                        found = true;
                        // Jika snack sudah ada dalam keranjang, tinggal tambahkan kuantitas
                        cart[i].kuantitas += kuantitas;
                        // KALKULASI TOTAL HARGA
                        totalAmount += cart[i].harga * kuantitas;
                        cout << "\nBerhasil menambahkan " << minuman[opt - 1].namaBarang << " ke keranjang.\n";
                        system("pause");
                        break;
                    }
                }

                if (!found)
                {
                    // Jika minuman belum ada dalam keranjang, tambahkan minuman baru
                    cart[cartSize].namaBarang = minuman[opt - 1].namaBarang;
                    cart[cartSize].harga = minuman[opt - 1].harga;
                    cart[cartSize].kuantitas = kuantitas;
                    cartSize++;

                    // KALKULASI TOTAL HARGA
                    totalAmount += cart[cartSize - 1].harga * kuantitas;

                    cout << "\nBerhasil menambahkan " << minuman[opt - 1].namaBarang << " ke keranjang.\n";
                    system("pause");
                }
            }
            else
            {
                cout << "\nInvalid option. Please select a valid food item number.\n";
            }
            break;
        case 3: // Order snack
            system("cls");
            cout << "\n=== SNACK ===\n";
            for (int i = 0; i < sizeSnack; i++)
            {
                cout << i + 1 << ". " << snack[i].namaBarang << " at Rp" << fixed << setprecision(3) << snack[i].harga << endl;
            }

            cout << "\nMasukkan nomor snack: ";
            cin >> opt;

            cout << "Masukkan berapa banyak: ";
            cin >> kuantitas;

            if (opt > 0 && opt <= sizeSnack)
            {
                bool found = false;

                for (int i = 0; i < cartSize; i++)
                {
                    if (snack[opt - 1].namaBarang == cart[i].namaBarang)
                    {
                        found = true;
                        // Jika snack sudah ada dalam keranjang, tinggal tambahkan kuantitas
                        cart[i].kuantitas += kuantitas;
                        // KALKULASI TOTAL HARGA
                        totalAmount += cart[i].harga * kuantitas;
                        cout << "\nBerhasil menambahkan " << snack[opt - 1].namaBarang << " ke keranjang.\n";
                        system("pause");
                        break;
                    }
                }

                if (!found)
                {
                    // Jika snack belum ada dalam keranjang, tambahkan snack baru
                    cart[cartSize].namaBarang = snack[opt - 1].namaBarang;
                    cart[cartSize].harga = snack[opt - 1].harga;
                    cart[cartSize].kuantitas = kuantitas;
                    cartSize++;

                    // KALKULASI TOTAL HARGA
                    totalAmount += cart[cartSize - 1].harga * kuantitas;

                    cout << "\nBerhasil menambahkan " << snack[opt - 1].namaBarang << " ke keranjang.\n";
                    system("pause");
                }
            }
            else
            {
                cout << "\nInvalid option. Please select a valid food item number.\n";
            }
            break;
        case 4:
            system("cls");

            if (cartSize == 0)
            {
                cout << "\nKeranjang kosong. Silakan tambahkan item terlebih dahulu.\n";
                system("pause");
                return customerInterface();
            }

            cout << "\n=== CART ===\n";
            cout << "Nama | Jumlah | Harga | "
                 << "(" << cartSize << "/" << TOTAL << ")\n";

            for (int i = 0; i < cartSize; i++)
            {
                cout << i + 1 << ". " << cart[i].namaBarang << " | " << cart[i].kuantitas << " | Rp" << cart[i].harga * cart[i].kuantitas << endl;
            }

            cout << "\nTotal: Rp" << fixed << setprecision(3) << totalAmount << endl;

            opt = 0;

            do
            {
                cout << "\n1. REMOVE ITEM";
                cout << "\n2. BACK";
                cout << "\nOPTION (1/2): ";
                cin >> opt;

                if (opt == 1)
                {
                    system("cls");
                    int del;
                    // Menampilkan cart
                    cout << "\n=== CART ===\n";
                    cout << "Nama | Jumlah | Harga "
                         << "(" << cartSize << "/" << TOTAL << ")\n";

                    for (int i = 0; i < cartSize; i++)
                    {
                        cout << i + 1 << ". " << cart[i].namaBarang << " | " << cart[i].kuantitas << " | Rp" << cart[i].harga * cart[i].kuantitas << endl;
                    }

                    // Menghapus item dari list
                    cout << "\nPILIH ITEM YANG INGIN DIHAPUS: ";
                    cin >> del;

                    if (del > 0 && del <= cartSize)
                    {
                        if (cart[del - 1].kuantitas > 1)
                        {
                            // Jika kuantitas lebih dari 1, kurangi kuantitas
                            cart[del - 1].kuantitas--;
                        }
                        else
                        {
                            // Jika kuantitas sudah 1, hapus item dari keranjang
                            for (int i = del - 1; i < cartSize - 1; i++)
                            {
                                cart[i] = cart[i + 1];
                            }
                            cartSize--;
                        }

                        totalAmount -= cart[del - 1].harga;
                        cout << "\nItem berhasil dihapus..\n";
                    }
                    else
                    {
                        cout << "\nInvalid option. Please select a valid item number.\n";
                    }
                    system("pause");
                    break;
                }
            } while (opt != 2);
            break;
        case 5:
            system("cls");
            if (cartSize == 0)
            {
                cout << "\nKeranjang kosong. Silakan tambahkan item terlebih dahulu.\n";
                system("pause");
                return customerInterface();
            }
            else
            {
                char choice;

                cout << "\n=== CHECK OUT ===\n";
                cout << "Nama | Jumlah | Harga | "
                     << "(" << cartSize << "/" << TOTAL << ")\n";

                for (int i = 0; i < cartSize; i++)
                {
                    cout << i + 1 << ". " << cart[i].namaBarang << " | " << cart[i].kuantitas << " | Rp" << cart[i].harga * cart[i].kuantitas << endl;
                }

                cout << "\nTotal: Rp" << fixed << setprecision(3) << totalAmount << endl;

                do
                {
                    cout << "\nLanjutkan? (Y/N): ";
                    cin >> choice;

                    if (choice == 'Y' || choice == 'y')
                    {
                        system("cls");
                        do
                        {
                            int payment;
                            opt = 0;

                            cout << "\n=== PAYMENT ===";
                            cout << "\n1. OFFLINE";
                            cout << "\n2. ONLINE";
                            cout << "\n3. BACK";
                            cout << "\nOPTION (1-3): ";
                            cin >> opt;

                            if (opt == 3)
                            {
                                break;
                            }

                            paymentOpt(opt, cartSize);

                            if (opt == 6)
                            {
                                opt = 0;
                            }
                        } while (opt != 3);
                        break;
                    }
                } while (choice != 'N' && choice != 'n');
                break;
            }
        case 6:
            cout << "\nTerima kasih telah menggunakan aplikasi kami.\n";
            system("pause");
            return login();
        default:
            cout << "\nInvalid option.";
            break;
        }
    } while (opt != 6);
}

int paymentOpt(int payment, int cartSize)
{
    system("cls");
    int opt, jarak;
    float pajak, deliveryFee; // jarak untuk ongkir
    bool isOffline;

    pajak = 0;
    deliveryFee = 0;

    switch (payment)
    {
    case 1:
        isOffline = true;

        cout << "\n=== PAYMENT OFFLINE ===";
        cout << "\n1. OVO";
        cout << "\n2. GOPAY";
        cout << "\n3. SHOPEEPAY";
        cout << "\n4. BANK BCA";
        cout << "\n5. BANK BRI";
        cout << "\n6. BANK MANDIRI";
        cout << "\n7. BANK JATIM";
        cout << "\n8. CASH";
        cout << "\n9. BACK";
        cout << "\nOPTION (1-9): ";
        cin >> opt;

        switch (opt)
        {
        case 1:

            system("cls");

            pajak = totalAmount * 0.1; // perhitungan pajak

            cout << "\n=== CHECK OUT ===\n";
            cout << "Nama | Jumlah | Harga "
                 << "(" << cartSize << "/" << TOTAL << ")\n";

            for (int i = 0; i < cartSize; i++)
            {
                cout << i + 1 << ". " << cart[i].namaBarang << " | " << cart[i].kuantitas << " | Rp" << fixed << setprecision(3) << cart[i].harga * cart[i].kuantitas << endl;
            }

            cout << "\n*PPN 10%: " << fixed << setprecision(3) << pajak;
            cout << "\nTotal: Rp" << fixed << setprecision(3) << totalAmount + pajak << endl;

            cout << "\n=== PEMBAYARAN OVO ===";
            cout << "\n1. BAYAR";
            cout << "\n2. BACK";
            cout << "\nOPTION (1/2): ";
            cin >> opt;

            if (opt == 1)
            {
                cout << "\nPEMBAYARAN SUKSES..\n";
                saveRiwayatTransaksi(jarak, isOffline, cartSize, cart, pajak, deliveryFee);

                system("pause");

                for (int i = 0; i < cartSize; i++)
                {
                    cart[i].namaBarang = {};
                    cart[i].kuantitas = {};
                    cart[i].harga = {};
                }

                customerInterface();
            }
            else
            {
                return paymentOpt(payment, cartSize);
            }
            break;

        case 2:

            /*

                BUAT LANJUTANNYA YA BROW UNTUK SISTEM PEMBAYARANNYA (CASE 2 - 8)

            */

        case 9:
            return 0;
            break;
        default:
            cout << "\nInvalid Option";
            break;
        }
        break;
    case 2:

        isOffline = false;

        cout << "Masukkan jarak lokasi customer: ";
        cin >> jarak;

        system("cls");

        cout << "\n=== PAYMENT ONLINE ===";
        cout << "\n1. OVO";
        cout << "\n2. GOPAY";
        cout << "\n3. SHOPEEPAY";
        cout << "\n4. BANK BCA";
        cout << "\n5. BANK BRI";
        cout << "\n6. BANK MANDIRI";
        cout << "\n7. BANK JATIM";
        cout << "\n8. CASH";
        cout << "\n9. BACK";
        cout << "\nOPTION (1-9): ";
        cin >> opt;

        switch (opt)
        {
        case 1:

            system("cls");

            pajak = totalAmount * 0.1;              // perhitungan pajak
            deliveryFee = 10.000 + (1.850 * jarak); // perhitungan ongkir

            cout << "\n=== CHECK OUT ONLINE ===\n";
            cout << "Nama | Jumlah | Harga "
                 << "(" << cartSize << "/" << TOTAL << ")\n";

            for (int i = 0; i < cartSize; i++)
            {
                cout << i + 1 << ". " << cart[i].namaBarang << " | " << cart[i].kuantitas << " | Rp" << fixed << setprecision(3) << cart[i].harga * cart[i].kuantitas << endl;
            }

            cout << "\nDelivery fee: " << fixed << setprecision(3) << deliveryFee;
            cout << "\n*PPN 10%: " << fixed << setprecision(3) << pajak;
            cout << "\nTotal: Rp" << fixed << setprecision(3) << totalAmount + pajak + deliveryFee << endl;

            cout << "\n=== PEMBAYARAN OVO ==="; // pajak: 1.000
            cout << "\n1. BAYAR";
            cout << "\n2. BACK";
            cout << "\nOPTION (1/2): ";
            cin >> opt;

            if (opt == 1)
            {
                cout << "\nPEMBAYARAN SUKSES..\n";
                saveRiwayatTransaksi(jarak, isOffline, cartSize, cart, pajak, deliveryFee);

                system("pause");

                for (int i = 0; i < cartSize; i++)
                {
                    cart[i].namaBarang = {};
                    cart[i].kuantitas = {};
                    cart[i].harga = {};
                }

                customerInterface();
            }
            else
            {
                return paymentOpt(payment, cartSize);
            }
            break;

            /*

                BUAT LANJUTANNYA YA BROW UNTUK SISTEM PEMBAYARANNYA (CASE 2 - 8)

            */

        case 9:
            return 0;
            break;
        default:
            cout << "\nInvalid Option";
            break;
        }
        break;
    }
}

void saveRiwayatTransaksi(int jarak, bool isOffline, int cartSize, dataBarang cart[], float pajak, float deliveryFee)
{
    int panjangBaru;

    // save riwayat transaksi

    ofstream saveHistory("riwayatTransaksi.txt");

    // saveHistory.open("riwayatTransaksi.txt", ios::app);

    if (sizeRiwayatTransaksi > 0)
    {
        for (int i = 0; i < sizeRiwayatTransaksi; i++)
        {
            saveHistory << riwayatTransaksi[i] << endl;
        }
    }

    if (isOffline = true)
    {
        panjangBaru = 9;

        saveHistory << "\n============================================================================\n";

        saveHistory << "\nNama | Jumlah | Harga "
                    << "(" << cartSize << "/" << TOTAL << ")\n";

        for (int i = 0; i < cartSize; i++)
        {
            saveHistory << i + 1 << ". " << cart[i].namaBarang << " | " << cart[i].kuantitas << " | Rp" << fixed << setprecision(3) << cart[i].harga * cart[i].kuantitas << endl;
            panjangBaru++;
        }

        saveHistory << "\n*PPN 10%: " << fixed << setprecision(3) << pajak;
        saveHistory << "\nTotal: Rp" << fixed << setprecision(3) << totalAmount + pajak << endl;

        saveHistory << "\n============================================================================\n";
    }
    else
    {
        panjangBaru = 10;
        ofstream saveHistory("riwayatTransaksi.txt");

        saveHistory << "\n============================================================================\n";

        saveHistory << "\nNama | Jumlah | Harga "
                    << "(" << cartSize << "/" << TOTAL << ")\n";

        for (int i = 0; i < cartSize; i++)
        {
            saveHistory << i + 1 << ". " << cart[i].namaBarang << " | " << cart[i].kuantitas << " | Rp" << fixed << setprecision(3) << cart[i].harga * cart[i].kuantitas << endl;
            panjangBaru++;
        }

        saveHistory << "\nDelivery fee: " << deliveryFee;
        saveHistory << "\n*PPN 10%: " << pajak;
        saveHistory << "\nTotal: Rp" << fixed << setprecision(3) << totalAmount + pajak + deliveryFee << endl;

        saveHistory << "\n============================================================================\n";
    }

    saveHistory.close();
    sizeRiwayatTransaksi += panjangBaru;

    saveData();

    return;
}

void saveData()
{

    // save data SIZE.txt

    ofstream newSIZE("SIZE.txt");

    newSIZE << sizeMakanan << " " << sizeMinuman << " " << sizeSnack << " " << sizeRiwayatTransaksi;

    // save data makanan.txt
    ofstream saveMakanan("makanan.txt");

    for (int i = 0; i < sizeMakanan; i++)
    {
        saveMakanan << makanan[i].namaBarang << endl;
    }

    saveMakanan.close();

    // save data hargaMakanan.txt

    ofstream saveHargaMakanan("hargaMakanan.txt");

    for (int i = 0; i < sizeMakanan; i++)
    {
        saveHargaMakanan << fixed << setprecision(3) << makanan[i].harga << endl;
    }

    saveHargaMakanan.close();

    // save data makanan.txt
    ofstream saveMinuman("minuman.txt");

    for (int i = 0; i < sizeMinuman; i++)
    {
        saveMinuman << minuman[i].namaBarang << endl;
    }

    saveMakanan.close();

    // save data hargaMakanan.txt

    ofstream saveHargaMinuman("hargaMinuman.txt");

    for (int i = 0; i < sizeMinuman; i++)
    {
        saveHargaMinuman << fixed << setprecision(3) << minuman[i].harga << endl;
    }

    saveHargaMinuman.close();
    // save data makanan.txt
    ofstream saveSnack("snack.txt");

    for (int i = 0; i < sizeSnack; i++)
    {
        saveSnack << snack[i].namaBarang << endl;
    }

    saveSnack.close();

    // save data hargaSnack.txt

    ofstream saveHargaSnack("hargaSnack.txt");

    for (int i = 0; i < sizeSnack; i++)
    {
        saveHargaSnack << fixed << setprecision(3) << snack[i].harga << endl;
    }

    saveHargaSnack.close();

    return;
}