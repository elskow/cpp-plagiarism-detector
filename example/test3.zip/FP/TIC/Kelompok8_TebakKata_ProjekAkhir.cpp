/*PROJEK PEMDAS KELOMPOK 8 TEKNIK INFORMATIKA C 2023
ANGGOTA : 
1. 072_WINDA INDRIASTY
2. 089_BAGUS DWI KURNIAWAN
3. 104_FIKRI NENDRA FADHLURRAHMAN
*/
#include <iostream> 
#include <vector>   // header untuk mengaktifkan operator didalam library vector
#include <ctime>    // header untuk mengaktifkan operator time(0)
#include <cstdlib>  // header untuk mengaktifkan operator srand() dan rand()
using namespace std;

//menyimpan informasi permainan, termasuk list nama buah, hewan, dan mahasiswa TIC23, kata rahasia, tebakan pemain, dan jumlah nyawa.
struct Game {
    string ulang;
    vector<string> nama_buah;
    vector<string> nama_hewan;
    vector<string> nama_mhsTIC23;
    string buahRahasia;
    string hewanRahasia;
    string mhsTIC23Rahasia;
    string tebakanbuah;
    string tebakanhewan;
    string tebakanmhsTIC23;
    int nyawa;
}; 

//fungsi untuk menginisialisasi permainan dengan mengatur nama-nama buah, hewan, dan mahasiswa TIC23 secara acak.
void  deklarasivariabel(Game *game) {
    game->nama_buah = { "apel", "jeruk", "semangka", "pisang", "anggur", "melon", "mangga", "nanas", "rambutan", "stroberi", "pepaya", "durian", "alpukat", "manggis" };
    game->nama_hewan={ "jerapah", "buaya","harimau", "singa", "rusa","gajah","anjing", "kucing","ayam", "banteng", "burung", "domba", "kepiting", "udang", "hiu", "paus"};
    game ->nama_mhsTIC23={ "aditya", "winda", "aldhan", "sandhika", "rayhan", "rohim", "vena", "dery", "benhard", "dzikri", "jovita", "adrian", "andhika", "zulhan", "louis", "fauzan", "waiz", "rafael", "bagus", "charis", "fariza", "hamid", "rival", "raqi", "raffi", "gama", "rizki", "frafga", "zaki", "dhuha", "hilma", "hafiz", "tazakka", "fikri", "narendra"};
    game->buahRahasia = game->nama_buah[rand() % game->nama_buah.size()];
    game->hewanRahasia= game->nama_hewan[rand() % game->nama_hewan.size()];
    game ->mhsTIC23Rahasia= game->nama_mhsTIC23[rand() % game->nama_mhsTIC23.size()];
    game->tebakanbuah = string(game->buahRahasia.size(), '_');
    game->tebakanhewan= string(game->hewanRahasia.size(),'_');
    game->tebakanmhsTIC23= string(game->mhsTIC23Rahasia.size(),'_');
    game->nyawa = 5;
}

//fungsi untuk alur permainan : Pemain diminta memilih tema (buah, hewan, atau mahasiswa TIC23), kemudian melakukan tebakan huruf untuk menebak kata rahasia.
void playGame(Game *game) {
    int pilihan;
    cout<<"Pilih tema tebak kata : \n1. nama buah \n2. nama hewan\n3. nama mahasiswaTIC23\nPilih tema (input angka) : "; cin>>pilihan;
    cout<<"================================================\n";
    if (pilihan==1){
        while (game->nyawa > 0 && game->tebakanbuah != game->buahRahasia && game->tebakanhewan != game->hewanRahasia) {
            cout << "KATA BUAH YANG DI TEBAK\t: " << game->tebakanbuah << "\n";
            cout << "NYAWA ANDA TERSISA\t: " << game->nyawa << "\n";
            cout << "MASUKAN HURUF\t\t: ";

            char huruf;
            cin >> huruf;
            huruf=tolower(huruf);// tolower di gunakan untuk antisipasi jika pemain menginputkan karakter kapital

            int cekhuruf_buah= game->buahRahasia.find(huruf);
            int jml_huruf_tebakan_buah=game->buahRahasia.size();
            if (cekhuruf_buah<0 ) {
                game->nyawa--;
            } else {
                for (int i = 0; i < jml_huruf_tebakan_buah; i++) {
                    if (game->buahRahasia[i] == huruf) {
                        game->tebakanbuah[i] = huruf;
                    }
                }
            }
            cout<<"================================================\n";
        }   
                if (game->tebakanbuah == game->buahRahasia) {
                    cout << "Selamat! Anda berhasil menebak kata buah : " << game->buahRahasia << "\n";
                } else {
                    cout << "Sayang sekali, Anda gagal. Kata buah yang benar adalah\t: " << game->buahRahasia << "\n";
                }
    } else if (pilihan ==2){
        while (game->nyawa > 0 && game->tebakanhewan != game->hewanRahasia && game->tebakanhewan != game->hewanRahasia) {
            cout << "KATA HEWAN YANG DI TEBAK\t: " << game->tebakanhewan << "\n";
            cout << "NYAWA ANDA TERSISA\t\t: " << game->nyawa << "\n";
            cout << "MASUKAN HURUF\t\t\t: ";

            char huruf;
            cin >> huruf;
            huruf=tolower(huruf);// tolower di gunakan untuk antisipasi jika pemain menginputkan karakter kapital
            int cekhuruf_hewan= game->hewanRahasia.find(huruf);
            int jml_huruf_tebakan_hewan=game->hewanRahasia.size();
            if (cekhuruf_hewan<0 ) {
                game->nyawa--;
            } else {
                for (int i = 0; i < jml_huruf_tebakan_hewan; i++) {
                    if (game->hewanRahasia[i] == huruf) {
                        game->tebakanhewan[i] = huruf;
                    }
                }
            } 
            cout<<"================================================\n";
        }
            if (game->tebakanhewan == game->hewanRahasia) {
              cout << "Selamat! Anda berhasil menebak nama hewan\t: " << game->hewanRahasia << "\n";
            } else {
               cout << "Sayang sekali, Anda gagal. nama hewan yang benar adalah\t: " << game->hewanRahasia << "\n";
            }   
    }else if (pilihan == 3){
               while (game->nyawa > 0 && game->tebakanmhsTIC23 != game->mhsTIC23Rahasia && game->tebakanmhsTIC23 != game->mhsTIC23Rahasia) {
            cout << "NAMA MHSTIC23 YANG DI TEBAK\t: " << game->tebakanmhsTIC23 << "\n";
            cout << "NYAWA ANDA TERSISA\t\t: " << game->nyawa << "\n";
            cout << "MASUKAN HURUF\t\t\t: ";

            char huruf;
            cin >> huruf;
            huruf=tolower(huruf);// tolower di gunakan untuk antisipasi jika pemain menginputkan karakter kapital
            int cekhuruf_mhsTIC23= game->mhsTIC23Rahasia.find(huruf);
            int jml_huruf_tebakan_mhsTIC23=game->mhsTIC23Rahasia.size();
            if (cekhuruf_mhsTIC23<0 ) {
                game->nyawa--;
            } else {
                for (int i = 0; i < jml_huruf_tebakan_mhsTIC23; i++) {
                    if (game->mhsTIC23Rahasia[i] == huruf) {
                        game->tebakanmhsTIC23[i] = huruf;
                    }
                }
            } 
            cout<<"================================================\n";
        }
            if (game->tebakanmhsTIC23 == game->mhsTIC23Rahasia) {
              cout << "Selamat! Anda berhasil menebak nama mahasiswa TIC23\t: " << game->mhsTIC23Rahasia << "\n";
            } else {
               cout << "Sayang sekali, Anda gagal. Nama mahasiswa yang benar adalah\t: " << game->mhsTIC23Rahasia << "\n";
            }    
    }


}

// memulai dan mengatur alur permainan. Permainan akan terus berlanjut selama pemain ingin bermain lagi (memilih 'y').
int main() {
    Game game;
    char ulang;
    
    do{
        system("cls");//untuk menghapus tampilan pada terminal supaya tidak menumpuk.
        srand(time(0)); // digunakan untuk memastikan bahwa setiap kali program dijalankan akan mendapatkan urutan angka acak yang berbeda.
       

        deklarasivariabel(&game);//deklarasi variabel program

        cout<<"================================================\n"
            <<"||                                            ||\n"
            <<"||   SELAMAT DATANG DI PERMAINAN TEBAK KATA   ||\n"
            <<"||                                            ||\n"
            <<"================================================\n";

        playGame(&game);//permainan di mulai 

        cout<<"main lagi (y/n): "; cin>>ulang;
        ulang=tolower(ulang);// tolower di gunakan untuk antisipasi jika pemain menginputkan karakter kapital
    } while (ulang=='y');
    system("cls");
    cout<<"Program selesai."<<endl;

    return 0;
}
