#include <iostream>
#include <ctime>
#include <string.h>
#include <conio.h>
#include <stdlib.h>
using namespace std;

#define ppn 0.10 //ppn = 10%
const int diskon = 100000;

int main(){

string alamat;
time_t now = time(0);
char* dt = ctime(&now);
char nama [50], menu[50], tanggal[50], lokasi[50], back;
int jumlah, makanan, makan, total, bayar, kurang, bonus, pajak, kembalian, akhir,
    harga[5]={9500, 18500, 19500, 20000, 24500}, i=0;
bool saldo;
string pembayaran;
    int bayar_cash, bayar_debit;
do{
system("CLS");
cout << "__ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __\n";
cout << "|                                                   |\n";
cout << "|            *PROGRAM PEMESANAN CATERING*           |\n";
cout << "|                        OLEH                       |\n";
cout << "|              RAFAEL, BENHARD, JOVITA              |\n";
cout << "|                                                   |\n";
cout << "__ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __ __\n";
cout << "====================================== CATERING INFORMATIKA =========================================" << endl;
cout << "============================================= TIC2023 ===============================================" << endl;
cout << "\nWAKTU PEMESANAN : " << dt << endl;
cout << "MASUKKAN NAMA PEMESAN : "; cin >> nama;
cout << "PILIHAN MENU YANG TERSEDIA" << endl;
cout << "=====================================================================================================" << endl;
cout << "||     [1] PAKET 1 (AYAM GORENG KECAP + (NASI LALAPAN) + ES TEH)          = Rp 9.500               ||" << endl;
cout << "||     [2] PAKET 2 (AYAM GORENG KAMPUNG + (NASI LALAPAN) + ES TEH)        = Rp 18.000              ||" << endl;
cout << "||     [3] PAKET 3 (AYAM GORENG KAMPUNG + (NASI LALAPAN) + ES JERUK)      = Rp 19.500              ||" << endl;
cout << "||     [4] PAKET 4 (AYAM BAKAR KAMPUNG (NASI LALAPAN) + ES JERUK)         = Rp 20.000              ||" << endl;
cout << "||     [5] PAKET 5 (AYAM BAKAR KAMPUNG + (NASI LALAPAN) + ES KELAPA)      = Rp 24.500              ||" << endl;
cout << "=====================================================================================================" << endl;

cout << " (MASUKKAN MENU PAKET MAKANAN BERDASARKAN NOMOR)" << endl;
cout << " SILAHKAN PILIH PAKET MAKANAN ANDA : "; cin >> makanan;

//seleksi
switch(makanan){
    case 1:
        strcpy(menu,"(AYAM GORENG KECAP + (NASI LALAPAN) + ES TEH)");
        break;
    case 2:
        strcpy(menu,"(AYAM GORENG KAMPUNG + (NASI LALAPAN) + ES TEH)");
        i=1;
        break;
    case 3:
        strcpy(menu,"(AYAM GORENG KAMPUNG + (NASI LALAPAN) + ES JERUK)");
        i=2;
        break;
    case 4:
        strcpy(menu,"(AYAM BAKAR KAMPUNG + (NASI LALAPAN) + ES JERUK)");
        i=3;
        break;
    case 5:
        strcpy(menu,"(AYAM BAKAR KAMPUNG + (NASI LALAPAN) + ES KELAPA)");
        i=4;
        break;
    default:
        cout << "MAAF PAKET PILIHAN MAKANAN ANDA TIDAK TERSEDIA" << endl;
        goto ulang;
}

cout << "ANDA MEMILIH" << menu << endl;
cout << endl;
cout << "JUMLAH PAKET MAKAN YANG DIBELI : "; cin >> jumlah;

makan = jumlah * harga [i];
pajak = makan * ppn;
total = pajak + makan;
cout << "TULISKAN TANGGAL PENGIRIMAN    : "; cin  >> tanggal;
cout << endl;
cout << "LOKASI PENGIRIMAN    : "; cin >> lokasi;
getline(cin, alamat);
cout << endl;
cout << "============================================================================================" << endl;
cout << "||                                   CATERING INFORMATIKA                                 ||" << endl;
cout << "============================================================================================" << endl;
cout << "\tNAMA PEMESAN          : "      << nama << endl;
cout << "\tPAKET MENU MAKAN      : "      << menu << endl;
cout << "\tJUMLAH MAKANAN        : "      << jumlah << "porsi" << endl;
cout << "\tHARGA PAKET MAKAN     : "      << harga[i] << " * " << jumlah << endl;
cout << "\tPAJAK PPN (10%)       : "      << pajak << endl;
cout << "\tTOTAL PEMBAYARAN      : Rp "   << total << endl;
cout << "\tTANGGAL PENGIRIMAN    : "      << tanggal << endl;
cout << "\tLOKASI PENGIRIMAN     : "      << lokasi << alamat << endl;
    if(jumlah>100){
    bonus = total - diskon;
    total = bonus;
    cout << endl;
    cout << "SELAMAT ANDA MENDAPATKAN DISKON POTONGAN HARGA : Rp " << diskon << " * " << endl;
    cout << "TOTAL PEMBAYARAN SETELAH DISKON : Rp " << total << endl;
}

cout << "============================================================================================" << endl;
cout << "PILIH METODE PEMBAYARAN" << endl;
    cout << "1. Cash" << endl;
    cout << "2. Debit" << endl;
    cout << "Pilih metode pembayaran (1 untuk Cash / 2 untuk Debit): ";
    int metode_pembayaran;
    cin >> metode_pembayaran;

if (metode_pembayaran == 1) {
    pembayaran = "Cash";
    cout << "SILAHKAN MASUKKAN JUMLAH UANG YANG DIBAYARKAN: Rp ";
    cin >> bayar_cash;
    kembalian = bayar_cash - total;

    if (kembalian < 0) {
        cout << "Maaf, uang yang Anda bayarkan kurang." << endl;
        continue; // Anda bisa menggunakan 'break' jika ingin keluar dari loop
    } else {
        cout << "Kembalian: Rp " << kembalian << endl;
    }
} else if (metode_pembayaran == 2) {
    pembayaran = "Debit";
    cout << "SILAHKAN MASUKKAN JUMLAH PEMBAYARAN DEBIT: Rp ";
    cin >> bayar_debit;
} else {
    cout << "Pilihan metode pembayaran tidak valid." << endl;
    return 1;
}

// perulangan
int bayar;
if (pembayaran == "Cash") {
    bayar = bayar_cash;
} else {
    bayar = bayar_debit;
}

cout << "=============================================================================================" << endl;

ulang:
cout << "[Y = Ya / T = Tidak]" << endl;
cout << "APAKAH ANDA INGIN MEMESAN LAGI ? [Y/T] = "; cin >> back;
}while (back=='Y'|| back=='y');
cout << endl;
cout << "=======================================================================" << endl;
cout << "||    *TERIMA KASIH TELAH MEMESAN MAKANAN DI CATERING INFORMATIKA    ||" << endl;
cout << "||   PESANAN ANDA AKAN KAMI ANTAR SAMPAI TUJUAN, SELAMAT MENIKMATI*  ||" << endl;
cout << "=======================================================================" << endl;

 
  return 0; 
}

