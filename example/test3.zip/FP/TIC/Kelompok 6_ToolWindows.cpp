#include <iostream>
#include <cstdlib>
#include <fstream>
using namespace std;
// Biar Maksimal, Run As Administrator
int main() {
    int n;
    while (true) {
        cout << "Menu:" << endl;
        cout << "1. List Program Windows" << endl;
        cout << "2. Shutdown computer" << endl;
        cout << "3. Restart computer" << endl;
        cout << "4. Performance Boost" << endl;
        cout << "5. Enable/Disable Windows Update" << endl;
        cout << "6. Enable/Disable Windows Defender" << endl;
        cout << "7. Exit" << endl;
        cout << "Pilihan : ";
        cin >> n;
        system("cls");
        switch (n) {
            case 1:
                cout << "List Program Windows : " << endl;
                cout << "1. Registry Editor \n" << "2. Defragment and Optimize Drives \n" << "3. Device Manager \n" << "4. Disk Management \n" << "5. Control Panel" << endl;
                cout << "6. Task Manager \n" << "7. DirectX Diagnostic Tool \n" << "8. Services \n" << "9. System Information \n" << "10. Memory Diagnostic Tool \n" << "11. Task Scheduler \n" << "12. System Configuration \n" << "13. Disk Cleanup \n" << "14. Exit" << endl;
                cout << "Pilihan : ";
                int x;
                cin >> x;

                switch (x) {
                    case 1:
                        system("cls");
                        cout << "Opening Registry Editor...";
                        system("start regedit.exe");
                        system("cls");
                        continue;
                    case 2:
                        system("cls");
                        cout << "Opening Defragment...";
                        system("start dfrgui.exe");
                        system("cls");
                        continue;
                    case 3:
                        system("cls");
                        cout << "Opening Device Manager...";
                        system("start devmgmt.msc");
                        system("cls");
                        continue;
                    case 4:
                        system("cls");
                        cout << "Opening Disk Management...";
                        system("start diskmgmt.msc");
                        system("cls");
                        continue;
                    case 5:
                        system("cls");
                        cout << "Opening Control Panel...";
                        system("start control panel");
                        system("cls");
                        continue;
                    case 6:
                        system("cls");
                        cout << "Opening Task Manager...";
                        system("start Taskmgr.exe");
                        system("cls");
                        continue;
                    case 7:
                        system("cls");
                        cout << "Opening DirectX Diagnostic Tool...";
                        system("start dxdiag.exe");
                        system("cls");
                        continue;
                    case 8:
                        system("cls");
                        cout << "Opening Services...";
                        system("start services.msc");
                        system("cls");
                        continue;
                    case 9:
                        system("cls");
                        cout << "Opening System Information...";
                        system("start msinfo32.exe");
                        system("cls");
                        continue;
                    case 10:
                        system("cls");
                        cout << "Opening Memory Diagnostic Tool...";
                        system("start MdSched.exe");
                        system("cls");
                        continue;
                    case 11:
                        system("cls");
                        cout << "Opening Task Scheduler...";
                        system("start taskschd.msc");
                        system("cls");
                        continue;
                    case 12:
                        system("cls");
                        cout << "Opening System Configuration...";
                        system("start msconfig.exe");
                        system("cls");
                        continue;
                    case 13:
                        system("cls");
                        cout << "Opening Disk Cleanup...";
                        system("start cleanmgr.exe");
                        system("cls");
                        continue;
                    case 14:
                        system("cls");
                        continue;
                    default:
                        system("cls");
                        cout << "Invalid input. Please try again." << endl;
                        break;
                }
                break;
            case 2:
                int r;
                cout << "1. Instant Shutdown" << endl;
                cout << "2. Shutdown (1 Jam)" << endl;
                cout << "3. Shutdown (2 Jam)" << endl;
                cout << "4. Shutdown (3 Jam)" << endl;
                cout << "5. Shutdown (Waktu Kustom)" << endl;
                cout << "6. Exit"<< endl;
                cout << "Pilihan : ";
                cin >> r;
                system("cls");
                switch (r) {
                    case 1: 
                        system("cmd.exe /C shutdown /s /t 1");
                        system("cls");
                        continue;
                    case 2:
                        system("cmd.exe /C shutdown /s /t 3600");
                        system("cls");
                        continue;
                    case 3:
                        system("cmd.exe /C shutdown /s /t 7200");
                        system("cls");
                        continue;
                    case 4:
                        system("cmd.exe /C shutdown /s /t 10800");
                        system("cls");
                        continue;
                    case 5:{
                        ofstream MyFile("shut.bat");

                        int b;
                        string i;
                        i = "shutdown /s /t ";
                        MyFile << i;
                        cout << "Masukkan Waktu (Dalam Detik) : ";
                        cin >> b;
                        MyFile << b;
                        MyFile.close();


                        ifstream myFile;
                        myFile.open("shut.bat");

                        system("cmd.exe /C shut.bat");
                        myFile.close();

                        remove("shut.bat");
                        system("cls");
                    }
                        continue;
                        case 6:
                            system("cls");
                            continue;
                        default: {
                            system("cls");
                            cout << "Invalid input. Please try again." << endl;
                            break;
                        }

                }
                break;
            case 3:
                int a;
                cout << "1. Instant Restart" << endl;
                cout << "2. Restart (1 Jam)" << endl;
                cout << "3. Restart (2 Jam)" << endl;
                cout << "4. Restart (3 Jam)" << endl;
                cout << "5. Restart (Waktu Kustom)" << endl;
                cout << "6. Exit"<< endl;
                cout << "Pilihan : ";
                cin >> a;
                system("cls");
                switch (a) {
                    case 1: 
                        system("cmd.exe /C shutdown /r /t 1");
                        system("cls");
                        continue;
                    case 2:
                        system("cmd.exe /C shutdown /r /t 3600");
                        system("cls");
                        continue;
                    case 3:
                        system("cmd.exe /C shutdown /r /t 7200");
                        system("cls");
                        continue;
                    case 4:
                        system("cmd.exe /C shutdown /r /t 10800");
                        system("cls");
                        continue;
                    case 5:{
                        ofstream MyFile("res.bat");

                        int b;
                        string i;
                        i = "shutdown /r /t ";
                        MyFile << i;
                        cout << "Masukkan Waktu (Dalam Detik) : ";
                        cin >> b;
                        MyFile << b;
                        MyFile.close();


                        ifstream myFile;
                        myFile.open("res.bat");

                        system("cmd.exe /C res.bat");
                        myFile.close();

                        remove("res.bat");
                        system("cls");
                    }
                        continue;
                        case 6:
                            system("cls");
                            continue;
                        default: {
                            system("cls");
                            cout << "Invalid input. Please try again." << endl;
                            break;
                        }

                }
                break;
            case 4:
                system("cls");
                cout << "Boosting....";
                system("cmd.exe /C taskkill /IM svchost.exe /F");
                break;
            default:
                system("cls");
                cout << "Invalid input. Please try again." << endl;
                break;
            
            case 5: 
            int q;
            cout << "1. Enable Windows Update" << endl;
            cout << "2. Disable Windows Update" << endl;
            cout << "3. Exit" << endl;
            cout << "Pilihan : ";
            cin >> q;
            system("cls");
            switch(q){
                case 1:
                system("cls");
                cout << "Enable Windows Update....";
                system("cmd.exe /C sc config wuauserv start= auto");
                system("cmd.exe /C net start wuauserv");
                system("cls");
                break;

                case 2:
                system("cls");
                cout << "Disable Windows Update....";
                system("cmd.exe /C sc config wuauserv start= disabled");
                system("cmd.exe /C net stop wuauserv");
                system("cls");
                break;

                case 3:
                system("cls");
                continue;

                default: {
                system("cls");
                cout << "Invalid input. Please try again." << endl;
                break;
                        }
                break;
            }
            break;

            case 6:
            int w;
            cout << "1. Enable Windows Defender(Butuh Restart)" << endl;
            cout << "2. Disable Windows Defender(Butuh Restart)" << endl;
            cout << "3. Exit" << endl;
            cout << "Pilihan : ";
            cin >> w;
            system("cls");
            switch(w){
                case 1 :
                system("cls");
                cout << "Enable Windows Defender....";
                system("cmd.exe /C sc config WinDefend start= auto");
                system("cmd.exe /C net start WinDefend");
                system("cls");
                break;

                case 2 :
                system("cls");
                cout << "Disable Windows Defender....";
                system("cmd.exe /C sc config WinDefend start= disabled");
                system("cmd.exe /C net stop WinDefend");
                system("cls");
                break;

                case 3 :
                system("cls");
                continue;
                
                default: {
                system("cls");
                cout << "Invalid input. Please try again." << endl;
                break;
                        }
                break;
            }
            break;
            
            case 7 :
            return 0;

            }
        }
    }
