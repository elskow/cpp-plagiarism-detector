#include <iostream>
#include <string>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <vector>

using namespace std;
const string USER_DATA_FILE = "userkurir.txt";
const int MAX_USERS = 5;

struct Barang{
    string namaPemilik;
    string namaBarang;
    float berat;
};

struct User {
    string username;
    string password;
    int paketTerkirim = 0;
    int pendapatan = 0;
    int orderan = 0;
    int totalpaket = 0;
    vector<Barang> tasKurir;
    bool isLoggedIn = false;
};

vector<string> listNamaBarang = {"Laptop", "Smartphone", "Kamera", "Headphone", "Es", "Mouse", "Buku", "Radio", "Pedang", "AK-47", "Bom", "Setrika", "Lemari"};
vector<string> listPemilikBarang = {"Barou", "Nagi", "Itoshi", "Aryu", "Isagi", "Brody", "Chigiri", "Bachira", "Senku", "Eren", "Mikasa", "Frieren", "Ayane", "Kotone"};

template <typename T>
T getRandomElement(const vector<T>& vec) {
    return vec[rand() % vec.size()];
}

User users[MAX_USERS];
int totalUser = 0;

User* temukanUser(const string& username) {
    for (int i = 0; i < totalUser; i++) {
        if (users[i].username == username) {
            return &users[i];
        }
    }
    return nullptr;
}

void simpanDataUserKeFile() {
    ofstream file(USER_DATA_FILE);
    if (file.is_open()) {
        for (int i = 0; i < totalUser; i++) {
            file << users[i].username << " " << users[i].password << " " << users[i].orderan << " " << users[i].pendapatan << " " << users[i].paketTerkirim << " " << users[i].totalpaket << " " << users[i].tasKurir.size() << endl;
            for (const auto& barang : users[i].tasKurir) {
            file << barang.namaPemilik << " " << barang.namaBarang << " " << barang.berat << endl;
            }

        }
        file.close();
        cout << "Data user berhasil disimpan ke file.\n";
    } else {
        cout << "Gagal membuka file untuk disimpan.\n";
    }
}

void bacaDataUserDariFile() {
    ifstream file(USER_DATA_FILE);
    if (file.is_open()) {
        totalUser = 0; 
        while (file >> users[totalUser].username >> users[totalUser].password >> users[totalUser].orderan >> users[totalUser].pendapatan >> users[totalUser].paketTerkirim >> users[totalUser].totalpaket) {
            int jumlahBarang;
            file >> jumlahBarang;
            users[totalUser].tasKurir.resize(jumlahBarang);
            for (int j = 0; j < jumlahBarang; j++) {
                file >> users[totalUser].tasKurir[j].namaPemilik >> users[totalUser].tasKurir[j].namaBarang >> users[totalUser].tasKurir[j].berat;
            }
            ++totalUser;
            if (totalUser >= MAX_USERS) {
                
                break;
            }
        }
        file.close();
        cout << "Data berhasil dibaca dari file.\n";
    } else {
        cout << "Gagal membaca file.\n";
    }
}

void registerUser() {
    if (totalUser < MAX_USERS) {
        User newUser;
        cout << "Masukkan username: ";
        cin >> newUser.username;

        while (temukanUser(newUser.username)) {
            cout << "Username sudah digunakan." << endl;
            cout << "Masukkan username: ";
            cin >> newUser.username;
        }

        cout << "Masukkan password: ";
        cin >> newUser.password;

        users[totalUser++] = newUser;

        cout << "Pendaftaran berhasil.\n";
    } else {
        cout << "User penuh.\n";
    }
}

bool loginUser(User* user) {
    string password;
    cout << "Masukkan password: ";
    cin >> password;

    if (user->password == password) {
        cout << "Login berhasil.\n";
        user->isLoggedIn = true;
        return true;
    }

    cout << "Login gagal. Password salah.\n";
    return false;
}

void statusKurir(User *loggedInUser){
    cout << "Nama : " << loggedInUser->username << endl;
    cout << "Paket yang belum terkirim : " << loggedInUser->orderan << endl;
    cout << "Paket yang telah terkirim : " << loggedInUser->paketTerkirim << endl;
    cout << "Pendapatan : " << loggedInUser->pendapatan << endl;
}

void getOrderan(User *loggedInUser){
    srand(time(0));
    if (loggedInUser->orderan < 5){
        int random = rand() % 3 + 1;
        loggedInUser->orderan += random;
        for (int i = 0; i < random; i++){
            Barang barang;
                    barang.namaPemilik = getRandomElement(listPemilikBarang);
                    barang.namaBarang = getRandomElement(listNamaBarang);
                    
                    if (barang.namaBarang == "Es" || barang.namaBarang == "Buku" || barang.namaBarang == "Mouse" || barang.namaBarang == "Headphone" || barang.namaBarang == "Radio"){
                        barang.berat = 0.5;
                    }else if (barang.namaBarang == "Smartphone" || barang.namaBarang == "Kamera" || barang.namaBarang == "Pedang" || barang.namaBarang == "Bom" || barang.namaBarang == "Setrika"){
                        barang.berat = 1.0;
                    } else if (barang.namaBarang == "Laptop" || barang.namaBarang == "AK-47" || barang.namaBarang == "Lemari"){
                        barang.berat = 2.0;
                    }
                    loggedInUser->tasKurir.push_back(barang);
        }
        cout << "Anda mendapatkan " << random << " paket.\n";
    }else {
        cout << "Orderan Maksimum.\n";
    }
}

void tampilkanTasRecursive(const vector<Barang>& tas, size_t index) {
    if (index >= tas.size()) {
        return;
    }

    const Barang& barang = tas[index];
    cout << "Barang #" << index + 1 << ":\n";
    cout << "   Nama pemilik: " << barang.namaPemilik << "\n";
    cout << "   Nama barang: " << barang.namaBarang << "\n";
    cout << "   Berat barang: " << barang.berat << " kg\n\n";

    
    tampilkanTasRecursive(tas, index + 1);
}


void tampilkanTas(User* loggedInUser){
    if (loggedInUser->tasKurir.empty()) {
        cout << "Isi tas kosong.\n";
    } else {
        // cout << "Daftar Barang:\n";
        // for (size_t i = 0; i < loggedInUser->tasKurir.size(); i++) {
        //     const Barang& barang = loggedInUser->tasKurir[i];
        //     cout << "Barang #" << i + 1 << ":\n";
        //     cout << "   Nama pemilik: " << barang.namaPemilik << "\n";
        //     cout << "   Nama barang: " << barang.namaBarang << "\n";
        //     cout << "   Berat barang: " << barang.berat << " kg\n\n";
        // }
        tampilkanTasRecursive(loggedInUser->tasKurir, 0);
    }
}

void antarPaket(User* loggedInUser){
    if (loggedInUser->tasKurir.empty()) {
        cout << "Tidak ada paket yang harus diantar\n";
    } else {
        cout << "Daftar Barang:\n";
        for (size_t i = 0; i < loggedInUser->tasKurir.size(); i++) {
            const Barang& barang = loggedInUser->tasKurir[i];
            cout << "Barang #" << i + 1 << ":\n";
            cout << "   Nama pemilik: " << barang.namaPemilik << "\n";
            cout << "   Nama barang: " << barang.namaBarang << "\n";
            cout << "   Berat barang: " << barang.berat << " kg\n\n";
        }
        cout << "Pilih nomor barang yang ingin diantar: ";
        size_t nomorBarang;
        cin >> nomorBarang;

        if (nomorBarang > 0 && nomorBarang <= loggedInUser->tasKurir.size()) {
            Barang barangDiantar = loggedInUser->tasKurir[nomorBarang-1];
                      
            loggedInUser->tasKurir.erase(loggedInUser->tasKurir.begin() + nomorBarang - 1);
            cout << barangDiantar.namaBarang << " telah diterima oleh " << barangDiantar.namaPemilik << "\n";
            if (barangDiantar.berat == 0.5){
                loggedInUser->pendapatan += 2000;
                cout << "Anda mendapatkan uang ongkir Rp2000\n";
            } else if (barangDiantar.berat == 1.0){
                loggedInUser->pendapatan += 3000;
                cout << "Anda mendapatkan uang ongkir Rp3000\n";
            } else if (barangDiantar.berat == 2.0){
                loggedInUser->pendapatan += 4000;
                cout << "Anda mendapatkan uang ongkir Rp4000\n";
            }
            loggedInUser->orderan -= 1;
            loggedInUser->paketTerkirim += 1;
            loggedInUser->totalpaket += 1;

        } else {
            cout << "Nomor barang tidak ada.\n";
        }
            
    }
}

void klaimBonus(User* loggedInUser){
    if (loggedInUser->totalpaket >= 5){
        loggedInUser->totalpaket -= 5;
        loggedInUser->pendapatan += 10000;
        cout << "Bonus berhasil diklaim\nAnda mendapatkan bonus Rp10000";
    } else {
        cout << "Anda akan mendapatkan bonus untuk setiap 5 paket yang terkirim\n";
    }
}

void menu(User* loggedInUser) {
    char pilihan;
    while (loggedInUser->isLoggedIn) {
        cout << "1. Status\n";
        cout << "2. Dapatkan Orderan Paket\n";
        cout << "3. Lihat Tas\n";
        cout << "4. Antar Paket\n";
        cout << "5. Klaim Bonus\n";
        cout << "6. Keluar\n";
        // cout << "\n";

        cout << "Masukkan pilihanmu: ";
        cin >> pilihan;
        if (pilihan == '1') {
            statusKurir(loggedInUser);

            char pilih;
            cout << "Ingin kembali ke menu? (Y) : ";
            cin >> pilih;
            if (pilih != 'Y' && pilih != 'y') {
                loggedInUser->isLoggedIn = false;
            }
        } else if (pilihan == '2') {
            getOrderan(loggedInUser);

            char pilih;
            cout << "Ingin kembali ke menu? (Y) : ";
            cin >> pilih;
            if (pilih != 'Y' && pilih != 'y') {
                loggedInUser->isLoggedIn = false;
            }
        } else if (pilihan == '3'){
            tampilkanTas(loggedInUser);

            char pilih;
            cout << "Ingin kembali ke menu? (Y) : ";
            cin >> pilih;
            if (pilih != 'Y' && pilih != 'y') {
                loggedInUser->isLoggedIn = false;
            }
        } else if (pilihan == '4'){
            antarPaket(loggedInUser);

            char pilih;
            cout << "Ingin kembali ke menu? (Y) : ";
            cin >> pilih;
            if (pilih != 'Y' && pilih != 'y') {
                loggedInUser->isLoggedIn = false;
            }
        } else if (pilihan == '5') {
            klaimBonus(loggedInUser);

            char pilih;
            cout << "Ingin kembali ke menu? (Y) : ";
            cin >> pilih;
            if (pilih != 'Y' && pilih != 'y') {
                loggedInUser->isLoggedIn = false;
            }
        } else if (pilihan == '6') {
            cout << "Keluar dari menu.\n";
            loggedInUser->isLoggedIn = false;
        }
         
    }
}

int main() {
    bacaDataUserDariFile();
    char pilihan;
    User* user = NULL;
    do {
        cout << "1. Daftar\n";
        cout << "2. Login\n";
        cout << "3. Keluar\n";
        cout << "Masukkan pilihanmu: ";
        cin >> pilihan;

        switch (pilihan) {
            case '1':
                registerUser();
                break;
            case '2':
            {        
                string username;
                cout << "Masukkan username: ";
                cin >> username;

                // User* user = temukanUser(username);
                user = temukanUser(username);
                if (user) {
                    if (loginUser(user)){  
                        menu(user);
                    }
                } else {
                    cout << "Pengguna tidak ditemukan.\n";
                }
            }
            break;

            case '3':
                cout << "Keluar dari program.\n";
                break;
            default:
                cout << "Pilihan tidak tersedia. Coba lagi.\n";
        }
    } while (pilihan != '3');

    simpanDataUserKeFile();
    return 0;
}
