#include <bits/stdtr1c++.h>

using namespace std;

struct data_mahasiswa {
  string nama;
  string kelas;
  string no;
  string prodi;
};

void login() {
  string username, password;

  cout << "Masukkan username: ";
  cin >> username;

  cout << "Masukkan password: ";
  cin >> password;

  if (username == "admin" && password == "123") {
    cout << "Login berhasil!" << endl;
  } else {
    cout << "Login gagal!" << endl;
    exit (0);
  }
}

void tambah_data() {
  data_mahasiswa data;

   cout << "Masukkan Nama: ";
  getline(cin, data.nama);

  cout << "Masukkan Jurusan: ";
  getline(cin, data.kelas);

  cout << "Masukkan NIM: ";
  getline(cin, data.no);

  cout << "Masukkan Prodi: ";
  getline(cin, data.prodi);

  ofstream file("data.txt", ios::app);

  file << data.nama << "," << data.kelas << "," << data.no << "," << data.prodi << endl;

  file.close();
  cout << "Data Berhasil Tersimpan";
}

void hapus_data() {
  string nama;

  cout << "Masukkan nama yang ingin dihapus: ";
  cin >> nama;

  ifstream file("data.txt");
  ofstream temp("temp.txt");

  string line;
  bool dataDitemukan = false;

  while (getline(file, line)) {
    if (line.find(nama) == string::npos) {
      temp << line << endl;
    } else {
      dataDitemukan = true;
    }
  }

  file.close();
  temp.close();

  remove("data.txt");
  rename("temp.txt", "data.txt");

  if (!dataDitemukan) {
    cout << "Data tidak ditemukan." << endl;
  } else {
    cout << "Data berhasil dihapus." << endl;
  }
}

void cari_data() {
  string nama;

  cout << "Masukkan nama yang ingin dicari: ";
  cin >> nama;

  ifstream file("data.txt");

  string line;
  bool dataDitemukan = false;

  while (getline(file, line)) {
    if (line.find(nama) != string::npos) {
      stringstream ss(line);
      string field;

      getline(ss, field, ',');
      cout << "Nama: " << field << endl;

      getline(ss, field, ',');
      cout << "Kelas: " << field << endl;

      getline(ss, field, ',');
      cout << "Nomor: " << field << endl;

      getline(ss, field, ',');
      cout << "Prodi: " << field << endl;

      dataDitemukan = true;
      break;
    }
  }

  file.close();

  if (!dataDitemukan) {
    cout << "Data tidak ditemukan." << endl;
  }
}

void tampilkan_semua_data() {
  ifstream file("data.txt");

  string line;
  while (getline(file, line)) {
    stringstream ss(line);
    string field;

    getline(ss, field, ',');
    cout << "Nama: " << field << endl;

    getline(ss, field, ',');
    cout << "Kelas: " << field << endl;

    getline(ss, field, ',');
    cout << "Nomor: " << field << endl;

    getline(ss, field, ',');
    cout << "Prodi: " << field << endl;
  }

  file.close();
}

int main() {
    cout << "\t************************************************************\n\n";
	cout << "\t.........................LOGIN..............................\n\n";
	cout << "\t************************************************************\n\n";
  int pilihan;

  login();

  do {
    cout << "\t************************************************************\n\n";
    cout << "\n\t-->> Welcome to Student database monitoring system <<-- 	\n";
	cout << "\t************************************************************\n\n";
    cout << endl;
    cout << "Menu:" << endl;
    cout << "1. Tambah data" << endl;
    cout << "2. Hapus data" << endl;
    cout << "3. Cari data" << endl;
    cout << "4. Tampilkan semua data" << endl;
    cout << "5. Keluar" << endl;
    cout << "Masukkan pilihan: ";
    cin >> pilihan;

    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    switch (pilihan) {
      case 1:
        tambah_data();
        break;
      case 2:
        hapus_data();
        break;
      case 3:
        cari_data();
        break;
      case 4:
        tampilkan_semua_data();
        break;
      case 5:
        cout << "Keluar dari program." << endl;
        cout << "Terima Kasih"<<endl;
        break;
      default:
        cout << "Pilihan tidak valid." << endl;
        break;
    }
  } while (pilihan != 5);

  return 0;
}



