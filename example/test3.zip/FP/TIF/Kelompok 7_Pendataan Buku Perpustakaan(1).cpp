#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

const int MAX_BARIS = 10;
const int MAX_KOLOM = 100;
const int MAX_JUDUL = 10;  // Jumlah judul buku yang diberikan

struct Buku {
    char judul[100];
    char pengarang[100];
    bool dipinjam;
};

struct BukuMatriks {
    Buku buku[MAX_BARIS][MAX_KOLOM];
};

void inisialisasiDaftarBuku(BukuMatriks& daftarBuku, int& jumlahBuku) {
    const char* judul[] = {
        "Perahu Kertas",
        "Negeri 5 Menara",
        "Laskar Pelangi",
        "Lho...itu kan juga korupsi?",
        "Hujan",
        "Tentang Kamu",
        "Rindu",
        "Hello",
        "Ayahku (bukan) Pembohong",
        "Bumi"
    };

    const char* pengarang[] = {
        "Dee Lestari",
        "Ahmad Fuadi",
        "Andrea Hirata",
        "A.Faris Ardi",
        "Tere Liye",
        "Tere Liye",
        "Tere Liye",
        "Tere Liye",
        "Tere Liye",
        "Tere Liye"
    };

    for (int i = 0; i < MAX_JUDUL; ++i) {
        strcpy(daftarBuku.buku[i / MAX_KOLOM][i % MAX_KOLOM].judul, judul[i]);
        strcpy(daftarBuku.buku[i / MAX_KOLOM][i % MAX_KOLOM].pengarang, pengarang[i]);
        daftarBuku.buku[i / MAX_KOLOM][i % MAX_KOLOM].dipinjam = false;
    }

    jumlahBuku = MAX_JUDUL;
}

int cariBukuByJudul(BukuMatriks& daftarBuku, int jumlahBuku, const char* judul, int index = 0) {
    if (index < jumlahBuku) {
        if (strcmp(daftarBuku.buku[index / MAX_KOLOM][index % MAX_KOLOM].judul, judul) == 0) {
            return index;  // Buku ditemukan
        } else {
            return cariBukuByJudul(daftarBuku, jumlahBuku, judul, index + 1);  // Cari di indeks berikutnya
        }
    } else {
        return -1;  // Buku tidak ditemukan
    }
}


void hapusBuku(BukuMatriks& daftarBuku, int& jumlahBuku, int buku) {
    if (buku >= 0 && buku < jumlahBuku) {
        for (int i = buku; i < jumlahBuku - 1; ++i) {
            strcpy(daftarBuku.buku[i / MAX_KOLOM][i % MAX_KOLOM].judul, daftarBuku.buku[(i + 1) / MAX_KOLOM][(i + 1) % MAX_KOLOM].judul);
            strcpy(daftarBuku.buku[i / MAX_KOLOM][i % MAX_KOLOM].pengarang, daftarBuku.buku[(i + 1) / MAX_KOLOM][(i + 1) % MAX_KOLOM].pengarang);
            daftarBuku.buku[i / MAX_KOLOM][i % MAX_KOLOM].dipinjam = daftarBuku.buku[(i + 1) / MAX_KOLOM][(i + 1) % MAX_KOLOM].dipinjam;
        }

        // Menghapus data pada indeks terakhir
        strcpy(daftarBuku.buku[(jumlahBuku - 1) / MAX_KOLOM][(jumlahBuku - 1) % MAX_KOLOM].judul, "");
        strcpy(daftarBuku.buku[(jumlahBuku - 1) / MAX_KOLOM][(jumlahBuku - 1) % MAX_KOLOM].pengarang, "");
        daftarBuku.buku[(jumlahBuku - 1) / MAX_KOLOM][(jumlahBuku - 1) % MAX_KOLOM].dipinjam = false;

        jumlahBuku--;
        cout << "Buku berhasil dihapus." << endl;
    } else {
        cout << "Nomor buku tidak valid." << endl;
    }
}

void tampilkanMenu() {
    cout << "Menu: " << endl;
    cout << "1. Pinjam Buku" << endl;
    cout << "2. Tambah Buku" << endl;
    cout << "3. Tampilkan Daftar Buku" << endl;
    cout << "4. Hapus Buku Tertentu" << endl;  // Ganti judul menu
    cout << "5. Simpan Ke File" << endl;
    cout << "6. Kembalikan Buku" << endl;
    cout << "0. Keluar" << endl;
}

    void hapusDaftarBuku(BukuMatriks& daftarBuku, int& jumlahBuku) {
    char judul[100];
    cout << "Masukkan judul buku yang ingin dihapus: ";
    cin.ignore();
    cin.getline(judul, sizeof(judul));

    int index = cariBukuByJudul(daftarBuku, jumlahBuku, judul);

    if (index != -1) {
        hapusBuku(daftarBuku, jumlahBuku, index);
        cout << "Buku berhasil dihapus." << endl;
    } else {
        cout << "Buku tidak ditemukan." << endl;
    }
}

void pinjamBuku(BukuMatriks& daftarBuku, int jumlahBuku) {
    int buku;
    cout << "Masukkan nomor buku yang ingin dipinjam: ";
    cin >> buku;

    if (buku >= 0 && buku < jumlahBuku) {
        if (!daftarBuku.buku[buku / MAX_KOLOM][buku % MAX_KOLOM].dipinjam) {
            daftarBuku.buku[buku / MAX_KOLOM][buku % MAX_KOLOM].dipinjam = true;
            cout << "Buku berhasil dipinjam." << endl;
        } else {
            cout << "Buku sudah dipinjam." << endl;
        }
    } else {
        cout << "Nomor buku tidak valid." << endl;
    }
}

void kembalikanBuku(BukuMatriks& daftarBuku, int jumlahBuku) {
    int buku;
    cout << "Masukkan nomor buku yang ingin dikembalikan: ";
    cin >> buku;

    if (buku >= 0 && buku < jumlahBuku) {
        if (daftarBuku.buku[buku / MAX_KOLOM][buku % MAX_KOLOM].dipinjam) {
            daftarBuku.buku[buku / MAX_KOLOM][buku % MAX_KOLOM].dipinjam = false;
            cout << "Buku berhasil dikembalikan." << endl;
        } else {
            cout << "Buku tidak dalam kondisi dipinjam." << endl;
        }
    } else {
        cout << "Nomor buku tidak valid." << endl;
    }
}

void tampilkanDaftarBuku(BukuMatriks& daftarBuku, int jumlahBuku) {
    cout << "Daftar Buku yang Tersedia:" << endl;
    for (int i = 0; i < jumlahBuku; ++i) {
        cout << "[" << i << "] ";
        cout << "Judul: " << daftarBuku.buku[i / MAX_KOLOM][i % MAX_KOLOM].judul << ", ";
        cout << "Pengarang: " << daftarBuku.buku[i / MAX_KOLOM][i % MAX_KOLOM].pengarang << ", ";
        cout << "Status: " << (daftarBuku.buku[i / MAX_KOLOM][i % MAX_KOLOM].dipinjam ? "Dipinjam" : "Tersedia") << endl;
    }
}

void tukarBuku(Buku* buku1, Buku* buku2) {
    Buku temp = *buku1;
    *buku1 = *buku2;
    *buku2 = temp;
}
void tambahBuku(BukuMatriks& daftarBuku, int& jumlahBuku, const char* judul, const char* pengarang) {
    if (jumlahBuku < MAX_BARIS * MAX_KOLOM) {
        int baris = jumlahBuku / MAX_KOLOM;
        int kolom = jumlahBuku % MAX_KOLOM;

        strcpy(daftarBuku.buku[baris][kolom].judul, judul);
        strcpy(daftarBuku.buku[baris][kolom].pengarang, pengarang);
        daftarBuku.buku[baris][kolom].dipinjam = false;

        // Memastikan buku yang ditambahkan berada di posisi yang benar
        for (int i = jumlahBuku; i > 0; --i) {
            if (strcmp(daftarBuku.buku[i / MAX_KOLOM][i % MAX_KOLOM].judul, daftarBuku.buku[(i - 1) / MAX_KOLOM][(i - 1) % MAX_KOLOM].judul) < 0) {
                tukarBuku(&daftarBuku.buku[i / MAX_KOLOM][i % MAX_KOLOM], &daftarBuku.buku[(i - 1) / MAX_KOLOM][(i - 1) % MAX_KOLOM]);
            } else {
                break;
            }
        }

        // Jumlah buku ditambah setelah operasi pointer
        jumlahBuku++;

        cout << "Buku berhasil ditambahkan." << endl;
    } else {
        cout << "Perpustakaan penuh, tidak dapat menambahkan buku." << endl;
    }
}

void simpanKeFile(BukuMatriks& daftarBuku, int jumlahBuku) {
    ofstream file("daftar_buku.txt");

    for (int i = 0; i < jumlahBuku; ++i) {
        file << daftarBuku.buku[i / MAX_KOLOM][i % MAX_KOLOM].judul << ",";
        file << daftarBuku.buku[i / MAX_KOLOM][i % MAX_KOLOM].pengarang << ",";
        file << (daftarBuku.buku[i / MAX_KOLOM][i % MAX_KOLOM].dipinjam ? "1" : "0") << endl;
    }

    file.close();
    cout << "Daftar buku berhasil disimpan ke dalam file." << endl;
}

int main() {
    BukuMatriks daftarBuku;
    int jumlahBuku = 0;

    // Inisialisasi daftar buku
    inisialisasiDaftarBuku(daftarBuku, jumlahBuku);

    int pilihan;

    do {
        tampilkanMenu();

        cout << "Pilihan Anda: ";
        cin >> pilihan;

        switch (pilihan) {
            case 1:
                pinjamBuku(daftarBuku, jumlahBuku);
                break;
            case 2:
                {
                    char judul[100];
                    char pengarang[100];
                    cout << "Masukkan judul buku: ";
                    cin.ignore(); // Clear newline from the input buffer
                    cin.getline(judul, sizeof(judul));
                    cout << "Masukkan nama pengarang: ";
                    cin.getline(pengarang, sizeof(pengarang));
                    tambahBuku(daftarBuku, jumlahBuku, judul, pengarang);
                }
                break;
            case 3:
                tampilkanDaftarBuku(daftarBuku, jumlahBuku);
                break;
            case 4:
                hapusDaftarBuku(daftarBuku, jumlahBuku);
                break;
            case 5:
                simpanKeFile(daftarBuku, jumlahBuku);
                break;
            case 6:
                kembalikanBuku(daftarBuku, jumlahBuku);
                break;
            case 0:
                cout << "Terima kasih telah berkunjung ke perpustakaan ini." << endl;
                break;
            default:
                cout << "Pilihan tidak valid." << endl;
        }
    } while (pilihan != 0);  // Loop tak terbatas

    return 0;
}