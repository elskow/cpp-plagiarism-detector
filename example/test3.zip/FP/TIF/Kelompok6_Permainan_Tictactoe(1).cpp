#include <iostream>
#include <time.h>
#include <string>

using namespace std;

string kotak[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9"};

void tampilan()
{
    cout << "     ____________________________\n";
    cout << "    |                            |\n";
    cout << "    |   Selamat Datang di Game   |\n";
    cout << "    |        Tic Tac Toe         |\n";
    cout << "    |____________________________|\n";
    cout << "    |                            |\n";
    cout << "    |        1.VS Komputer       |\n";
    cout << "    |                            |\n";
    cout << "    |        2.Multyplayer       |\n";
    cout << "    |____________________________|\n";
    cout << "  \n";
}
void tampilanVSKomputer()
{
    system("cls");
    cout << "  --------------------------------\n";
    cout << "       Selamat Datang di Game     \n";
    cout << "            Tic Tac Toe           \n";
    cout << "  --------------------------------\n";
    cout << "            VS Komputer           \n";
    cout << "  --------------------------------\n";
    cout << "     Player1 (\x1B[34mX\033[0m) | komputer (\x1B[31mO\033[0m)     \n\n";
    cout << "      ________ ________ ________\n";
    cout << "     |        |        |        |\n";
    cout << "     |    " << kotak[0] << "   |    " << kotak[1] << "   |   " << kotak[2] << "    |\n";
    cout << "     |________|________|________|\n";
    cout << "     |        |        |        |\n";
    cout << "     |    " << kotak[3] << "   |    " << kotak[4] << "   |   " << kotak[5] << "    |\n";
    cout << "     |________|________|________|\n";
    cout << "     |        |        |        |\n";
    cout << "     |    " << kotak[6] << "   |    " << kotak[7] << "   |   " << kotak[8] << "    |\n";
    cout << "     |________|________|________|\n"
         << " \n";
}
void tampilanMultiplayer()
{
    system("cls");
    cout << "   --------------------------------\n";
    cout << "        Selamat Datang di Game     \n";
    cout << "             Tic Tac Toe           \n";
    cout << "   --------------------------------\n";
    cout << "             Multyplayer           \n";
    cout << "   --------------------------------\n";
    cout << "       Player1 (\x1B[34mX\033[0m) | Player2 (\x1B[31mO\033[0m)     \n\n";
    cout << "      ________ ________ ________\n";
    cout << "     |        |        |        |\n";
    cout << "     |    " << kotak[0] << "   |    " << kotak[1] << "   |   " << kotak[2] << "    |\n";
    cout << "     |________|________|________|\n";
    cout << "     |        |        |        |\n";
    cout << "     |    " << kotak[3] << "   |    " << kotak[4] << "   |   " << kotak[5] << "    |\n";
    cout << "     |________|________|________|\n";
    cout << "     |        |        |        |\n";
    cout << "     |    " << kotak[6] << "   |    " << kotak[7] << "   |   " << kotak[8] << "    |\n";
    cout << "     |________|________|________|\n"
         << " \n";
}

int hasil()
{
    if (kotak[0] == kotak[1] && kotak[1] == kotak[2])
    {
        return 1;
    }
    else if (kotak[3] == kotak[4] && kotak[4] == kotak[5])
    {
        return 1;
    }
    else if (kotak[6] == kotak[7] && kotak[7] == kotak[8])
    {
        return 1;
    }
    else if (kotak[0] == kotak[3] && kotak[3] == kotak[6])
    {
        return 1;
    }
    else if (kotak[1] == kotak[4] && kotak[4] == kotak[7])
    {
        return 1;
    }
    else if (kotak[2] == kotak[5] && kotak[5] == kotak[8])
    {
        return 1;
    }
    else if (kotak[0] == kotak[4] && kotak[4] == kotak[8])
    {
        return 1;
    }
    else if (kotak[2] == kotak[4] && kotak[4] == kotak[6])
    {
        return 1;
    }
    else if (kotak[0] != "1" && kotak[1] != "2" && kotak[2] != "3" && kotak[3] != "4" && kotak[4] != "5" && kotak[5] != " 6" && kotak[6] != "7" && kotak[7] != "8" && kotak[8] != "9")
    {
        return -1;
    }
    else
    {
        return 0;
    }
}

int main()
{
    int play = 1, nilaiHasil;
    char pilihan, tipePermainan;
    string pemain[3] = {"Player1", "Komputer", "Player2"};
    string karakter;

tipePermainan:
mainLagi:
    tampilan();
    cout << "       Pilih Tipe Permainan : ";
    cin >> tipePermainan;

    if (tipePermainan == '1')
    {
        do
        {
            tampilanVSKomputer();

            play = (play % 2) ? 1 : 2;

            if (play == 1 && pemain[0] == "Player1")
            {
                cout << " "
                     << "\n\n   Giliran " << pemain[0] << ", Masukkan Nomer : ";
                cin >> pilihan;

                karakter = "\x1B[34mX\033[0m";

                if (pilihan == '1' && kotak[0] == "1")
                {
                    kotak[0] = karakter;
                }
                else if (pilihan == '2' && kotak[1] == "2")
                {
                    kotak[1] = karakter;
                }
                else if (pilihan == '3' && kotak[2] == "3")
                {
                    kotak[2] = karakter;
                }
                else if (pilihan == '4' && kotak[3] == "4")
                {
                    kotak[3] = karakter;
                }
                else if (pilihan == '5' && kotak[4] == "5")
                {
                    kotak[4] = karakter;
                }
                else if (pilihan == '6' && kotak[5] == "6")
                {
                    kotak[5] = karakter;
                }
                else if (pilihan == '7' && kotak[6] == "7")
                {
                    kotak[6] = karakter;
                }
                else if (pilihan == '8' && kotak[7] == "8")
                {
                    kotak[7] = karakter;
                }
                else if (pilihan == '9' && kotak[8] == "9")
                {
                    kotak[8] = karakter;
                }
                else
                {
                    play--;
                }
            }
            else if (play == 2 && pemain[1] == "Komputer")
            {
                srand(time(0));
                int nilaiRandom = rand() % 9;

                karakter = "\x1B[31mO\033[0m";

                if (nilaiRandom == 1 && kotak[0] == "1")
                {
                    kotak[0] = karakter;
                }
                else if (nilaiRandom == 2 && kotak[1] == "2")
                {
                    kotak[1] = karakter;
                }
                else if (nilaiRandom == 3 && kotak[2] == "3")
                {
                    kotak[2] = karakter;
                }
                else if (nilaiRandom == 4 && kotak[3] == "4")
                {
                    kotak[3] = karakter;
                }
                else if (nilaiRandom == 5 && kotak[4] == "5")
                {
                    kotak[4] = karakter;
                }
                else if (nilaiRandom == 6 && kotak[5] == "6")
                {
                    kotak[5] = karakter;
                }
                else if (nilaiRandom == 7 && kotak[6] == "7")
                {
                    kotak[6] = karakter;
                }
                else if (nilaiRandom == 8 && kotak[7] == "8")
                {
                    kotak[7] = karakter;
                }
                else if (nilaiRandom == 9 && kotak[8] == "9")
                {
                    kotak[8] = karakter;
                }
                else
                {
                    play--;
                }
            }
            nilaiHasil = hasil();
            play++;
        } while (nilaiHasil == 0);
        tampilanVSKomputer();
        if (nilaiHasil == 1)
        {
            play--;
            if (play == 1)
            {
                cout << "\n           " << pemain[0] << " Menang!\n\n";
            }
            else
            {
                cout << "\n           " << pemain[1] << " Menang!\n\n";
            }
        }
        else if (nilaiHasil == -1)
        {
            cout << "\n        "
                 << " Game Berakhir Seri!\n\n";
        }
    }
    else if (tipePermainan == '2')
    {
        do
        {
            tampilanMultiplayer();
            play = (play % 2) ? 1 : 2;

            if (play == 1 && pemain[0] == "Player1")
            {
                cout << " "
                     << "\n\n   Giliran " << pemain[0] << ", Masukkan Nomer : ";
                cin >> pilihan;

                karakter = "\x1B[34mX\033[0m";

                if (pilihan == '1' && kotak[0] == "1")
                {
                    kotak[0] = karakter;
                }
                else if (pilihan == '2' && kotak[1] == "2")
                {
                    kotak[1] = karakter;
                }
                else if (pilihan == '3' && kotak[2] == "3")
                {
                    kotak[2] = karakter;
                }
                else if (pilihan == '4' && kotak[3] == "4")
                {
                    kotak[3] = karakter;
                }
                else if (pilihan == '5' && kotak[4] == "5")
                {
                    kotak[4] = karakter;
                }
                else if (pilihan == '6' && kotak[5] == "6")
                {
                    kotak[5] = karakter;
                }
                else if (pilihan == '7' && kotak[6] == "7")
                {
                    kotak[6] = karakter;
                }
                else if (pilihan == '8' && kotak[7] == "8")
                {
                    kotak[7] = karakter;
                }
                else if (pilihan == '9' && kotak[8] == "9")
                {
                    kotak[8] = karakter;
                }
                else
                {
                    play--;
                }
            }
            else if (play == 2 && pemain[2] == "Player2")
            {
                cout << " "
                     << "\n\n   Giliran " << pemain[2] << ", Masukkan Nomer : ";
                cin >> pilihan;

                karakter = "\x1B[31mO\033[0m";

                if (pilihan == '1' && kotak[0] == "1")
                {
                    kotak[0] = karakter;
                }
                else if (pilihan == '2' && kotak[1] == "2")
                {
                    kotak[1] = karakter;
                }
                else if (pilihan == '3' && kotak[2] == "3")
                {
                    kotak[2] = karakter;
                }
                else if (pilihan == '4' && kotak[3] == "4")
                {
                    kotak[3] = karakter;
                }
                else if (pilihan == '5' && kotak[4] == "5")
                {
                    kotak[4] = karakter;
                }
                else if (pilihan == '6' && kotak[5] == "6")
                {
                    kotak[5] = karakter;
                }
                else if (pilihan == '7' && kotak[6] == "7")
                {
                    kotak[6] = karakter;
                }
                else if (pilihan == '8' && kotak[7] == "8")
                {
                    kotak[7] = karakter;
                }
                else if (pilihan == '9' && kotak[8] == "9")
                {
                    kotak[8] = karakter;
                }
                else
                {
                    play--;
                }
            }
            nilaiHasil = hasil();
            play++;
        } while (nilaiHasil == 0);
        tampilanMultiplayer();
        if (nilaiHasil == 1)
        {
            play--;
            if (play == 1)
            {
                cout << "\n            " << pemain[0] << " Menang!\n\n";
            }
            else
            {
                cout << "\n            " << pemain[2] << " Menang!\n\n";
            }
        }
        else if (nilaiHasil == -1)
        {
            cout << "\n        "
                 << " Game Berakhir Seri!\n\n";
        }
    }
    else
    {
        cout << " \n";
        cout << "     \x1B[31mInput yang anda masukan salah\033[0m\n"
             << "             \x1B[31mCoba lagi!!!\033[0m         \n";
        cout << "\n";
        goto tipePermainan; // berfungsi untuk kembali ke pemilihan tipe permainan jika input yg dimasukan salah
    }

inputLagi:
    char mainLagi;
    char inputLagi;
    cout << "\n"
         << "    Apakah Mau Bermain Lagi?(y/n) : ";
    cin >> mainLagi;

    if (mainLagi == 'y' || mainLagi == 'Y')
    {

        // Berfungsi untuk mereset simbol pada tiap angka
        nilaiHasil = 0;
        for (int i = 0; i < 9; i++)
        {
            kotak[i] = to_string(i + 1);
        }
        // Kembali ke awal program
        goto mainLagi;
    }
    else if (mainLagi == 'n' || mainLagi == 'N')
    {
        cout << "\n "
             << "     Terima Kasih, Sudah Bermain!\n"
             << " ";
    }
    else
    {
        cout << "     \n";
        cout << "     \x1B[31mInput yang anda masukan salah\033[0m\n"
             << "             \x1B[31mCoba lagi!!!\033[0m         \n";
        goto inputLagi;
    }

    return 0;
}
