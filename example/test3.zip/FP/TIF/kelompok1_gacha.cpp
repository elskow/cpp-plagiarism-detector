#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>

using namespace std;

struct Item {
    string name;
    string tipe;
    int dps;
    ;
};

void gacha(Item items[], int size, string nama) {
    srand(time(0));
    int randomIndex = rand() % size;
    Item item = items[randomIndex];
    cout << "Anda mendapatkan item: " << item.name << endl;
    cout << "Tingkat Keganasan Item: " << item.tipe << endl;
    cout << "Damage per Second: " << item.dps << endl;

    cout << "==========================================================" << endl;

    ofstream outputFile("hasil_gacha.txt", ios::app);
    outputFile.is_open();
    outputFile << "User "  << nama  << endl;
    outputFile << "Anda mendapatkan item: " << item.name << endl;
    outputFile << "Tingkat Keganasan Item: " << item.tipe << endl;
    outputFile << "Damage per Second: " << item.dps << endl;
    outputFile.close();
   
}

int main() {
    string nama;
    Item items[9] = {
  
    {"LOBET = Loyo Betul" ,"D" , 10},
    {"LEMIN = Lele Mini" ,"C" , 50},
    {"LEJUM = Lele Jumbo" ,"A" , 299},
    {"IMRON = Itam Merona" ,"B" ,165},
    {"GATOT = Gagah Berotot" ,"A",287},
    {"IWAN = Imut dan Menawan" ,"B" , 202},
    {"IPUL = Imut dan Powerpul" ,"S" ,610},
    {"SUHADI = Suka Hilang Kendali" ,"SS", 1024},
    {"MASASI = Masuk Sana Sini" ,"SSR" ,9999},
    };

    int choice;
    do {
        cout << "=========================================================" << endl;
        cout << "Selamat datang di Gacha Simulator! Siapakah kamu??" << endl;
        cout << "Nama anda : ";
        cin >> nama;
        cout << "oke "<< nama << " apakah kamu ingin bermain??" << endl;
        cout << "1. Gass" << endl;
        cout << "0. Keluar" << endl;
        cout << "Pilihan Anda: ";
        cin >> choice;

        switch (choice) {
            case 1:
                gacha(items,9 ,nama);
                break;
            case 0:
                cout << "Terima kasih telah bermain!" << endl;
                break;
            default:
                cout << "Pilihan tidak valid. Silakan coba lagi." << endl;
                break;
        }
    } while (choice != 0);

    return 0;
}