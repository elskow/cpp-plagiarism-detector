#include <iostream>
#include <ctime>
#include <fstream>
using namespace std;

void tampilkanPapan (char *Kotak);
void gerakanPemain (char *kotak, char pemain);
void gerakanKomputer (char *kotak, char komputer);
string periksaHasil (char *kotak, char pemain, char komputer);
void simpanHasilKeFile(const string& hasil);
void tampilkanRiwayatDariFile();
bool gameBerakhir(char *kotak, char pemain, char komputer);
void hapusRiwayat(const string& namaFile);


int main() {
    bool LanjutBermain = true;
    const string namaFile = "sejarah.txt";
    hapusRiwayat(namaFile);

    do {
        char kotak[9] = {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '};
        char pemain = 'X';
        char komputer = 'O';
        bool berjalan = true;

        tampilkanPapan(kotak);

        while (berjalan) {
            gerakanPemain(kotak, pemain);
            tampilkanPapan(kotak);

            if (gameBerakhir(kotak, pemain, komputer)) {
                berjalan = false;
                break;
            }

            gerakanKomputer(kotak, komputer);
            tampilkanPapan(kotak);

            if (gameBerakhir(kotak, pemain, komputer)) {
                berjalan = false;
                break;
            }
        }

        string hasil = periksaHasil(kotak, pemain, komputer);
        if (!hasil.empty()) {
            cout << hasil << endl;
        }

        simpanHasilKeFile(hasil);

        char mainLagi;
        cout << "Main lagi? (y/n): ";
        cin >> mainLagi;

        if (mainLagi != 'y' && mainLagi != 'Y') {
            LanjutBermain = false; // memperbarui kondisi loop
        }

    } while (LanjutBermain);

    cout << "Terima kasih telah bermain!\n";
    cout << "Riwayat Permainan:\n";

    tampilkanRiwayatDariFile();

    return 0;
}
 
void tampilkanPapan(char *kotak){
    cout << "     |     |     " << '\n';
    cout << "  "<< kotak[0] << "  |  "<< kotak[1] << "  |  "<< kotak[2] << "  " << '\n';
    cout << "__|_|__" << '\n';
    cout << "     |     |     " << '\n';
    cout << "  "<< kotak[3] << "  |  "<< kotak[4] << "  |  "<< kotak[5] << "  " << '\n';
    cout << "__|_|__" << '\n';
    cout << "     |     |     " << '\n';
    cout << "  "<< kotak[6] << "  |  "<< kotak[7] << "  |  "<< kotak[8] << "  " << '\n';
    cout << "     |     |     " << '\n';
    cout << '\n';
}
void gerakanPemain(char *kotak, char pemain){
    int nomor;
    do {
        cout << "Masukkan nomor untuk meempatkan tanda (1-9): ";
        cin >> nomor;
        nomor--;
        if (kotak[nomor] == ' '){
            kotak[nomor] = pemain;
            break;
        }
    }while (!nomor > 0 || !nomor < 8);

}
void gerakanKomputer(char *kotak, char komputer){
    int nomor;
    srand(time(0));

    while(true) {
        nomor = rand() % 9;
        if (kotak [nomor] == ' '){
            kotak [nomor] = komputer;
            break;

        }
    }
}
string periksaHasil(char *kotak, char pemain, char komputer) {
    for (int i = 0; i < 3; i++) {
        // Check horizontal, vertical, and diagonal lines for a winner
        if ((kotak[i * 3] != ' ') && (kotak[i * 3] == kotak[i * 3 + 1]) && (kotak[i * 3 + 1] == kotak[i * 3 + 2])) {
            return (kotak[i * 3] == pemain) ? "Menang" : "Kalah";
        }

        if ((kotak[i] != ' ') && (kotak[i] == kotak[i + 3]) && (kotak[i + 3] == kotak[i + 6])) {
            return (kotak[i] == pemain) ? "Menang" : "Kalah";
        }
    }

    // Check diagonals
    if ((kotak[0] != ' ') && (kotak[0] == kotak[4]) && (kotak[4] == kotak[8])) {
        return (kotak[0] == pemain) ? "Menang" : "Kalah";
    }
    if ((kotak[2] != ' ') && (kotak[2] == kotak[4]) && (kotak[4] == kotak[6])) {
        return (kotak[2] == pemain) ? "Menang" : "Kalah";
    }

    // Check for a draw
    for (int i = 0; i < 9; i++) {
        if (kotak[i] == ' ') {
            return ""; // Game is still ongoing
        }
    }
    return "SERI!";
}

bool gameBerakhir(char *kotak, char pemain, char komputer) {
    string hasil = periksaHasil(kotak, pemain, komputer);
    return !hasil.empty();
}
void simpanHasilKeFile(const string& hasil) {
    ofstream outFile("sejarah.txt", ios::app);
    if (outFile.is_open()) {
        outFile << hasil << "\n";
        outFile.close();
    } else {
        cerr << "Error membuka riwayat file untuk dibaca.\n";
    }
}

void tampilkanRiwayatDariFile() {
    ifstream inFile("sejarah.txt");
    if (inFile.is_open()) {
        string baris;
        while (getline(inFile, baris)) {
            cout << baris << "\n";
        }
        inFile.close();
    } else {
        cerr << "Error membuka riwayat file untuk dibaca.\n";
    };
}
void hapusRiwayat (const string& namaFile ) {
    ofstream outfile (namaFile.c_str(), ios::trunc);
    outfile.close();
}