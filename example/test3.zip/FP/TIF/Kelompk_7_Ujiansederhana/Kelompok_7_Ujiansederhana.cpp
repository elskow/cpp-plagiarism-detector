#include <iostream>
#include <fstream>
#include <cstdlib>
#include <iomanip>
#include <string>

using namespace std;

struct Pertanyaan
{
    string pertanyaan;
    string pilihan[4];
    int jawabanBenar;
};

void clearScreen()
{
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

void buatKertasUjian(string &nama, string &kelas, string &tanggal, string &nim, string &mapel)
{
    clearScreen();

    cout << "===== Ujian " << mapel << " =====\n";
    cout << "Masukkan Nama\t: ";
    cin.ignore();
    getline(cin, nama);
    cout << "Masukkan NIM\t: ";
    getline(cin, nim);
    cout << "Masukkan Kelas\t: ";
    getline(cin, kelas);
    cout << "Masukkan Tanggal: ";
    getline(cin, tanggal);

    clearScreen();

    cout << "===== Ujian " << mapel << " =====\n";
    cout << "Nama: " << nama << "\tNIM: " << nim << "\tKelas: " << kelas << "\tTanggal: " << tanggal << "\n\n";
}

void laksanakanUjian(const Pertanyaan pertanyaan[], int jumlahPertanyaan, const string &nama, const string &nim, const string &kelas, const string &tanggal, const string &mapel, const string &guru)
{
    int *jawabanPemain = new int[jumlahPertanyaan];

    for (int i = 0; i < jumlahPertanyaan; ++i)
    {
        clearScreen();

        cout << "===== Pertanyaan " << i + 1 << " =====\n";
        cout << pertanyaan[i].pertanyaan << "\n";
        for (int j = 0; j < 4; ++j)
        {
            cout << j + 1 << ". " << pertanyaan[i].pilihan[j] << "\n";
        }

        cout << "Masukkan jawaban Anda (1-4): ";
        cin >> jawabanPemain[i];
        cout << endl;
    }

    int skor = 0;
    clearScreen();
    cout << "===== Hasil Ujian =====\n";
    for (int i = 0; i < jumlahPertanyaan; ++i)
    {
        cout << i + 1 << ". Soal: " << pertanyaan[i].pertanyaan << "\n";
        cout << "   Jawaban Siswa: " << jawabanPemain[i] << "\n";
        cout << "   Jawaban Benar: " << pertanyaan[i].jawabanBenar << "\n";
        if (jawabanPemain[i] == pertanyaan[i].jawabanBenar)
        {
            skor++;
        }
        cout << "\n";
    }

    ofstream file("ujian.txt");
    if (file.is_open())
    {
        file << "===== Hasil Ujian =====" << endl
             << endl;
        file << "Guru penguji\t: " << guru << endl;
        file << "Mata Pelajaran\t: " << mapel << endl
             << endl;
        file << "=======================";
        file << "Nama \t: " << nama << "\n";
        file << "NIM \t: " << nim << "\n";
        file << "Kelas \t: " << kelas << "\n";
        file << "Tanggal \t: " << tanggal << "\n\n";

        for (int i = 0; i < jumlahPertanyaan; ++i)
        {
            file << i + 1 << ". Soal: " << pertanyaan[i].pertanyaan << "\n";
            file << "   Jawaban Siswa: " << jawabanPemain[i] << "\n";
            file << "   Jawaban Benar: " << pertanyaan[i].jawabanBenar << "\n";
            file << "\n";
        }

        double nilai = static_cast<double>(skor) / jumlahPertanyaan * 100;
        file << "Nilai Akhir: " << fixed << setprecision(2) << nilai << " (Skor: " << skor << " dari " << jumlahPertanyaan << ")\n";

        file.close();
        cout << "Hasil ujian disimpan di file 'ujian.txt'\n";
    }
    else
    {
        cout << "Gagal membuka file untuk penyimpanan hasil ujian.\n";
    }

    delete[] jawabanPemain;
}

int main()
{

    cout << " ===============================================\n";
    cout << "|               SELAMAT DATANG DI               |\n";
    cout << "|              PROGRAM UJIAN KELAS              |\n";
    cout << "|                  KELOMPOK 7                   |\n";
    cout << " ===============================================\n\n";

    string guru, mapel;
    cout << "Masukkan nama guru penguji: ";
    getline(cin, guru);
    cout << endl;

    cout << "Masukkan mata pelajaran: ";
    getline(cin, mapel);
    cout << endl;

    clearScreen();

    int jumlahPertanyaan;
    cout << "Masukkan jumlah pertanyaan: ";
    cin >> jumlahPertanyaan;
    cout << endl;

    Pertanyaan *pertanyaan = new Pertanyaan[jumlahPertanyaan];

    for (int i = 0; i < jumlahPertanyaan; ++i)
    {
        cout << "Masukkan pertanyaan " << i + 1 << ": ";
        cin.ignore();
        getline(cin, pertanyaan[i].pertanyaan);

        for (int j = 0; j < 4; ++j)
        {
            cout << "Masukkan pilihan jawaban " << j + 1 << ": ";
            getline(cin, pertanyaan[i].pilihan[j]);
        }

        cout << "Masukkan jawaban benar (1-4): ";
        cin >> pertanyaan[i].jawabanBenar;
        cout << endl;
    }

    string nama, kelas, tanggal, nim;
    buatKertasUjian(nama, kelas, tanggal, nim, mapel);
    laksanakanUjian(pertanyaan, jumlahPertanyaan, nama, nim, kelas, tanggal, mapel, guru);

    delete[] pertanyaan;

    return 0;
}
