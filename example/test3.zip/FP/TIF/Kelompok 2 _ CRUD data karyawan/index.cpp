// KELOMPOK 2
//  CRUD DATA KARYAWAN
//  1. DION WANGSA RIZAL PERMANA (209)
//  2. RAHMA NUR AIZA (197)
//  3. NAYLA AZZAHRA (185)

#include <iostream>
#include <unistd.h>
#include <limits>
#include <string>
#include <fstream>
#include <iomanip>

using namespace std;

struct Login
{
    string username;
    string password;
};

Login user[] = {{"admin1", "sandi1"}, {"admin2", "sandi2"}};
const int totalUser = sizeof(user) / sizeof(user[0]);

struct dataKaryawan
{
    string ID, nama, alamat, jabatan, gaji;
};

const int jumlahMaksKaryawan = 50;
dataKaryawan karyawan[jumlahMaksKaryawan];
int jumlahKaryawanSekarang = 0;

void hitungMundur(int detik);
bool login();
int memuatKaryawan(dataKaryawan *karyawan, int hitung);
bool cekNama(const string &nama);
bool cekAlamat(const string &alamat);
bool validasiID(const string &ID);
bool isNumber(const string &str);

void createKaryawan(dataKaryawan *karyawan, int &jumlahKaryawanSekarang);
void readKaryawan(dataKaryawan karyawan[], int jumlahKaryawanSekarang);
void updateKaryawan(dataKaryawan *karyawan, int jumlahKaryawanSekarang, const string &ID);
void deleteKaryawan(dataKaryawan *karyawan, int &jumlahKaryawanSekarang, const string ID);

int main()
{
    cout << endl
         << "Olah data Karyawan" << endl;
    cout << endl
         << "Silahkan Login terlebih dahulu" << endl;

    bool Login = false;
    while (!Login)
    {
        Login = login();
    }

    int opsi;

    jumlahKaryawanSekarang = memuatKaryawan(karyawan, jumlahKaryawanSekarang);

    do
    {
        cout << endl
             << "Piih salah satu opsi di bawah ini: " << endl
             << "1. Tambahkan Karyawan." << endl
             << "2. Tampilkan data karyawan." << endl
             << "3. Perbarui data karyawan." << endl
             << "4. Hapus salah satu karyawan." << endl
             << "5. Log out" << endl
             << "Pilih salah satu opsi: ";
        if (!(cin >> opsi) || opsi > 5 || opsi < 1)
        {
            cout << endl
                 << "INPUT TIDAK VALID" << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        cout << endl;

        if (opsi == 1)
        {
            createKaryawan(karyawan, jumlahKaryawanSekarang);
        }
        else if (opsi == 2)
        {
            readKaryawan(karyawan, jumlahKaryawanSekarang);
        }
        else if (opsi == 3)
        {
            string ID;
            cout << endl
                 << "Masukkan ID dari karyawan yang ingin diperbarui: ";
            cin.ignore();
            cin >> ID;
            updateKaryawan(karyawan, jumlahKaryawanSekarang, ID);
        }
        else if (opsi == 4)
        {
            string ID;
            cout << endl
                 << "Masukkan ID dari karyawan yang ingin dihapus: ";
            cin.ignore();
            cin >> ID;
            deleteKaryawan(karyawan, jumlahKaryawanSekarang, ID);
        }
        else if (opsi == 5)
        {
            cout << "Berhasil Log out" << endl;
            return 0;
        }
        else
        {
            cout << "Opsi tidak valid" << endl;
        }

    } while (opsi != 5);
}

void hitungMundur(int detik)
{
    for (int i = detik; i > 0; --i)
    {
        cout << "Tunggu " << i << " detik" << endl;
        sleep(1);
    }
    cout << endl
         << "Silahkan Login kembali" << endl;
}

bool login()
{
    string username, password;
    int percobaanLogin = 0;
    int delayWaktu = 30;

    while (percobaanLogin < 3)
    {
        cout << endl
             << "Username: ";
        cin >> username;
        cout << "Password: ";
        cin >> password;

        for (int i = 0; i < totalUser; i++)
        {
            if (username == user[i].username && password == user[i].password)
            {
                cout << endl
                     << "LOGIN BERHASIL"
                     << endl;
                return true;
            }
        }

        cout << endl
             << "Kata sandi atau password anda salah, silahkan coba lagi" << endl;
        percobaanLogin++;

        if (percobaanLogin == 3)
        {
            cout << endl
                 << "Terlalu banyak percobaan yang gagal" << endl;
            cout << "Tunggu " << delayWaktu << " detik sebelum mencoba lagi." << endl
                 << endl;
            hitungMundur(delayWaktu);
            delayWaktu += 30;

            percobaanLogin = 0;
        }
    }
    return false;
}

int memuatKaryawan(dataKaryawan *karyawan, int jumlahKaryawanSekarang)
{
    ifstream fileKaryawan("fileKaryawan.txt");
    if (fileKaryawan.is_open())
    {

        while (jumlahKaryawanSekarang < jumlahMaksKaryawan && getline(fileKaryawan, karyawan[jumlahKaryawanSekarang].nama, ',') &&
               getline(fileKaryawan, karyawan[jumlahKaryawanSekarang].alamat, ',') &&
               getline(fileKaryawan, karyawan[jumlahKaryawanSekarang].jabatan, ',') &&
               getline(fileKaryawan, karyawan[jumlahKaryawanSekarang].ID, ',') &&
               getline(fileKaryawan, karyawan[jumlahKaryawanSekarang].gaji))
        {
            jumlahKaryawanSekarang++;
        }
        fileKaryawan.close();
    }
    else
    {
        cout << endl
             << "Data Karyawan kosong" << endl;
    }
    return jumlahKaryawanSekarang;
}

void createKaryawan(dataKaryawan *karyawan, int &jumlahKaryawanSekarang)
{
    if (jumlahKaryawanSekarang < jumlahMaksKaryawan)
    {
        dataKaryawan karyawanBaru;

        bool namaValid = false;
        bool alamatValid = false;
        bool jabatanValid = false;
        bool idValid = false;
        bool gajiValid = false;

        cin.ignore();
        while (!namaValid)
        {
            cout << endl
                 << "Masukkan Nama Karyawan: ";
            getline(cin, karyawanBaru.nama);

            if (cekNama(karyawanBaru.nama))
            {
                namaValid = true;
            }
            else
            {
                cout << endl
                     << "Nama harus berupa huruf dan tidak boleh kosong" << endl;
            }
        }

        while (!alamatValid)
        {
            cout << "Masukkan Alamat: ";
            getline(cin, karyawanBaru.alamat);

            if (cekAlamat(karyawanBaru.alamat))
            {
                alamatValid = true;
            }
            else
            {
                cout << endl
                     << "Alamat hanya boleh terdiri dari huruf, angka, titik, dan koma" << endl;
            }
        }

        while (!jabatanValid)
        {
            cout << "Masukkan Jabatan: ";
            getline(cin, karyawanBaru.jabatan);

            if (cekNama(karyawanBaru.jabatan))
            {
                jabatanValid = true;
            }
            else
            {
                cout << endl
                     << "Jabatan berupa huruf dan tidak boleh kosong" << endl;
            }
        }

        while (!idValid)
        {
            cout << "ID 4 angka bilangan bulat" << endl
                 << "Masukkan ID: ";
            getline(cin, karyawanBaru.ID);

            if (karyawanBaru.ID.length() != 4 || !isNumber(karyawanBaru.ID))
            {
                cout << endl
                     << "ID harus terdiri dari 4 angka bilangan bulat" << endl
                     << endl;
            }
            else if (validasiID(karyawanBaru.ID))
            {
                cout << endl
                     << "ID tidak tersedia" << endl
                     << endl;
            }
            else
            {
                idValid = true;
            }
        }

        while (!gajiValid)
        {
            cout << "Gaji karyawan" << endl
                 << "(format masukan: bilangan bulat dengan minimal 3000000 / 3 juta)" << endl
                 << "Masukkan gaji: ";
            getline(cin, karyawanBaru.gaji);

            if (!isdigit(karyawanBaru.gaji[0]))
            {
                cout << endl
                     << "Gaji harus berupa angka" << endl
                     << endl;
            }
            else
            {
                int gaji = stoi(karyawanBaru.gaji);
                if (gaji < 3000000)
                {
                    cout << endl
                         << "Gaji harus berupa bilangan bulat dengan nominal terkecil 3000000 (3 juta)" << endl
                         << endl;
                }
                else
                {
                    gajiValid = true;
                }
            }
        }

        karyawan[jumlahKaryawanSekarang++] = karyawanBaru;

        ofstream file("fileKaryawan.txt", ios::app);
        if (file.is_open())
        {
            file << karyawanBaru.nama << "," << karyawanBaru.alamat << "," << karyawanBaru.jabatan << ","
                 << karyawanBaru.ID << "," << karyawanBaru.gaji << endl;
            file.close();
            cout << endl
                 << "Data karyawan berhasil ditambahkan." << endl;
        }
        else
        {
            cout << endl
                 << "Gagal membuka file" << endl;
        }
    }
    else
    {
        cout << endl
             << "Jumlah karyawan anda sudah mencapai batas" << endl;
    }
}

void readKaryawan(dataKaryawan karyawan[], int jumlahKaryawanSekarang)
{
    cout << left << setw(35) << "NAMA"
         << left << setw(30) << "ALAMAT"
         << left << setw(20) << "JABATAN"
         << left << setw(10) << "ID"
         << left << setw(2) << ""
         << left << setw(15) << "GAJI" << endl;

    for (int i = 0; i < jumlahKaryawanSekarang; ++i)
    {
        cout << left << setw(35) << karyawan[i].nama
             << left << setw(30) << karyawan[i].alamat
             << left << setw(20) << karyawan[i].jabatan
             << left << setw(10) << karyawan[i].ID
             << left << setw(2) << "Rp."
             << left << setw(15) << karyawan[i].gaji << endl;
    }
}

void updateKaryawan(dataKaryawan *karyawan, int jumlahKaryawanSekarang, const string &ID)
{
    for (int i = 0; i < jumlahKaryawanSekarang; ++i)
    {
        if (ID == karyawan[i].ID)
        {
            bool namaValid = false;
            bool alamatValid = false;
            bool jabatanValid = false;
            bool idValid = false;
            bool gajiValid = false;

            cin.ignore();
            while (!namaValid)
            {
                cout << endl
                     << "Masukkan Nama Karyawan: ";
                getline(cin, karyawan[i].nama);

                if (cekNama(karyawan[i].nama))
                {
                    namaValid = true;
                }
                else
                {
                    cout << endl
                         << "Nama harus berupa huruf dan tidak boleh kosong" << endl;
                }
            }

            while (!alamatValid)
            {
                cout << "Masukkan Alamat: ";
                getline(cin, karyawan[i].alamat);

                if (cekAlamat(karyawan[i].alamat))
                {
                    alamatValid = true;
                }
                else
                {
                    cout << endl
                         << "Alamat tidak boleh kosong" << endl;
                }
            }

            while (!jabatanValid)
            {
                cout << "Masukkan Jabatan: ";
                getline(cin, karyawan[i].jabatan);

                if (cekNama(karyawan[i].jabatan))
                {
                    jabatanValid = true;
                }
                else
                {
                    cout << endl
                         << "Jabatan berupa huruf dan tidak boleh kosong" << endl;
                }
            }

            while (!gajiValid)
            {
                cout << "Gaji karyawan" << endl
                     << "(format masukan bilangan bulat dengan minimal 3000000 / 3 juta)" << endl
                     << "Masukkan gaji: ";
                getline(cin, karyawan[i].gaji);

                if (!isdigit(karyawan[i].gaji[0]))
                {
                    cout << endl
                         << "Gaji harus berupa angka" << endl
                         << endl;
                }
                else
                {
                    int gaji = stoi(karyawan[i].gaji);
                    if (gaji < 3000000)
                    {
                        cout << endl
                             << "Gaji tidak valid" << endl
                             << endl;
                    }
                    else
                    {
                        gajiValid = true;
                    }
                }
            }

            ofstream fileKaryawan("fileKaryawan.txt");
            if (fileKaryawan.is_open())
            {
                for (int j = 0; j < jumlahKaryawanSekarang; ++j)
                {
                    fileKaryawan << karyawan[j].nama << "," << karyawan[j].alamat << "," << karyawan[j].jabatan << ","
                                 << karyawan[j].ID << "," << karyawan[j].gaji << endl;
                }
                fileKaryawan.close();
                cout << endl
                     << "Data karyawan berhasil diperbarui." << endl;
            }
            else
            {
                cout << endl
                     << "Gagal membuka atau membuat file." << endl;
            }
            return;
        }
    }
    cout << endl
         << "Karyawan dengan ID tersebut tidak ditemukan." << endl;
}

void deleteKaryawan(dataKaryawan *karyawan, int &jumlahKaryawanSekarang, const string ID)
{
    for (int i = 0; i < jumlahKaryawanSekarang; ++i)
    {
        if (ID == karyawan[i].ID)
        {
            for (int j = i; j < jumlahKaryawanSekarang - 1; ++j)
            {
                karyawan[j] = karyawan[j + 1];
            }
            jumlahKaryawanSekarang--;

            ofstream fileKaryawan("fileKaryawan.txt");
            if (fileKaryawan.is_open())
            {
                for (int j = 0; j < jumlahKaryawanSekarang; ++j)
                {
                    fileKaryawan << karyawan[j].nama << "," << karyawan[j].alamat << "," << karyawan[j].jabatan << ","
                                 << karyawan[j].ID << "," << karyawan[j].gaji << endl;
                }
                fileKaryawan.close();
                cout << endl
                     << "Data karyawan berhasil dihapus." << endl;
            }
            else
            {
                cout << endl
                     << "Gagal membuka atau membuat fileKaryawan." << endl;
            }
            return;
        }
    }
    cout << endl
         << "Karyawan dengan ID tersebut tidak ditemukan." << endl;
}
bool cekNama(const string &nama)
{
    if (nama.empty())
    {
        return false;
    }

    for (char c : nama)
    {
        if (!isalpha(c) && !isspace(c))
        {
            return false;
        }
    }

    return true;
}

bool cekAlamat(const string &alamat)
{
    if (alamat.empty())
    {
        return false;
    }

    for (char c : alamat)
    {

        if (!isalnum(c) && c != '.' && c != ',' && !isspace(c))
        {
            return false;
        }
    }

    return true;
}

bool validasiID(const string &ID)
{
    for (int i = 0; i < jumlahKaryawanSekarang; ++i)
    {
        if (ID == karyawan[i].ID)
        {
            return true;
        }
    }
    return false;
}

bool isNumber(const string &str)
{
    for (char c : str)
    {
        if (!isdigit(c))
        {
            return false;
        }
    }
    return true;
}