#include <iostream>
#include <fstream>
#include <string>

using namespace std;

// Struct untuk menyimpan informasi film
struct Film {
    string judul;
    int harga;
};

// Struct untuk menyimpan informasi kursi
struct Kursi {
    int nomor;
    int baris;
    int kolom;
    bool tersedia;
};

// Struct untuk menyimpan informasi waktu tayang
struct WaktuTayang {
    string jam;
    string namaFileKursi;
};

// Fungsi untuk menampilkan daftar film
void tampilkanDaftarFilm(Film daftarFilm[], int jumlahFilm) {
    cout << "Daftar Film:" << endl;
    for (int i = 0; i < jumlahFilm; i++) {
        cout << i + 1 << ". " << daftarFilm[i].judul << " - Harga: Rp" << daftarFilm[i].harga << endl;
    }
}

// Fungsi untuk menampilkan daftar waktu tayang
void tampilkanDaftarJam(WaktuTayang daftarJam[], int jumlahJam) {
    cout << "Daftar Jam Tayang:" << endl;
    for (int i = 0; i < jumlahJam; i++) {
        cout << i + 1 << ". Jam " << daftarJam[i].jam << endl;
    }
}

// Fungsi untuk menampilkan daftar kursi
void tampilkanDaftarKursi(Kursi daftarKursi[], int jumlahBaris, int jumlahKolom) {
    cout << "Daftar Kursi:" << endl;

    // Menampilkan label kolom
    cout << "   ";
    for (int j = 0; j < jumlahKolom; j++) {
        cout << j + 1 << " ";
    }
    cout << endl;

    // Menampilkan kursi
    for (int i = 0; i < jumlahBaris; i++) {
        cout << char('A' + i) << "  "; // Label baris

        for (int j = 0; j < jumlahKolom; j++) {
            int index = i * jumlahKolom + j;
            if (daftarKursi[index].tersedia) {
                cout << "O "; // Kursi tersedia
            } else {
                cout << "X "; // Kursi sudah dipesan
            }
        }
        cout << endl;
    }
}

// Fungsi rekursif untuk menghitung total harga tiket
int hitungTotalHarga(int hargaTiket, int jumlahTiket) {
    if (jumlahTiket == 0) {
        return 0;
    } else {
        return hargaTiket + hitungTotalHarga(hargaTiket, jumlahTiket - 1);
    }
}

// Fungsi untuk mengatur semua kursi menjadi tersedia
void inisialisasiKursi(Kursi daftarKursi[], int jumlahKursi) {
    for (int i = 0; i < jumlahKursi; i++) {
        daftarKursi[i].tersedia = true;
    }
}

// Fungsi untuk menyimpan data kursi ke file
void simpanDataKursi(Kursi daftarKursi[], int jumlahKursi, const string& namaFile) {
    ofstream file(namaFile);

    if (file.is_open()) {
        for (int i = 0; i < jumlahKursi; i++) {
            file << daftarKursi[i].nomor << " "
                 << daftarKursi[i].baris << " "
                 << daftarKursi[i].kolom << " "
                 << daftarKursi[i].tersedia << endl;
        }

        file.close();
    } else {
        cout << "Gagal membuka file untuk penyimpanan data kursi." << endl;
    }
}

// Fungsi untuk memuat data kursi dari file
void muatDataKursi(Kursi daftarKursi[], int jumlahKursi, const string& namaFile) {
    ifstream file(namaFile);

    if (file.is_open()) {
        for (int i = 0; i < jumlahKursi; i++) {
            file >> daftarKursi[i].nomor
                 >> daftarKursi[i].baris
                 >> daftarKursi[i].kolom
                 >> daftarKursi[i].tersedia;
        }

        file.close();
    } else {
        cout << "File tidak ditemukan. Membuat file baru." << endl;

        // Inisialisasi data kursi jika gagal membaca file
        for (int i = 0; i < jumlahKursi; i++) {
            daftarKursi[i].tersedia = true;
        }

        // Save the initialized data to the new file
        simpanDataKursi(daftarKursi, jumlahKursi, namaFile);
    }
}

// Fungsi untuk mendapatkan nama file kursi berdasarkan judul film dan jam tayang
string dapatkanNamaFileKursi(const string& judulFilm, const string& jamTayang) {
    return judulFilm + "_kursi_" + jamTayang + ".json";
}

// Fungsi untuk melakukan pembelian tiket
void beliTiket(Film daftarFilm[], int jumlahFilm, Kursi daftarKursi[], int jumlahKursi, WaktuTayang daftarJam[], int jumlahJam) {
    int pilihanFilm;
    cout << "Pilih nomor film yang ingin ditonton: ";
    cin >> pilihanFilm;

    // Memastikan input berada dalam range yang valid
    if (pilihanFilm >= 1 && pilihanFilm <= jumlahFilm) {
        int pilihanJam;
        tampilkanDaftarJam(daftarJam, jumlahJam);
        cout << "Pilih jam tayang yang diinginkan: " << endl;
        cin >> pilihanJam;

        // Memastikan input jam tayang berada dalam range yang valid
        if (pilihanJam >= 1 && pilihanJam <= jumlahJam) {
            // Muat data kursi untuk film dan jam tayang yang dipilih
            muatDataKursi(daftarKursi, jumlahKursi, dapatkanNamaFileKursi(daftarFilm[pilihanFilm - 1].judul, daftarJam[pilihanJam - 1].jam));

            int jumlahTiket;
            cout << "Masukkan jumlah tiket yang ingin dibeli: ";
            cin >> jumlahTiket;

            // Memastikan jumlah tiket tidak negatif
            if (jumlahTiket > 0) {
                for (int i = 0; i < jumlahTiket; i++) {
                    // Mendapatkan harga tiket berdasarkan jenis film
                    int hargaTiket = daftarFilm[pilihanFilm - 1].harga;

                    // Menampilkan daftar kursi
                    tampilkanDaftarKursi(daftarKursi, 5, 6);

                    bool kursiValid = false;
                    while (!kursiValid) {
                        // Memilih kursi
                        cout << "Pilih kursi (contoh: A1): ";
                        string pilihanKursi;
                        cin >> pilihanKursi;

                        // Memastikan input kursi memiliki format yang benar
                        if (pilihanKursi.length() == 2 && isalpha(pilihanKursi[0]) && isdigit(pilihanKursi[1])) {
                            int baris = toupper(pilihanKursi[0]) - 'A';
                            int kolom = pilihanKursi[1] - '0' - 1;

                            // Memastikan kursi tersedia
                            int index = baris * 6 + kolom;
                            if (daftarKursi[index].tersedia) {
                                // Menandai kursi sebagai sudah dipesan
                                daftarKursi[index].tersedia = false;

                                // Menghitung total harga tiket
                                int totalHarga = hitungTotalHarga(hargaTiket, jumlahTiket);
                                cout << "Total harga tiket: Rp" << totalHarga << endl;

                                // Menyimpan data kursi ke file dengan nama unik untuk setiap film dan jam tayang
                                simpanDataKursi(daftarKursi, jumlahKursi, dapatkanNamaFileKursi(daftarFilm[pilihanFilm - 1].judul, daftarJam[pilihanJam - 1].jam));

                                kursiValid = true; // Keluar dari loop jika kursi valid
                            } else {
                                cout << "Kursi sudah dipesan. Pilihan kursi tidak valid. Silakan pilih kursi lain." << endl;
                            }
                        } else {
                            cout << "Format nomor kursi tidak valid. Silakan masukkan nomor kursi dengan format yang benar." << endl;
                        }
                    }
                }
            } else {
                cout << "Jumlah tiket tidak valid." << endl;
            }
        } else {
            cout << "Nomor jam tayang tidak valid." << endl;
        }
    } else {
        cout << "Nomor film tidak valid." << endl;
    }
}

int main() {
    const int jumlahFilm = 5;
    Film daftarFilm[jumlahFilm] = {{"Dune", 30000}, {"Jatuh Cinta seperti di Film-Film", 30000}, {"Monster", 25000}, {"The Boy and The Heron", 35000}, {"Perfect Days", 25000}};

    const int jumlahJam = 3;
    WaktuTayang daftarJam[jumlahJam] = {{"10:00", "jam10"}, {"13:00", "jam13"}, {"16:00", "jam16"}};

    const int jumlahKursi = 5 * 6;
    Kursi daftarKursi[jumlahKursi];

    // Inisialisasi semua kursi menjadi tersedia
    inisialisasiKursi(daftarKursi, jumlahKursi);

    tampilkanDaftarFilm(daftarFilm, jumlahFilm);
    beliTiket(daftarFilm, jumlahFilm, daftarKursi, jumlahKursi, daftarJam, jumlahJam);
    
    return 0;
}
