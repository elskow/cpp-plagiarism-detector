#include <iostream>
#include <fstream>
#include <string>

using namespace std;

struct Alamat {
    string desa;
    string kecamatan;
    string kabupaten;
};

struct IdentitasPenyewa {
    string nama;
    string pekerjaan;
    Alamat alamat;
};

struct Penyewa {
    IdentitasPenyewa identitas;
    int durasiSewa;
    string tujuanPenggunaan;
};

const int maksimal_penyewa = 5;
Penyewa daftarPenyewa[maksimal_penyewa];
int jumlahPenyewa = 0;

void tambahPenyewa() {
    if (jumlahPenyewa < maksimal_penyewa) {
        cout << "Masukkan nama penyewa: ";
        cin.ignore();
        getline(cin, daftarPenyewa[jumlahPenyewa].identitas.nama);

        cout << "Masukkan pekerjaan penyewa: ";
        getline(cin, daftarPenyewa[jumlahPenyewa].identitas.pekerjaan);

        cout << "Masukkan alamat penyewa:\n";
        cout << "Desa: ";
        getline(cin, daftarPenyewa[jumlahPenyewa].identitas.alamat.desa);
        cout << "Kecamatan: ";
        getline(cin, daftarPenyewa[jumlahPenyewa].identitas.alamat.kecamatan);
        cout << "Kabupaten: ";
        getline(cin, daftarPenyewa[jumlahPenyewa].identitas.alamat.kabupaten);

        cout << "Masukkan tujuan penggunaan ruko: ";
        getline(cin, daftarPenyewa[jumlahPenyewa].tujuanPenggunaan);

        cout << "Masukkan durasi sewa (tahun): ";
        cin >> daftarPenyewa[jumlahPenyewa].durasiSewa;

        if (daftarPenyewa[jumlahPenyewa].durasiSewa > 3){
            cout << "maaf, maksimal penyewaan ruko 3 tahun. \n";
        } else {
        jumlahPenyewa++;
        cout << "Penyewa ditambahkan.\n";
        }
    } else {
        cout << "Daftar penyewa penuh.\n";
    }
}

void tampilkanPenyewa() {
    if (jumlahPenyewa > 0) {
        cout << "Daftar Penyewa:\n";
        for (int i = 0; i < jumlahPenyewa; ++i) {
            cout << i + 1 << " Nama: " << daftarPenyewa[i].identitas.nama
                 << ", Pekerjaan: " << daftarPenyewa[i].identitas.pekerjaan
                 << ", Alamat Desa: " << daftarPenyewa[i].identitas.alamat.desa << ", Kecamatan " << daftarPenyewa[i].identitas.alamat.kecamatan << ", Kabupaten " << daftarPenyewa[i].identitas.alamat.kabupaten
                 << ", Tujuan Penggunaan: " << daftarPenyewa[i].tujuanPenggunaan
                 << ", Durasi Sewa: " << daftarPenyewa[i].durasiSewa << " Tahun\n";
        }
    } else {
        cout << "Belum ada penyewa.\n";
    }
}

int hitungBiaya(int durasi) {
    const int hargaPerTahun = 4750000;

    if (durasi == 3) {
        const double diskon = 0.2;
        return static_cast<int>(durasi * hargaPerTahun * (1.0 - diskon));
    } else {
        return durasi * hargaPerTahun;
    }
}

void cetakStruk(int index) {
    ofstream fileStruk("struk_penyewaanbaru.txt", ios::app); 
    if (fileStruk.is_open()) {
        fileStruk << "===== Struk Penyewaan =====\n";
        fileStruk << "Nama Penyewa: " << daftarPenyewa[index].identitas.nama << "\n";
        fileStruk << "Pekerjaan Penyewa: " << daftarPenyewa[index].identitas.pekerjaan << "\n";
        fileStruk << "Alamat Penyewa: Desa " << daftarPenyewa[index].identitas.alamat.desa << ", Kecamatan " << daftarPenyewa[index].identitas.alamat.kecamatan << ", Kabupaten " << daftarPenyewa[index].identitas.alamat.kabupaten << "\n";
        fileStruk << "Tujuan Penggunaan Ruko: " << daftarPenyewa[index].tujuanPenggunaan << "\n";
        fileStruk << "Durasi Sewa: " << daftarPenyewa[index].durasiSewa << " tahun\n";
        fileStruk << "Biaya Total: Rp. " << hitungBiaya(daftarPenyewa[index].durasiSewa) << "\n";
        fileStruk << "==========================\n";
        cout << "Struk penyewaan telah dicetak dalam file 'struk_penyewaanbaru.txt'.\n";
        fileStruk.close();
    } else {
        cout << "Gagal mencetak struk. Harap coba lagi.\n";
    }
}

int main() {
    int pilihan;

    do {
        cout << "=== Penyewaan Ruko ===\n";
        cout << "1. Tambah Penyewa\n";
        cout << "2. Tampilkan Daftar Penyewa\n";
        cout << "3. Cetak Struk Penyewaan\n";
        cout << "0. Keluar\n";
        cout << "Pilih: ";
        cin >> pilihan;

        if (pilihan == 1) {
            tambahPenyewa();
        } else if (pilihan == 2) {
            tampilkanPenyewa();
        } else if (pilihan == 3) {
            if (jumlahPenyewa > 0) {
                tampilkanPenyewa();
                int indeksPenyewa;
                cout << "Masukkan nomor penyewa untuk mencetak struk: ";
                cin >> indeksPenyewa;
                if (indeksPenyewa >= 1 && indeksPenyewa <= jumlahPenyewa) {
                    cetakStruk(indeksPenyewa - 1);
                } else {
                    cout << "Nomor penyewa tidak valid.\n";
                }
            } else {
                cout << "Belum ada penyewa.\n";
            }
        } else if (pilihan != 0) {
            cout << "Pilihan tidak valid. Coba lagi.\n";
        }

    } while (pilihan != 0) ;
    return 0; 
}