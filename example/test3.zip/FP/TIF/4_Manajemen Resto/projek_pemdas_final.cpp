#include <iostream>
#include <fstream>
#include <string>
#include "json.hpp"
using namespace std;
using json = nlohmann::json;

// Struktur data untuk menyimpan detail menu
struct Menu {
    string nama;
    double harga;
    double modal;
    int stok;
};

// Struktur data untuk menyimpan detail transaksi
struct Transaksi {
    string tanggal;
    int totalHarga;
    int totalLaba;
    int totalTransaksi;
};

// Fungsi untuk menyimpan menu ke file JSON
void simpanMenuKeJSON(const string& namaFile, const Menu* menu, int jumlahMenu) {
    json jsonMenu;

    for (int i = 0; i < jumlahMenu; ++i) {
        jsonMenu.push_back({
            {"nama", menu[i].nama},
            {"harga", menu[i].harga},
            {"modal", menu[i].modal},
            {"stok", menu[i].stok}
        });
    }

    ofstream file(namaFile);
    file << jsonMenu.dump(2);  // Menggunakan dump(2) agar hasil lebih mudah dibaca
    file.close();
}

// Fungsi untuk memuat menu dari file JSON
void muatMenuDariJSON(const string& namaFile, Menu* menu, int jumlahMenu) {
    ifstream file(namaFile);
    if (file.is_open()) {
        json jsonMenu;
        file >> jsonMenu;

        for (int i = 0; i < jumlahMenu; ++i) {
            menu[i] = {
                jsonMenu[i]["nama"],
                jsonMenu[i]["harga"],
                jsonMenu[i]["modal"],
                jsonMenu[i]["stok"]
            };
        }
    }
}

// Fungsi untuk menyimpan transaksi ke file JSON
void simpanTransaksiKeJSON(const string& namaFile, const Transaksi& transaksi) {
    json jsonTransaksi;

    // Cek apakah file sudah ada
    ifstream file(namaFile);
    if (file.is_open()) {
        file >> jsonTransaksi;
        file.close();
    }

    // Tambahkan transaksi baru
    jsonTransaksi.push_back({
        {"tanggal", transaksi.tanggal},
        {"totalHarga", transaksi.totalHarga},
        {"totalLaba", transaksi.totalLaba},
        {"totalTransaksi", transaksi.totalTransaksi}
    });

    // Simpan ke file JSON
    ofstream outputFile(namaFile);
    outputFile << jsonTransaksi.dump(2);
    outputFile.close();
}

// Fungsi untuk memuat transaksi dari file JSON
void muatTransaksiDariJSON(const string& namaFile, vector<Transaksi>& daftarTransaksi) {
    ifstream file(namaFile);
    if (file.is_open()) {
        json jsonTransaksi;
        file >> jsonTransaksi;

        for (const auto& transaksiJson : jsonTransaksi) {
            Transaksi transaksi = {
                transaksiJson["tanggal"],
                transaksiJson["totalHarga"],
                transaksiJson["totalLaba"],
                transaksiJson["totalTransaksi"]
            };
            daftarTransaksi.push_back(transaksi);
        }
        file.close();
    }
}

int main() {
    Transaksi transaksi;
    const int jumlahMakanan = 5;
    const int jumlahMinuman = 3;

    // Deklarasi dan inisialisasi menu makanan
    Menu makanan[jumlahMakanan] = {
        {"Nasi Goreng", 12000.0, 5000.0, 10},
        {"Mie Goreng", 12000.0, 5000.0, 10},
        {"Sate Ayam", 17000.0, 9000.0, 10},
        {"Gulai Kambing", 25000.0, 13000.0, 10},
        {"Rendang Sapi", 25000.0, 15000.0, 10}
    };

    // Deklarasi dan inisialisasi menu minuman
    Menu minuman[jumlahMinuman] = {
        {"Es Teh", 5000.0, 3000.0, 10},
        {"Air Es", 8000.0, 5000.0, 10},
        {"Es Kopi", 10000.0, 7000.0, 10}
    };

    int fitur;
    int omset = 0, totalLaba = 0, totalTransaksi = 0;
    double uang_kas = 0.0; // Variabel uang kas
    vector<Transaksi> daftarTransaksiHarian;


    // Loop utama program
    do {
        // Tampilkan menu fitur
        cout << "Pilih Fitur : " << endl;
        cout << "1. Kasir" << "\t" << "2. Laporan Harian" << "\t" << "3. Ambil Uang Kas" << "\t" << "0. Keluar" << endl;

        cin >> fitur;

        // Reset variabel harian
        int totalHarga = 0;
        double totalModal = 0.0;

        switch (fitur) {
            case 1: {
                // Masukkan tanggal untuk transaksi
                cout << "Masukkan Tanggal (format: DD-MM-YYYY): ";
                cin.ignore();
                getline(cin, transaksi.tanggal);

                // Tampilkan daftar menu
                cout << "=================================" << endl;
                cout << "           DAFTAR MENU           " << endl;
                cout << "=================================" << endl;
                cout << "Menu                    Harga    " << endl;
                cout << "---------------------------------" << endl;

                // Tampilkan menu makanan
                cout << "Makanan : " << endl << endl;
                for (int i = 0; i < jumlahMakanan; i++) {
                    cout << makanan[i].nama << "\t\t" << "Rp." << makanan[i].harga << endl;
                }

                // Tampilkan menu minuman
                cout << endl << "Minuman : " << endl << endl;
                for (int i = 0; i < jumlahMinuman; i++) {
                    cout << minuman[i].nama << "\t\t\t" << "Rp." << minuman[i].harga << endl;
                }

                cout << "---------------------------------" << endl;
                cout << "Masukkan Pesanan : " << endl;

                int porsi;
                string menuYangDipilih;

                while (true) {
                    cin >> porsi;
                    if (porsi == 0) {
                        break;
                    }

                    cin.ignore();
                    getline(cin, menuYangDipilih);

                    bool menuDitemukan = false;

                    // Cek apakah menu adalah makanan
                    for (int j = 0; j < jumlahMakanan; j++) {
                        if (menuYangDipilih == makanan[j].nama) {
                            menuDitemukan = true;
                            if (porsi > makanan[j].stok) {
                                cout << "Stok tidak cukup untuk " << makanan[j].nama << ". Stok saat ini: " << makanan[j].stok << endl;
                            } else {
                                makanan[j].stok -= porsi;
                                totalHarga += makanan[j].harga * porsi;
                                totalModal += makanan[j].modal * porsi;
                                totalLaba += (makanan[j].harga - makanan[j].modal) * porsi;
                                transaksi.totalTransaksi++;
                            }
                            break;
                        }
                    }

                    // Jika bukan makanan, cek apakah menu adalah minuman
                    if (!menuDitemukan) {
                        for (int k = 0; k < jumlahMinuman; k++) {
                            if (menuYangDipilih == minuman[k].nama) {
                                menuDitemukan = true;
                                if (porsi > minuman[k].stok) {
                                    cout << "Stok tidak cukup untuk " << minuman[k].nama << ". Stok saat ini: " << minuman[k].stok << endl;
                                } else {
                                    minuman[k].stok -= porsi;
                                    totalHarga += minuman[k].harga * porsi;
                                    totalModal += minuman[k].modal * porsi;
                                    totalLaba += (minuman[k].harga - minuman[k].modal) * porsi;
                                    transaksi.totalTransaksi++;
                                }
                                break;
                            }
                        }
                    }

                    // Jika tidak ditemukan, tampilkan pesan
                    if (!menuDitemukan) {
                        cout << "Menu tidak ditemukan." << endl;
                    }
                }

                // Tampilkan nota pembayaran
                cout << "=================================" << endl;
                cout << "         NOTA PEMBAYARAN         " << endl;
                cout << "=================================" << endl;
                cout << "Total Harga   : Rp." << totalHarga << endl;
                cout << "Total Modal   : Rp." << totalModal << endl;
                cout << "Terima kasih atas pembeliannya!" << endl;
                cout << "=================================" << endl;

                // Perbarui nilai omset
                omset += totalHarga;

                // Reset nilai totalHarga untuk transaksi selanjutnya
                totalHarga = 0;

                // Tambahkan transaksi ke total transaksi harian
                transaksi.totalHarga = omset;
                transaksi.totalLaba = totalLaba;  // Menggunakan totalLaba dari transaksi terakhir
                transaksi.totalTransaksi++;

                // Simpan transaksi ke file JSON
                string namaFileTransaksi = "transaksi_" + transaksi.tanggal + ".json";
                simpanTransaksiKeJSON(namaFileTransaksi, transaksi);

                break;
            }

            case 2: {
                // Masukkan tanggal untuk melihat laporan harian
                cout << "Masukkan Tanggal Laporan (format: DD-MM-YYYY): ";
                string tanggalLaporan;
                cin.ignore();
                getline(cin, tanggalLaporan);

                // Muat transaksi dari file JSON
                Transaksi transaksiLaporan;
                string namaFileLaporan = "transaksi_" + tanggalLaporan + ".json";
                muatTransaksiDariJSON(namaFileLaporan, daftarTransaksiHarian);

                // Tampilkan laporan harian
                cout << "=================================" << endl;
                cout << "          LAPORAN HARIAN         " << endl;
                cout << "=================================" << endl;
                cout << "Tanggal       : " << tanggalLaporan << endl;
                cout << "Omset         : Rp." << daftarTransaksiHarian.back().totalHarga << endl;
                cout << "Laba / Rugi   : Rp." << daftarTransaksiHarian.back().totalLaba << endl;
                cout << "Total Transaksi: " << daftarTransaksiHarian.back().totalTransaksi << " transaksi" << endl;


                break;
            }

            case 3: {
                // Fitur untuk mengambil uang kas
                cout << "Jumlah uang kas yang dapat diambil (10% dari total laba): Rp." << (0.1 * totalLaba) << endl;
                double jumlahAmbil;
                cout << "Masukkan jumlah uang kas yang ingin diambil: Rp.";
                cin >> jumlahAmbil;

                // Validasi jumlah uang kas yang diambil
                if (jumlahAmbil < 0 || jumlahAmbil > (0.1 * totalLaba)) {
                    cout << "Jumlah uang kas yang dimasukkan tidak valid." << endl;
                } else {
                    // Kurangi uang kas dan tampilkan pesan berhasil
                    uang_kas -= jumlahAmbil;
                    cout << "Pengambilan uang kas berhasil." << endl;
                }

                break;
            }
        }
    } while (fitur != 0);

    // Simpan menu ke file JSON
    simpanMenuKeJSON("menu_makanan.json", makanan, jumlahMakanan);

    return 0;
}