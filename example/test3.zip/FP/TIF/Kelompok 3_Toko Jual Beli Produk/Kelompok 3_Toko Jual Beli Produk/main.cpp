#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <limits>
#include <fstream>

using namespace std;

struct Barang {
    string nama;
    int stok;
    double harga;
};

void simpanDataBarang(Barang* daftarBarang, int jumlahBarang) {
    ofstream file("data_barang.txt");

    if (!file.is_open()) {
        cerr << "Gagal membuka file untuk menyimpan data barang." << endl;
        return;
    }

    for (int i = 0; i < jumlahBarang; i++) {
        file << daftarBarang[i].nama << "," << daftarBarang[i].stok << "," << daftarBarang[i].harga << "\n";
    }

    file.close();
}

void muatDataBarang(Barang* daftarBarang, int& jumlahBarang) {
    ifstream file("data_barang.txt");

    if (!file.is_open()) {
        cerr << "Gagal membuka file untuk memuat data barang." << endl;
        return;
    }

    jumlahBarang = 0;
    while (getline(file, daftarBarang[jumlahBarang].nama, ',') &&
           file >> daftarBarang[jumlahBarang].stok &&
           file.ignore() &&
           file >> daftarBarang[jumlahBarang].harga) {
        jumlahBarang++;
    }

    file.close();
}


int tampilkanMenu() {
    int pilihan;
    cout << "===== Toko Jual Beli =====" << endl;
    cout << "1. Cek/Daftar Barang" << endl;
    cout << "2. Tambah Barang" << endl;
    cout << "3. Buka Toko" << endl;
    cout << "4. Keluar" << endl;

    while (true) {
        cout << "Pilih: ";
        cin >> pilihan;

        if (cin.fail()) {
            cin.clear();  
            cin.ignore(numeric_limits<streamsize>::max(), '\n');  
            cout << "Pilihan tidak valid. Program berakhir." << endl;
            break;  
        } else {
            return pilihan;  
        }
    }
}

bool isNamaBarangSudahAda(const Barang* daftarBarang, int jumlahBarang, const string& namaBarang) {
    for (int i = 0; i < jumlahBarang; i++) {
        if (daftarBarang[i].nama == namaBarang) {
            return true;  
        }
    }
    return false;  
}

void tampilkanDaftarBarang(Barang* daftarBarang, int& jumlahBarang) {
    cout << "========== DAFTAR BARANG ==========\n";
    for (int i = 0; i < jumlahBarang; i++) {
        cout << i + 1 << ". " << daftarBarang[i].nama << " - Rp: " << daftarBarang[i].harga << " - Stok: " << daftarBarang[i].stok << "\n";
    }
    cout << "===================================\n";
    cout << "Pilihan: " << endl;
    cout << "1. Hapus Barang" << endl;
    cout << "2. Edit Barang" << endl;
    cout << "3. Kembali Ke Menu Utama" << endl;

    int pilihan;
    cout << "Masukkan pilihan: ";
    cin >> pilihan;

    switch (pilihan) {
        case 1:

            int indeksHapus;
            cout << "Masukkan nomor barang yang ingin dihapus: ";
            cin >> indeksHapus;

            if (indeksHapus >= 1 && indeksHapus <= jumlahBarang) {
                for (int i = indeksHapus - 1; i < jumlahBarang - 1; i++) {
                    daftarBarang[i] = daftarBarang[i + 1];
                }
                jumlahBarang--;
                cout << "Barang berhasil dihapus!\n";
            } else {
                cout << "Nomor barang tidak valid.\n";
            }
            break;
        case 2:

            int indeksEdit;
            cout << "Masukkan nomor barang yang ingin diedit: ";
            cin >> indeksEdit;

            if (indeksEdit >= 1 && indeksEdit <= jumlahBarang) {
                cout << "Edit Barang #" << indeksEdit << endl;


                string namaBarangBaru;
                cout << "1. Nama Barang: ";
                cin.ignore();
                getline(cin, namaBarangBaru);

                if (namaBarangBaru != daftarBarang[indeksEdit - 1].nama &&
                    isNamaBarangSudahAda(daftarBarang, jumlahBarang, namaBarangBaru)) {
                    cout << "Mohon maaf, barang dengan nama tersebut sudah ada di daftar barang.\n";
                    break;
                }

                daftarBarang[indeksEdit - 1].nama = namaBarangBaru;
                cout << "2. Harga Barang: ";
                cin >> daftarBarang[indeksEdit - 1].harga;

                cout << "3. Stok Barang: ";
                cin >> daftarBarang[indeksEdit - 1].stok;

                cout << "Barang berhasil diedit!\n";
            } else {
                cout << "Nomor barang tidak valid.\n";
            }
            break;
        case 3:

            break;
        default:
            cout << "Pilihan tidak valid.\n";
    }
}



void hapusBarang(Barang* daftarBarang, int& jumlahBarang, int indeksHapus) {

    for (int i = indeksHapus; i < jumlahBarang - 1; i++) {
        daftarBarang[i] = daftarBarang[i + 1];
    }

    jumlahBarang--;
}

void tambahBarang(Barang* daftarBarang, int& jumlahBarang) {
    cout << "Masukkan nama barang: ";
    cin.ignore();
    getline(cin, daftarBarang[jumlahBarang].nama);


    if (isNamaBarangSudahAda(daftarBarang, jumlahBarang, daftarBarang[jumlahBarang].nama)) {
        cout << "Mohon maaf, barang dengan nama tersebut sudah ada di daftar barang.\n";
        return;
    }

    cout << "Masukkan harga barang: ";
    cin >> daftarBarang[jumlahBarang].harga;

    cout << "Masukkan stok barang: ";
    cin >> daftarBarang[jumlahBarang].stok;

    cout << "Barang berhasil ditambahkan!\n";
    jumlahBarang++;
}


void bukaToko(Barang *barang, int jumlahBarang) {
    srand(time(0));

    bool adaPembelian = false;  
    cout << "Seseorang sedang berbelanja..." << endl;
    for (int i = 0; i < jumlahBarang; i++) {
        if (barang[i].stok > 0 && (rand() % 2 == 1)) {
            int jumlahBeli = rand() % (barang[i].stok) + 1; 
            cout << "Seseorang membeli " << jumlahBeli << " " << barang[i].nama << "(s) seharga Rp :" << (jumlahBeli * barang[i].harga) << endl;
            barang[i].stok -= jumlahBeli;
            adaPembelian = true;  
        }
    }

    if (!adaPembelian) {
        cout << "Seseorang telah pergi dari toko mu." << endl;
    } else {
        cout << "Seseorang selesai berbelanja." << endl;
    }
}

void terimakasih() {
    ifstream myfile("text.txt");

    if (!myfile.is_open()) {
        cerr << "Gagal membuka file." << endl;
    } else {
        string line;

        if (getline(myfile, line)) {
            cout << line << endl;
        } else {
            cerr << "Gagal membaca isi file." << endl;
        }

        myfile.close();
    }
}

int main() {
    const int MAX_BARANG = 100;
    const int MAX_PEMBELIAN = 100;
    Barang daftarBarang[MAX_BARANG];
    string daftarPembelian[MAX_PEMBELIAN];

    int jumlahBarang = 0;
    int jumlahPembelian = 0;

    muatDataBarang(daftarBarang, jumlahBarang);

    int pilihan;

    do {
        pilihan = tampilkanMenu();

        switch (pilihan) {
            case 1:
                tampilkanDaftarBarang(daftarBarang, jumlahBarang);
                break;
            case 2:
                tambahBarang(daftarBarang, jumlahBarang);
                simpanDataBarang(daftarBarang, jumlahBarang);
                break;
            case 3:
                bukaToko(daftarBarang, jumlahBarang);
                simpanDataBarang(daftarBarang, jumlahBarang);
                break;
            case 4:
                terimakasih();
                break;
        }

    } while (pilihan != 4);

    return 0;
}