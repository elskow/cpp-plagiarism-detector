#include <iostream>
#include <cstdlib>
#include <limits>
using namespace std;


void tampilkanInstruksi() {
    cout << "<<========================================================>>" << endl;
    cout << "======== Selamat Datang di Game Batu-Gunting-Kertas ========" << endl;
    cout << "<<========================================================>>" << endl;
    cout << "<<Pilih batu, gunting, atau kertas untuk melawan komputer >>" << endl;
    cout << "============ Anda akan bermain melawan komputer ============" << endl;
    cout << "====== Pemenang ditentukan berdasarkan aturan biasa ========" << endl << endl;
}
int getPilihanPengguna() {
    int pilihan;
    do {cout << "Pilih (1: Batu, 2: Gunting, 3: Kertas): ";
    cin >> pilihan;
    
   if (pilihan < 1 || pilihan > 3 || cin.fail()) {
        cout << "Input tidak valid. ";
    }        
    if (pilihan == 1){
                cout <<  endl << "pilihan kamu : batu" << endl;}
    if(pilihan== 2){
                cout <<  endl << "pilihan kamu : gunting" << endl;}
    if(pilihan == 3){
                cout <<  endl << "pilihan kamu : kertas" << endl;}
    else { 
    cin.clear();  
    cin.ignore(numeric_limits<streamsize>::max(), '\n'); }
    }while(pilihan < 1 || pilihan > 3 || cin.fail());
    return pilihan;
}

int getPilihanKomputer() {
     int pilihan;
    
     pilihan = rand() % 3 + 1 ;
     if(pilihan == 1){
                cout <<  endl << "pilihan komputer : "  << "batu" << endl;}
     if(pilihan == 2){
                cout <<  endl << "pilihan komputer : "  << "gunting" << endl;}
     if(pilihan == 3){
                cout <<  endl << "pilihan komputer : "  << "kertas" << endl;}
     return pilihan; 
}

void tentukanPemenang(int pilihanPengguna, int pilihanKomputer, int &skorkamu, int &skorbot) {
   if ((pilihanPengguna == 1 && pilihanKomputer == 2) ||
        (pilihanPengguna == 2 && pilihanKomputer == 3) ||
        (pilihanPengguna == 3 && pilihanKomputer == 1)) {
        cout << endl << "Anda menang!" << endl;
       
        skorkamu++;
    } else if (pilihanPengguna == pilihanKomputer) {
        cout << endl << "Pertandingan seri" << endl;
        
        skorkamu++;
        skorbot++;
    } else {
        cout << endl << "Komputer menang." << endl;
        
        skorbot++;
    }
}
int main() {
    
    tampilkanInstruksi(); 
    
    int putaran;
    char lanjut;
    int skorkamu = 0, skorbot = 0; 
     
     do{
     tampilkanInstruksi();
     do{ cout << "masukan berapa putaran yang diinginkan : ";
     cin >> putaran;
    if (cin.fail() || putaran <= 0) {
            cin.clear();  // Membersihkan status error pada cin
            cin.ignore(numeric_limits<streamsize>::max(), '\n');  // Membersihkan buffer input
            cout << "Input tidak valid. Masukkan angka yang lebih besar dari 0." << endl;
        }

    } while (cin.fail() || putaran <= 0);

    for (int i = 1; i <= putaran; i++) 
    {   
        cout << "Ronde : " << i << endl;
        int pilihankamu = getPilihanPengguna();
       
        int pilihanbot = getPilihanKomputer();

        
        tentukanPemenang(pilihankamu, pilihanbot, skorkamu, skorbot);
    }
    
     cout << endl << "hasil akhir "<< endl << "skor kamu = " << skorkamu << "   skor bot = " << skorbot << endl;
     if (skorkamu < skorbot)
     {
        cout << endl << "KAMU KALAH DALAM PERTANDINGAN" << endl << endl;}
     else if (skorkamu == skorbot)
     {
        cout << endl << "PERTANDINGAN SERI" << endl << endl; }
      else 
      {
        cout << endl <<  "KAMU MEMENANGKAN PERTANDINGAN" << endl << endl;
    }
     do{cout << "mau main lagi(y/n)? ";
    cin >> lanjut;
    if((!(lanjut == 'y')) || (!(lanjut == 'n'))){
       cout << "inputan salah" << endl;}
       }
    while((!(lanjut == 'y')) && (!(lanjut == 'n')));
     system("cls");
    }
    while (lanjut == 'y' || lanjut == 'Y');

        cout <<"=========permainan berakhir===========";
    
    return 0; }
    