#include <iostream>
#include <stdlib.h>
#include <windows.h>
#include <string>
#include <iomanip>
using namespace std;

long long generaterandomsaldotabungan()
{
    // Untuk me-Random jumlah saldo
    long long saldotabungan = 0;
    for (int i = 0; i < 8; ++i)
    {
        saldotabungan = saldotabungan * 10 + rand() % 10;
    }
    return saldotabungan;
}
long long generaterandomsaldogiro()
{
    // Untuk me-Random jumlah saldo
    long long saldogiro = 0;
    for (int i = 0; i < 8; ++i)
    {
        saldogiro = saldogiro * 10 + rand() % 10;
    }
    return saldogiro;
}

void displayformatsaldotabungan(long long saldotabungan)
{
    // Ubah saldo menjadi string
    string saldotabunganStr = to_string(saldotabungan);

    // Tentukan panjang saldo
    int length = saldotabunganStr.length();

    // Tampilkan saldo dengan pemisah titik
    cout << fixed << setprecision(2);
    for (int i = 0; i < length; ++i)
    {
        cout << saldotabunganStr[i];
        if ((length - i - 1) % 3 == 0 && i != length - 1)
        {
            cout << '.';
        }
    }
    cout << endl;
}
void displayformatsaldogiro(long long saldogiro)
{
    // Ubah saldo menjadi string
    string saldogiroStr = to_string(saldogiro);

    // Tentukan panjang saldo
    int length = saldogiroStr.length();

    // Tampilkan saldo dengan pemisah titik
    cout << fixed << setprecision(2);
    for (int i = 0; i < length; ++i)
    {
        cout << saldogiroStr[i];
        if ((length - i - 1) % 3 == 0 && i != length - 1)
        {
            cout << '.';
        }
    }
    cout << endl;
}

int main()
{
    // Passwrod Pin ATM
    int pin, pin_true;
    cout << "            SELAMAT DATANG DI ATM GATO" << endl;
    cout << "==================================================" << endl;
    cout << "            SILAHKAN MASUKKAN PIN ANDA" << endl;
    cout << endl;
    cout << "MASUKKAN PIN ANDA \t: ";
    cin >> pin;
    system("cls");

    if (pin >= 100000 && pin <= 999999)
    {
        int percob_gagal = 0;
        const int batas_percob = 4;

        cout << "==================== ATM GATO ====================" << endl;
        cout << endl;
        while (percob_gagal < batas_percob)
        {

            cout << "KONFIRMASI PIN ANDA \t: ";
            cin >> pin_true;
            system("cls");

            if (pin_true != pin)
            {
                cout << "==================== ATM GATO ====================" << endl;
                cout << endl;
                cout << "          PIN SALAH. SILAHKAN COBA LAGI." << endl;
                cout << endl;
                percob_gagal++;
            }
            else
            {
                break;
            }
        }
        system("cls");
        if (percob_gagal == batas_percob)
        {
            cout << "==================== ATM GATO ====================" << endl;
            cout << endl;
            cout << "         BATAS PERCOBAAN GAGAL TERCAPAI." << endl;
            cout << "          SILAHKAN MULAI ULANG PROGRAM." << endl;
            cout << endl;
            cout << "==================================================" << endl;
            return 0;
        }
    }
    else
    {
        pin = 0;
        cout << "==================== ATM GATO ====================" << endl;
        cout << endl;
        cout << "                 PIN TIDAK VALID" << endl;
        cout << "           HARAP MASUKKAN 6 DIGIT ANGKA" << endl;
        cout << "        (PIN TIDAK BOLEH DI AWALI ANGKA 0)" << endl;
        cout << endl;
        cout << "MASUKKAN PIN ANDA \t: ";
        cin >> pin;
        system("cls");

        if (pin <= 100000 || pin >= 999999)
        {
            int percob_gagal1 = 0;
            const int batas_percob1 = 4;

            cout << "==================== ATM GATO ====================" << endl;
            cout << endl;
            while (percob_gagal1 < batas_percob1)
            {

                cout << "                 PIN TIDAK VALID" << endl;
                cout << "           HARAP MASUKKAN 6 DIGIT ANGKA" << endl;
                cout << "        (PIN TIDAK BOLEH DI AWALI ANGKA 0)" << endl;
                cout << endl;
                cout << "MASUKKAN PIN ANDA \t: ";
                cin >> pin;
                system("cls");

                if (pin <= 100000 || pin >= 999999)
                {
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    percob_gagal1++;
                }
                else
                {
                    break;
                }
                if (pin >= 100000 && pin <= 999999)
                {
                    int percob_gagal2 = 0;
                    const int batas_percob2 = 4;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    while (percob_gagal2 < batas_percob2)
                    {
                        cout << "KONFIRMASI PIN ANDA \t: ";
                        cin >> pin_true;
                        system("cls");

                        if (pin_true != pin)
                        {
                            cout << "==================== ATM GATO ====================" << endl;
                            cout << endl;
                            cout << "          PIN SALAH. SILAHKAN COBA LAGI." << endl;
                            cout << endl;
                            percob_gagal2++;
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            }
            system("cls");
            if (percob_gagal1 == batas_percob1)
            {
                cout << "==================== ATM GATO ====================" << endl;
                cout << endl;
                cout << "         BATAS PERCOBAAN GAGAL TERCAPAI." << endl;
                cout << "          SILAHKAN MULAI ULANG PROGRAM." << endl;
                cout << endl;
                cout << "==================================================" << endl;
                return 0;
            }
        }

        int percob_gagal3 = 0;
        const int batas_percob3 = 4;
        cout << "==================== ATM GATO ====================" << endl;
        cout << endl;
        while (percob_gagal3 < batas_percob3)
        {
            cout << "KONFIRMASI PIN ANDA \t: ";
            cin >> pin_true;
            system("cls");

            if (pin_true != pin)
            {
                cout << "==================== ATM GATO ====================" << endl;
                cout << endl;
                cout << "          PIN SALAH. SILAHKAN COBA LAGI." << endl;
                cout << endl;
                percob_gagal3++;
            }
            else
            {
                break;
            }
        }
        system("cls");
        if (percob_gagal3 == batas_percob3)
        {
            cout << "==================== ATM GATO ====================" << endl;
            cout << endl;
            cout << "         BATAS PERCOBAAN GAGAL TERCAPAI." << endl;
            cout << "          SILAHKAN MULAI ULANG PROGRAM." << endl;
            cout << endl;
            cout << "==================================================" << endl;
            return 0;
        }
    }

    // Menu Penarikan Cepat ATM

    int restartpenarikancepat, restartjumlahlainnya;
    int pil = 0;
    int pil6 = 0;
    int restart;
    long long int no_rek;
    srand(time(0));
    long long saldotabungan = generaterandomsaldotabungan();
    long long saldogiro = generaterandomsaldogiro();

    do
    {

    restartpenarikancepat:

        cout << "==================== ATM GATO ====================" << endl;
        cout << endl;
        cout << "               MENU PENARIKAN CEPAT" << endl;
        cout << "         SILAHKAN PILIH JUMLAH PENARIKAN" << endl;
        cout << "    (PILIH 'MENU LAIN' JIKA INGIN CETAK RECEIPT)" << endl;
        cout << endl;
        cout << " 1. <-- 50.000                      500.000 --> 3." << endl;
        cout << endl;
        cout << " 2. <-- 200.000                   1.000.000 --> 4." << endl;
        cout << endl;
        cout << "                                JUMLAH LAIN --> 5." << endl;
        cout << endl;
        cout << "                               MENU LAINNYA --> 6." << endl;
        cout << endl;
        cout << "7. <-- KELUAR / SELESAI" << endl;
        cout << endl;
        cout << "==================================================" << endl;
        cout << endl;
        cout << "MASUKKAN PILIHAN ANDA : ";
        cin >> pil;
        system("cls");

        switch (pil)
        {
        // Penarikan cepat 1
        case 1:
            int pil1;
            cout << "==================== ATM GATO ====================" << endl;
            cout << endl;
            cout << "               PILIH JENIS REKENING" << endl;
            cout << endl;
            cout << "                         DARI REKENING GIRO --> 1." << endl;
            cout << endl;
            cout << "                     DARI REKENING TABUNGAN --> 2." << endl;
            cout << endl;
            cout << "MASUKKAN PILIHAN ANDA : ";
            cin >> pil1;
            system("cls");

            switch (pil1)
            {
            case 1:
                if (50000 <= saldogiro)
                {
                    saldogiro -= 50000;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    cout << endl;
                    Sleep(5000);
                    system("cls");
                    int pil11;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "              TRANSAKSI TELAH SELESAI" << endl;
                    cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                    cout << endl;
                    cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                    cout << endl;
                    cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                    cout << endl;
                    cout << "MASUKKAN PILIHAN ANDA : ";
                    cin >> pil11;
                    system("cls");

                    if (pil11 == 1)
                    {
                        goto restartpenarikancepat;
                    }
                    else if (pil11 == 2)
                    {
                        cout << "==================== ATM GATO ====================" << endl;
                        cout << endl;
                        cout << "             TRANSAKSI TELAH SELESAI" << endl;
                        cout << endl;
                        cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                        cout << endl;
                        cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                        cout << endl;
                        cout << "==================================================" << endl;
                        cout << endl;
                        return 0;
                    }
                }
                else
                {
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                SALDO TIDAK CUKUP" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "         KEMBALI KE MENU PENARIKAN CEPAT" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    Sleep(5000);
                    system("cls");
                    goto restartpenarikancepat;
                }
            case 2:
                if (50000 <= saldotabungan)
                {
                    saldotabungan -= 50000;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    cout << endl;
                    Sleep(5000);
                    system("cls");
                    int pil12;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "              TRANSAKSI TELAH SELESAI" << endl;
                    cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                    cout << endl;
                    cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                    cout << endl;
                    cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                    cout << endl;
                    cout << "MASUKKAN PILIHAN ANDA : ";
                    cin >> pil12;
                    system("cls");

                    if (pil12 == 1)
                    {
                        goto restartpenarikancepat;
                    }
                    else if (pil12 == 2)
                    {
                        cout << "==================== ATM GATO ====================" << endl;
                        cout << endl;
                        cout << "             TRANSAKSI TELAH SELESAI" << endl;
                        cout << endl;
                        cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                        cout << endl;
                        cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                        cout << endl;
                        cout << "==================================================" << endl;
                        cout << endl;
                        return 0;
                    }
                }
                else
                {
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                SALDO TIDAK CUKUP" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "         KEMBALI KE MENU PENARIKAN CEPAT" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    Sleep(5000);
                    system("cls");
                    goto restartpenarikancepat;
                }
            }
        // Penarikan Cepat 2
        case 2:
            int pil2;
            cout << "==================== ATM GATO ====================" << endl;
            cout << endl;
            cout << "               PILIH JENIS REKENING" << endl;
            cout << endl;
            cout << "                         DARI REKENING GIRO --> 1." << endl;
            cout << endl;
            cout << "                     DARI REKENING TABUNGAN --> 2." << endl;
            cout << endl;
            cout << "MASUKKAN PILIHAN ANDA : ";
            cin >> pil2;
            system("cls");

            switch (pil2)
            {
            case 1:
                if (200000 <= saldogiro)
                {
                    saldogiro -= 200000;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    cout << endl;
                    Sleep(5000);
                    system("cls");
                    int pil21;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "              TRANSAKSI TELAH SELESAI" << endl;
                    cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                    cout << endl;
                    cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                    cout << endl;
                    cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                    cout << endl;
                    cout << "MASUKKAN PILIHAN ANDA : ";
                    cin >> pil21;
                    system("cls");

                    if (pil21 == 1)
                    {
                        goto restartpenarikancepat;
                    }
                    else if (pil21 == 2)
                    {
                        cout << "==================== ATM GATO ====================" << endl;
                        cout << endl;
                        cout << "             TRANSAKSI TELAH SELESAI" << endl;
                        cout << endl;
                        cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                        cout << endl;
                        cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                        cout << endl;
                        cout << "==================================================" << endl;
                        cout << endl;
                        return 0;
                    }
                }
                else
                {
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                SALDO TIDAK CUKUP" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "         KEMBALI KE MENU PENARIKAN CEPAT" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    Sleep(5000);
                    system("cls");
                    goto restartpenarikancepat;
                }

            case 2:
                if (200000 <= saldotabungan)
                {
                    saldotabungan -= 200000;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    cout << endl;
                    Sleep(5000);
                    system("cls");
                    int pil22;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "              TRANSAKSI TELAH SELESAI" << endl;
                    cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                    cout << endl;
                    cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                    cout << endl;
                    cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                    cout << endl;
                    cout << "MASUKKAN PILIHAN ANDA : ";
                    cin >> pil22;
                    system("cls");

                    if (pil22 == 1)
                    {
                        goto restartpenarikancepat;
                    }
                    else if (pil22 == 2)
                    {
                        cout << "==================== ATM GATO ====================" << endl;
                        cout << endl;
                        cout << "             TRANSAKSI TELAH SELESAI" << endl;
                        cout << endl;
                        cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                        cout << endl;
                        cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                        cout << endl;
                        cout << "==================================================" << endl;
                        cout << endl;
                        return 0;
                    }
                }
                else
                {
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                SALDO TIDAK CUKUP" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "         KEMBALI KE MENU PENARIKAN CEPAT" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    cout << endl;
                    Sleep(5000);
                    system("cls");
                    goto restartpenarikancepat;
                }
            }
        // Penarikan cepat 3
        case 3:
            int pil3;
            cout << "==================== ATM GATO ====================" << endl;
            cout << endl;
            cout << "               PILIH JENIS REKENING" << endl;
            cout << endl;
            cout << "                         DARI REKENING GIRO --> 1." << endl;
            cout << endl;
            cout << "                     DARI REKENING TABUNGAN --> 2." << endl;
            cout << endl;
            cout << "MASUKKAN PILIHAN ANDA : ";
            cin >> pil3;
            system("cls");

            switch (pil3)
            {
            case 1:
                if (500000 <= saldogiro)
                {
                    saldogiro -= 500000;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    cout << endl;
                    Sleep(5000);
                    system("cls");
                    int pil31;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "              TRANSAKSI TELAH SELESAI" << endl;
                    cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                    cout << endl;
                    cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                    cout << endl;
                    cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                    cout << endl;
                    cout << "MASUKKAN PILIHAN ANDA : ";
                    cin >> pil31;
                    system("cls");

                    if (pil31 == 1)
                    {
                        goto restartpenarikancepat;
                    }
                    else if (pil31 == 2)
                    {
                        cout << "==================== ATM GATO ====================" << endl;
                        cout << endl;
                        cout << "             TRANSAKSI TELAH SELESAI" << endl;
                        cout << endl;
                        cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                        cout << endl;
                        cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                        cout << endl;
                        cout << "==================================================" << endl;
                        cout << endl;
                        return 0;
                    }
                }
                else
                {
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                SALDO TIDAK CUKUP" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "         KEMBALI KE MENU PENARIKAN CEPAT" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    cout << endl;
                    Sleep(5000);
                    system("cls");
                    goto restartpenarikancepat;
                }

            case 2:
                if (500000 <= saldotabungan)
                {
                    saldotabungan -= 500000;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    cout << endl;
                    Sleep(5000);
                    system("cls");
                    int pil32;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "              TRANSAKSI TELAH SELESAI" << endl;
                    cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                    cout << endl;
                    cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                    cout << endl;
                    cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                    cout << endl;
                    cout << "MASUKKAN PILIHAN ANDA : ";
                    cin >> pil32;
                    system("cls");

                    if (pil32 == 1)
                    {
                        goto restartpenarikancepat;
                    }
                    else if (pil32 == 2)
                    {
                        cout << "==================== ATM GATO ====================" << endl;
                        cout << endl;
                        cout << "             TRANSAKSI TELAH SELESAI" << endl;
                        cout << endl;
                        cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                        cout << endl;
                        cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                        cout << endl;
                        cout << "==================================================" << endl;
                        cout << endl;
                        return 0;
                    }
                }
                else
                {
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                SALDO TIDAK CUKUP" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "         KEMBALI KE MENU PENARIKAN CEPAT" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    cout << endl;
                    Sleep(5000);
                    system("cls");
                    goto restartpenarikancepat;
                }
            }
        // Penarikan Cepat 4
        case 4:
            int pil4;
            cout << "==================== ATM GATO ====================" << endl;
            cout << endl;
            cout << "               PILIH JENIS REKENING" << endl;
            cout << endl;
            cout << "                         DARI REKENING GIRO --> 1." << endl;
            cout << endl;
            cout << "                     DARI REKENING TABUNGAN --> 2." << endl;
            cout << endl;
            cout << "MASUKKAN PILIHAN ANDA : ";
            cin >> pil4;
            system("cls");

            switch (pil4)
            {
            case 1:
                if (1000000 <= saldogiro)
                {
                    saldogiro -= 1000000;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    cout << endl;
                    Sleep(5000);
                    system("cls");
                    int pil41;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "              TRANSAKSI TELAH SELESAI" << endl;
                    cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                    cout << endl;
                    cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                    cout << endl;
                    cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                    cout << endl;
                    cout << "MASUKKAN PILIHAN ANDA : ";
                    cin >> pil41;
                    system("cls");

                    if (pil41 == 1)
                    {
                        goto restartpenarikancepat;
                    }
                    else if (pil41 == 2)
                    {
                        cout << "==================== ATM GATO ====================" << endl;
                        cout << endl;
                        cout << "             TRANSAKSI TELAH SELESAI" << endl;
                        cout << endl;
                        cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                        cout << endl;
                        cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                        cout << endl;
                        cout << "==================================================" << endl;
                        cout << endl;
                        return 0;
                    }
                }
                else
                {
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                SALDO TIDAK CUKUP" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "         KEMBALI KE MENU PENARIKAN CEPAT" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    cout << endl;
                    Sleep(5000);
                    system("cls");
                    goto restartpenarikancepat;
                }

            case 2:
                if (1000000 <= saldotabungan)
                {
                    saldotabungan -= 1000000;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    cout << endl;
                    Sleep(5000);
                    system("cls");
                    int pil42;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "              TRANSAKSI TELAH SELESAI" << endl;
                    cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                    cout << endl;
                    cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                    cout << endl;
                    cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                    cout << endl;
                    cout << "MASUKKAN PILIHAN ANDA : ";
                    cin >> pil42;
                    system("cls");

                    if (pil42 == 1)
                    {
                        goto restartpenarikancepat;
                    }
                    else if (pil42 == 2)
                    {
                        cout << "==================== ATM GATO ====================" << endl;
                        cout << endl;
                        cout << "             TRANSAKSI TELAH SELESAI" << endl;
                        cout << endl;
                        cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                        cout << endl;
                        cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                        cout << endl;
                        cout << "==================================================" << endl;
                        cout << endl;
                        return 0;
                    }
                }
                else
                {
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                SALDO TIDAK CUKUP" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "         KEMBALI KE MENU PENARIKAN CEPAT" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    cout << endl;
                    Sleep(5000);
                    system("cls");
                    goto restartpenarikancepat;
                }
            }
        // 5. Jumlah Lainnya
        case 5:

        restartjumlahlainnya:

            int nominaltunai, pil5;
            nominaltunai >= 1;
            nominaltunai <= 1500000;
            cout << "==================== ATM GATO ====================" << endl;
            cout << endl;
            cout << "         MASUKKAN JUMLAH PENARIKAN TUNAI" << endl;
            cout << "                YANG ANDA INGINKAN" << endl;
            cout << "           (DALAM KELIPATAN RP 50.000)" << endl;
            cout << "              MAKSIMAL RP 1.500.000" << endl;
            cout << endl;
            cout << "MASUKKAN NOMINAL : ";
            cin >> nominaltunai;
            system("cls");

            if (nominaltunai > 1 && nominaltunai <= 1500000 && nominaltunai % 50000 == 0)
            {

                cout << "==================== ATM GATO ====================" << endl;
                cout << endl;
                cout << "        KONFIRMASI JUMLAH PENARIKAN TUNAI : " << endl;
                cout << endl;
                cout << "                 RP " << nominaltunai << endl;
                cout << endl;
                cout << "                                      BENAR --> 1." << endl;
                cout << endl;
                cout << "                                      SALAH --> 2." << endl;
                cout << endl;
                cout << "MASUKKAN PILIHAN ANDA : ";
                cin >> pil5;
                system("cls");

                switch (pil5)
                {
                case 1:
                    int pil51;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "               PILIH JENIS REKENING" << endl;
                    cout << endl;
                    cout << "                         DARI REKENING GIRO --> 1." << endl;
                    cout << endl;
                    cout << "                     DARI REKENING TABUNGAN --> 2." << endl;
                    cout << endl;
                    cout << "MASUKKAN PILIHAN ANDA : ";
                    cin >> pil51;
                    system("cls");

                    switch (pil51)
                    {
                    case 1:
                        if (nominaltunai <= saldogiro)
                        {
                            saldogiro -= nominaltunai;
                            cout << "==================== ATM GATO ====================" << endl;
                            cout << endl;
                            cout << "                   HARAP TUNGGU" << endl;
                            cout << endl;
                            cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                            cout << endl;
                            cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                            cout << endl;
                            cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                            cout << endl;
                            cout << "==================================================" << endl;
                            cout << endl;
                            Sleep(5000);
                            system("cls");
                            int pil511;
                            cout << "==================== ATM GATO ====================" << endl;
                            cout << endl;
                            cout << "              TRANSAKSI TELAH SELESAI" << endl;
                            cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                            cout << endl;
                            cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                            cout << endl;
                            cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                            cout << endl;
                            cout << "MASUKKAN PILIHAN ANDA : ";
                            cin >> pil511;
                            system("cls");

                            if (pil511 == 1)
                            {
                                goto restartpenarikancepat;
                            }
                            else if (pil511 == 2)
                            {
                                cout << "==================== ATM GATO ====================" << endl;
                                cout << endl;
                                cout << "             TRANSAKSI TELAH SELESAI" << endl;
                                cout << endl;
                                cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                                cout << endl;
                                cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                                cout << endl;
                                cout << "==================================================" << endl;
                                cout << endl;
                                return 0;
                            }
                        }
                        else
                        {
                            cout << "==================== ATM GATO ====================" << endl;
                            cout << endl;
                            cout << "                SALDO TIDAK CUKUP" << endl;
                            cout << endl;
                            cout << "                   HARAP TUNGGU" << endl;
                            cout << endl;
                            cout << "         KEMBALI KE MENU PENARIKAN CEPAT" << endl;
                            cout << endl;
                            cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                            cout << endl;
                            cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                            cout << endl;
                            cout << "==================================================" << endl;
                            cout << endl;
                            Sleep(5000);
                            system("cls");
                            goto restartpenarikancepat;
                        }

                    case 2:
                        if (nominaltunai <= saldotabungan)
                        {
                            saldotabungan -= nominaltunai;
                            cout << "==================== ATM GATO ====================" << endl;
                            cout << endl;
                            cout << "                   HARAP TUNGGU" << endl;
                            cout << endl;
                            cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                            cout << endl;
                            cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                            cout << endl;
                            cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                            cout << endl;
                            cout << "==================================================" << endl;
                            cout << endl;
                            Sleep(5000);
                            system("cls");
                            int pil512;
                            cout << "==================== ATM GATO ====================" << endl;
                            cout << endl;
                            cout << "              TRANSAKSI TELAH SELESAI" << endl;
                            cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                            cout << endl;
                            cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                            cout << endl;
                            cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                            cout << endl;
                            cout << "MASUKKAN PILIHAN ANDA : ";
                            cin >> pil512;
                            system("cls");

                            if (pil512 == 1)
                            {
                                goto restartpenarikancepat;
                            }
                            else if (pil512 == 2)
                            {
                                cout << "==================== ATM GATO ====================" << endl;
                                cout << endl;
                                cout << "             TRANSAKSI TELAH SELESAI" << endl;
                                cout << endl;
                                cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                                cout << endl;
                                cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                                cout << endl;
                                cout << "==================================================" << endl;
                                cout << endl;
                                return 0;
                            }
                        }
                        else
                        {
                            cout << "==================== ATM GATO ====================" << endl;
                            cout << endl;
                            cout << "                SALDO TIDAK CUKUP" << endl;
                            cout << endl;
                            cout << "                   HARAP TUNGGU" << endl;
                            cout << endl;
                            cout << "         KEMBALI KE MENU PENARIKAN CEPAT" << endl;
                            cout << endl;
                            cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                            cout << endl;
                            cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                            cout << endl;
                            cout << "==================================================" << endl;
                            cout << endl;
                            Sleep(5000);
                            system("cls");
                            goto restartpenarikancepat;
                        }
                    }

                case 2:
                    goto restartjumlahlainnya;
                }
            }
            else
            {
                int percob_gagal2 = 0;
                const int batas_percob2 = 3;
                cout << "==================== ATM GATO ====================" << endl;
                cout << endl;
                cout << "                NILAI TIDAK SESUAI" << endl;
                cout << "     HARAP MASUKKAN NILAI KELIPATAN RP 50.000" << endl;
                cout << "            DAN MAKSIMAL RP 1.500.000" << endl;
                cout << endl;
                cout << "MASUKKAN NOMINAL :";
                cin >> nominaltunai;
                system("cls");

                cout << "==================== ATM GATO ====================" << endl;
                cout << endl;
                while (percob_gagal2 < batas_percob2)
                {
                    cout << "                NILAI TIDAK SESUAI" << endl;
                    cout << "     HARAP MASUKKAN NILAI KELIPATAN RP 50.000" << endl;
                    cout << "            DAN MAKSIMAL RP 1.500.000" << endl;
                    cout << endl;
                    cout << "MASUKKAN NOMINAL :";
                    cin >> nominaltunai;
                    system("cls");

                    if (nominaltunai < 1 || nominaltunai > 1500000 || nominaltunai % 50000 != 0)
                    {
                        cout << "==================== ATM GATO ====================" << endl;
                        cout << endl;
                        percob_gagal2++;
                    }
                    else if (nominaltunai > 1 && nominaltunai <= 1500000 && nominaltunai % 50000 == 0)
                    {
                        int pil521;
                        cout << "==================== ATM GATO ====================" << endl;
                        cout << endl;
                        cout << "        KONFIRMASI JUMLAH PENARIKAN TUNAI : " << endl;
                        cout << endl;
                        cout << "                 RP " << nominaltunai << endl;
                        cout << endl;
                        cout << "                                      BENAR --> 1." << endl;
                        cout << endl;
                        cout << "                                      SALAH --> 2." << endl;
                        cout << endl;
                        cout << "MASUKKAN PILIHAN ANDA : ";
                        cin >> pil521;
                        system("cls");

                        switch (pil521)
                        {
                        case 1:
                            int pil522;
                            cout << "==================== ATM GATO ====================" << endl;
                            cout << endl;
                            cout << "               PILIH JENIS REKENING" << endl;
                            cout << endl;
                            cout << "                         DARI REKENING GIRO --> 1." << endl;
                            cout << endl;
                            cout << "                     DARI REKENING TABUNGAN --> 2." << endl;
                            cout << endl;
                            cout << "MASUKKAN PILIHAN ANDA : ";
                            cin >> pil522;
                            system("cls");

                            switch (pil522)
                            {
                            case 1:
                                if (nominaltunai <= saldogiro)
                                {
                                    saldogiro -= nominaltunai;
                                    cout << "==================== ATM GATO ====================" << endl;
                                    cout << endl;
                                    cout << "                   HARAP TUNGGU" << endl;
                                    cout << endl;
                                    cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                                    cout << endl;
                                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                    cout << endl;
                                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                    cout << endl;
                                    cout << "==================================================" << endl;
                                    cout << endl;
                                    Sleep(5000);
                                    system("cls");
                                    int pil5211;
                                    cout << "==================== ATM GATO ====================" << endl;
                                    cout << endl;
                                    cout << "              TRANSAKSI TELAH SELESAI" << endl;
                                    cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                                    cout << endl;
                                    cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                                    cout << endl;
                                    cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                                    cout << endl;
                                    cout << "MASUKKAN PILIHAN ANDA : ";
                                    cin >> pil5211;
                                    system("cls");

                                    if (pil5211 == 1)
                                    {
                                        goto restartpenarikancepat;
                                    }
                                    else if (pil5211 == 2)
                                    {
                                        cout << "==================== ATM GATO ====================" << endl;
                                        cout << endl;
                                        cout << "             TRANSAKSI TELAH SELESAI" << endl;
                                        cout << endl;
                                        cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                                        cout << endl;
                                        cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                                        cout << endl;
                                        cout << "==================================================" << endl;
                                        cout << endl;
                                        return 0;
                                    }
                                }
                                else
                                {
                                    cout << "==================== ATM GATO ====================" << endl;
                                    cout << endl;
                                    cout << "                SALDO TIDAK CUKUP" << endl;
                                    cout << endl;
                                    cout << "                   HARAP TUNGGU" << endl;
                                    cout << endl;
                                    cout << "         KEMBALI KE MENU PENARIKAN CEPAT" << endl;
                                    cout << endl;
                                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                    cout << endl;
                                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                    cout << endl;
                                    cout << "==================================================" << endl;
                                    cout << endl;
                                    Sleep(5000);
                                    system("cls");
                                    goto restartpenarikancepat;
                                }

                            case 2:
                                if (nominaltunai <= saldotabungan)
                                {
                                    saldotabungan -= nominaltunai;
                                    cout << "==================== ATM GATO ====================" << endl;
                                    cout << endl;
                                    cout << "                   HARAP TUNGGU" << endl;
                                    cout << endl;
                                    cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                                    cout << endl;
                                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                    cout << endl;
                                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                    cout << endl;
                                    cout << "==================================================" << endl;
                                    cout << endl;
                                    Sleep(5000);
                                    system("cls");
                                    int pil5221;
                                    cout << "==================== ATM GATO ====================" << endl;
                                    cout << endl;
                                    cout << "              TRANSAKSI TELAH SELESAI" << endl;
                                    cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                                    cout << endl;
                                    cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                                    cout << endl;
                                    cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                                    cout << endl;
                                    cout << "MASUKKAN PILIHAN ANDA : ";
                                    cin >> pil5221;
                                    system("cls");

                                    if (pil5221 == 1)
                                    {
                                        goto restartpenarikancepat;
                                    }
                                    else if (pil5221 == 2)
                                    {
                                        cout << "==================== ATM GATO ====================" << endl;
                                        cout << endl;
                                        cout << "             TRANSAKSI TELAH SELESAI" << endl;
                                        cout << endl;
                                        cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                                        cout << endl;
                                        cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                                        cout << endl;
                                        cout << "==================================================" << endl;
                                        cout << endl;
                                        return 0;
                                    }
                                }
                                else
                                {
                                    cout << "==================== ATM GATO ====================" << endl;
                                    cout << endl;
                                    cout << "                SALDO TIDAK CUKUP" << endl;
                                    cout << endl;
                                    cout << "                   HARAP TUNGGU" << endl;
                                    cout << endl;
                                    cout << "         KEMBALI KE MENU PENARIKAN CEPAT" << endl;
                                    cout << endl;
                                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                    cout << endl;
                                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                    cout << endl;
                                    cout << "==================================================" << endl;
                                    cout << endl;
                                    Sleep(5000);
                                    system("cls");
                                    goto restartpenarikancepat;
                                }
                            }
                        case 2:
                            goto restartjumlahlainnya;
                        }
                    }
                    else
                    {
                        break;
                    }
                }

                system("cls");
                if (percob_gagal2 == batas_percob2)
                {
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "          BATAS PERCOBAAN GAGAL TERCAPAI." << endl;
                    cout << "           SILAHKAN MULAI ULANG PROGRAM." << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    cout << endl;
                    return 0;
                }
            }
        // 6. Menu Lainnya
        case 6:
        restarttransfer:
            cout << "==================== ATM GATO ====================" << endl;
            cout << endl;
            cout << "        PILIH TRANSAKSI YANG ANDA INGINKAN" << endl;
            cout << endl;
            cout << "1. <-- TRANSFER" << endl;
            cout << endl;
            cout << "2. <-- INFORMASI SALDO" << endl;
            cout << endl;
            cout << "3. <-- MENU SEBELUMNYA" << endl;
            cout << endl;
            cout << "4. <-- KELUAR / SELESAI" << endl;
            cout << endl;
            cout << "==================================================" << endl;
            cout << endl;
            cout << "MASUKKAN PILIHAN ANDA : ";
            cin >> pil6;
            system("cls");

            switch (pil6)
            {
            case 1:

                int pil61;
                cout << "==================== ATM GATO ====================" << endl;
                cout << endl;
                cout << "                   ATM TRANSFER" << endl;
                cout << endl;
                cout << "                !!! PERHATIAN !!!" << endl;
                cout << "    (NOMER REKENING TIDAK BOLEH AWALAN ANGKA 0)" << endl;
                cout << endl;
                cout << "          MASUKKAN NOMOR REKENING TUJUAN" << endl;
                cout << endl;
                cout << ": ";
                cin >> no_rek;
                cout << endl;
                cout << "                                 JIKA BENAR --> 1." << endl;
                cout << endl;
                cout << "                                 JIKA SALAH --> 2." << endl;
                cout << endl;
                cout << "MASUKKAN PILIHAN ANDA : ";
                cin >> pil61;
                system("cls");

                if (no_rek >= 1000000000 && no_rek <= 9999999999)
                {
                    switch (pil61)
                    {
                    case 1:
                        int nominal1;
                        nominal1 >= 1;
                        nominal1 <= 1500000;
                        cout << "==================== ATM GATO ====================" << endl;
                        cout << endl;
                        cout << "          MASUKKAN JUMLAH NILAI TRANSFER" << endl;
                        cout << "                YANG ANDA INGINKAN" << endl;
                        cout << "                MINIMAL RP 10.000" << endl;
                        cout << "              MAKSIMAL RP 1.500.000" << endl;
                        cout << endl;
                        cout << "MASUKKAN NOMINAL : ";
                        cin >> nominal1;
                        system("cls");

                        if (nominal1 >= 10000 && nominal1 <= 1500000)
                        {
                            int pil611;
                            cout << "==================== ATM GATO ====================" << endl;
                            cout << endl;
                            cout << "        KONFIRMASI JUMLAH NILAI TRANSFER : " << endl;
                            cout << endl;
                            cout << "                 RP " << nominal1 << endl;
                            cout << endl;
                            cout << "                                      BENAR --> 1." << endl;
                            cout << endl;
                            cout << "                                      SALAH --> 2." << endl;
                            cout << endl;
                            cout << "MASUKKAN PILIHAN ANDA : ";
                            cin >> pil611;
                            system("cls");

                            switch (pil611)
                            {
                            case 1:
                                int pil6111;
                                cout << "==================== ATM GATO ====================" << endl;
                                cout << endl;
                                cout << "               PILIH JENIS REKENING" << endl;
                                cout << endl;
                                cout << "                         DARI REKENING GIRO --> 1." << endl;
                                cout << endl;
                                cout << "                     DARI REKENING TABUNGAN --> 2." << endl;
                                cout << endl;
                                cout << "MASUKKAN PILIHAN ANDA : ";
                                cin >> pil6111;
                                system("cls");

                                switch (pil6111)
                                {
                                case 1:
                                    if (nominal1 <= saldogiro)
                                    {
                                        saldogiro -= nominal1;
                                        cout << "==================== ATM GATO ====================" << endl;
                                        cout << endl;
                                        cout << "                   HARAP TUNGGU" << endl;
                                        cout << endl;
                                        cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                                        cout << endl;
                                        cout << "- - - - - - - - - - - - - - - - - - - - - - - - - " << endl;
                                        cout << endl;
                                        cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                        cout << endl;
                                        cout << "==================================================" << endl;
                                        Sleep(5000);
                                        system("cls");
                                        int pil6112;
                                        cout << "==================== ATM GATO ====================" << endl;
                                        cout << endl;
                                        cout << "              TRANSAKSI TELAH SELESAI" << endl;
                                        cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                                        cout << endl;
                                        cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                                        cout << endl;
                                        cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                                        cout << endl;
                                        cout << "MASUKKAN PILIHAN ANDA : ";
                                        cin >> pil6112;
                                        system("cls");

                                        if (pil6112 == 1)
                                        {
                                            goto restarttransfer;
                                        }
                                        else if (pil6112 == 2)
                                        {
                                            cout << "==================== ATM GATO ====================" << endl;
                                            cout << endl;
                                            cout << "             TRANSAKSI TELAH SELESAI" << endl;
                                            cout << endl;
                                            cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                                            cout << endl;
                                            cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                                            cout << endl;
                                            cout << "==================================================" << endl;
                                            cout << endl;
                                            return 0;
                                        }
                                    }
                                    else
                                    {
                                        cout << "==================== ATM GATO ====================" << endl;
                                        cout << endl;
                                        cout << "                SALDO TIDAK CUKUP" << endl;
                                        cout << endl;
                                        cout << "                   HARAP TUNGGU" << endl;
                                        cout << endl;
                                        cout << "              KEMBALI KE MENU UTAMA" << endl;
                                        cout << endl;
                                        cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                        cout << endl;
                                        cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                        cout << endl;
                                        cout << "==================================================" << endl;
                                        cout << endl;
                                        Sleep(5000);
                                        system("cls");
                                        goto restarttransfer;
                                    }

                                case 2:
                                    if (nominal1 <= saldotabungan)
                                    {
                                        saldotabungan -= nominal1;
                                        cout << "==================== ATM GATO ====================" << endl;
                                        cout << endl;
                                        cout << "                   HARAP TUNGGU" << endl;
                                        cout << endl;
                                        cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                                        cout << endl;
                                        cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                        cout << endl;
                                        cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                        cout << endl;
                                        cout << "==================================================" << endl;
                                        Sleep(5000);
                                        system("cls");
                                        int pil6121;
                                        cout << "==================== ATM GATO ====================" << endl;
                                        cout << endl;
                                        cout << "             TRANSAKSI TELAH SELESAI" << endl;
                                        cout << "           PERLU TRANSAKSI YANG LAIN ?" << endl;
                                        cout << endl;
                                        cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                                        cout << endl;
                                        cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                                        cout << endl;
                                        cout << "MASUKKAN PILIHAN ANDA : ";
                                        cin >> pil6121;
                                        system("cls");

                                        if (pil6121 == 1)
                                        {
                                            goto restarttransfer;
                                        }
                                        else if (pil6121 == 2)
                                        {
                                            cout << "==================== ATM GATO ====================" << endl;
                                            cout << endl;
                                            cout << "             TRANSAKSI TELAH SELESAI" << endl;
                                            cout << endl;
                                            cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                                            cout << endl;
                                            cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                                            cout << endl;
                                            cout << "==================================================" << endl;
                                            cout << endl;
                                            return 0;
                                        }
                                    }
                                    else
                                    {
                                        cout << "==================== ATM GATO ====================" << endl;
                                        cout << endl;
                                        cout << "                SALDO TIDAK CUKUP" << endl;
                                        cout << endl;
                                        cout << "                   HARAP TUNGGU" << endl;
                                        cout << endl;
                                        cout << "              KEMBALI KE MENU UTAMA" << endl;
                                        cout << endl;
                                        cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                        cout << endl;
                                        cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                        cout << endl;
                                        cout << "==================================================" << endl;
                                        cout << endl;
                                        Sleep(5000);
                                        system("cls");
                                        goto restarttransfer;
                                    }
                                }

                            case 2:
                                goto restarttransfer;
                            }
                        }
                        else
                        {
                            int percob_gagal5 = 0;
                            const int batas_percob5 = 3;
                            cout << "==================== ATM GATO ====================" << endl;
                            cout << endl;
                            cout << "           NILAI TRANSFER TIDAK SESUAI" << endl;
                            cout << "      HARAP MASUKKAN NILAI MINIMAL RP 10.000" << endl;
                            cout << "            DAN MAKSIMAL RP 1.500.000" << endl;
                            cout << endl;
                            cout << "MASUKKAN NOMINAL :";
                            cin >> nominal1;
                            system("cls");

                            cout << "==================== ATM GATO ====================" << endl;
                            cout << endl;
                            while (percob_gagal5 < batas_percob5)
                            {
                                cout << "           NILAI TRANSFER TIDAK SESUAI" << endl;
                                cout << "      HARAP MASUKKAN NILAI MINIMAL RP 10.000" << endl;
                                cout << "            DAN MAKSIMAL RP 1.500.000" << endl;
                                cout << endl;
                                cout << "MASUKKAN NOMINAL :";
                                cin >> nominal1;
                                system("cls");

                                if (nominal1 < 10000 || nominal1 >= 1500000)
                                {
                                    cout << "==================== ATM GATO ====================" << endl;
                                    cout << endl;
                                    percob_gagal5++;
                                }
                                else if (nominal1 > 10000 && nominal1 <= 1500000)
                                {
                                    int pil6122;
                                    cout << "==================== ATM GATO ====================" << endl;
                                    cout << endl;
                                    cout << "        KONFIRMASI JUMLAH NILAI TRANSFER : " << endl;
                                    cout << endl;
                                    cout << "                 RP " << nominal1 << endl;
                                    cout << endl;
                                    cout << "                                      BENAR --> 1." << endl;
                                    cout << endl;
                                    cout << "                                      SALAH --> 2." << endl;
                                    cout << endl;
                                    cout << "MASUKKAN PILIHAN ANDA : ";
                                    cin >> pil6122;
                                    system("cls");

                                    switch (pil6122)
                                    {
                                    case 1:
                                        int pil61221;
                                        cout << "==================== ATM GATO ====================" << endl;
                                        cout << endl;
                                        cout << "               PILIH JENIS REKENING" << endl;
                                        cout << endl;
                                        cout << "                         DARI REKENING GIRO --> 1." << endl;
                                        cout << endl;
                                        cout << "                     DARI REKENING TABUNGAN --> 2." << endl;
                                        cout << endl;
                                        cout << "MASUKKAN PILIHAN ANDA : ";
                                        cin >> pil61221;
                                        system("cls");

                                        switch (pil61221)
                                        {
                                        case 1:
                                            if (nominal1 <= saldogiro)
                                            {
                                                saldogiro -= nominal1;
                                                cout << "==================== ATM GATO ====================" << endl;
                                                cout << endl;
                                                cout << "                   HARAP TUNGGU" << endl;
                                                cout << endl;
                                                cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                                                cout << endl;
                                                cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                                cout << endl;
                                                cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                                cout << endl;
                                                cout << "==================================================" << endl;
                                                Sleep(5000);
                                                system("cls");
                                                int pil612211;
                                                cout << "==================== ATM GATO ====================" << endl;
                                                cout << endl;
                                                cout << "              TRANSAKSI TELAH SELESAI" << endl;
                                                cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                                                cout << endl;
                                                cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                                                cout << endl;
                                                cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                                                cout << endl;
                                                cout << "MASUKKAN PILIHAN ANDA : ";
                                                cin >> pil612211;
                                                system("cls");

                                                if (pil612211 == 1)
                                                {
                                                    goto restarttransfer;
                                                }
                                                else if (pil612211 == 2)
                                                {
                                                    cout << "==================== ATM GATO ====================" << endl;
                                                    cout << endl;
                                                    cout << "             TRANSAKSI TELAH SELESAI" << endl;
                                                    cout << endl;
                                                    cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                                                    cout << endl;
                                                    cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                                                    cout << endl;
                                                    cout << "==================================================" << endl;
                                                    cout << endl;
                                                    return 0;
                                                }
                                            }
                                            else
                                            {
                                                cout << "==================== ATM GATO ====================" << endl;
                                                cout << endl;
                                                cout << "                SALDO TIDAK CUKUP" << endl;
                                                cout << endl;
                                                cout << "                   HARAP TUNGGU" << endl;
                                                cout << endl;
                                                cout << "              KEMBALI KE MENU UTAMA" << endl;
                                                cout << endl;
                                                cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                                cout << endl;
                                                cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                                cout << endl;
                                                cout << "==================================================" << endl;
                                                cout << endl;
                                                Sleep(5000);
                                                system("cls");
                                                goto restarttransfer;
                                            }

                                        case 2:
                                            if (nominal1 <= saldotabungan)
                                            {
                                                saldotabungan -= nominal1;
                                                cout << "==================== ATM GATO ====================" << endl;
                                                cout << endl;
                                                cout << "                   HARAP TUNGGU" << endl;
                                                cout << endl;
                                                cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                                                cout << endl;
                                                cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                                cout << endl;
                                                cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                                cout << endl;
                                                cout << "==================================================" << endl;
                                                Sleep(5000);
                                                system("cls");
                                                int pil612221;
                                                cout << "==================== ATM GATO ====================" << endl;
                                                cout << endl;
                                                cout << "              TRANSAKSI TELAH SELESAI" << endl;
                                                cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                                                cout << endl;
                                                cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                                                cout << endl;
                                                cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                                                cout << endl;
                                                cout << "MASUKKAN PILIHAN ANDA : ";
                                                cin >> pil612221;
                                                system("cls");

                                                if (pil612221 == 1)
                                                {
                                                    goto restarttransfer;
                                                }
                                                else if (pil612221 == 2)
                                                {
                                                    cout << "==================== ATM GATO ====================" << endl;
                                                    cout << endl;
                                                    cout << "             TRANSAKSI TELAH SELESAI" << endl;
                                                    cout << endl;
                                                    cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                                                    cout << endl;
                                                    cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                                                    cout << endl;
                                                    cout << "==================================================" << endl;
                                                    cout << endl;
                                                    return 0;
                                                }
                                            }
                                            else
                                            {
                                                cout << "==================== ATM GATO ====================" << endl;
                                                cout << endl;
                                                cout << "                SALDO TIDAK CUKUP" << endl;
                                                cout << endl;
                                                cout << "                   HARAP TUNGGU" << endl;
                                                cout << endl;
                                                cout << "              KEMBALI KE MENU UTAMA" << endl;
                                                cout << endl;
                                                cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                                cout << endl;
                                                cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                                cout << endl;
                                                cout << "==================================================" << endl;
                                                cout << endl;
                                                Sleep(5000);
                                                system("cls");
                                                goto restarttransfer;
                                            }
                                        }
                                    case 2:
                                        goto restarttransfer;
                                    }
                                }
                                else
                                {
                                    goto restarttransfer;
                                }
                            }

                            system("cls");
                            if (percob_gagal5 == batas_percob5)
                            {
                                cout << "==================== ATM GATO ====================" << endl;
                                cout << endl;
                                cout << "          BATAS PERCOBAAN GAGAL TERCAPAI." << endl;
                                cout << "           SILAHKAN MULAI ULANG PROGRAM." << endl;
                                cout << endl;
                                cout << "==================================================" << endl;
                                cout << endl;
                                return 0;
                            }
                        }
                    case 2:
                        goto restarttransfer;
                    }
                }
                else if (pil61 == 2)
                {
                    goto restarttransfer;
                }
                else
                {
                    no_rek = 0;
                    int pil63;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "            NOMOR REKENING TIDAK VALID" << endl;
                    cout << endl;
                    cout << "                !!! PERHATIAN !!!" << endl;
                    cout << "    (NOMER REKENING TIDAK BOLEH AWALAN ANGKA 0)" << endl;
                    cout << "          (HARAP MASUKKAN 10 DIGIT ANGKA)" << endl;
                    cout << endl;
                    cout << "          MASUKKAN NOMOR REKENING TUJUAN" << endl;
                    cout << ": ";
                    cin >> no_rek;
                    cout << endl;
                    cout << "                                 JIKA BENAR --> 1." << endl;
                    cout << endl;
                    cout << "                                 JIKA SALAH --> 2." << endl;
                    cout << endl;
                    cout << "MASUKKAN PILIHAN ANDA : ";
                    cin >> pil63;
                    system("cls");

                    if (no_rek <= 1000000000 || no_rek >= 9999999999)
                    {
                        int percob_gagal4 = 0;
                        const int batas_percob4 = 3;
                        if (pil63 == 1)
                        {

                            cout << "==================== ATM GATO ====================" << endl;
                            cout << endl;
                            while (percob_gagal4 < batas_percob4)
                            {
                                int pil631;
                                cout << "            NOMOR REKENING TIDAK VALID" << endl;
                                cout << endl;
                                cout << "                !!! PERHATIAN !!!" << endl;
                                cout << "    (NOMER REKENING TIDAK BOLEH AWALAN ANGKA 0)" << endl;
                                cout << "          (HARAP MASUKKAN 10 DIGIT ANGKA)" << endl;
                                cout << endl;
                                cout << "          MASUKKAN NOMOR REKENING TUJUAN" << endl;
                                cout << ": ";
                                cin >> no_rek;
                                cout << endl;
                                cout << "                             JIKA BENAR --> 1." << endl;
                                cout << endl;
                                cout << "                             JIKA SALAH --> 2." << endl;
                                cout << endl;
                                cout << "MASUKKAN PILIHAN ANDA : ";
                                cin >> pil631;
                                system("cls");

                                if (no_rek <= 1000000000 || no_rek >= 9999999999)
                                {
                                    switch (pil631)
                                    {
                                    case 1:
                                        cout << "==================== ATM GATO ====================" << endl;
                                        cout << endl;
                                        percob_gagal4++;

                                    case 2:
                                        if (pil631 == 2)
                                        {
                                            goto restarttransfer;
                                        }
                                    }
                                }
                                else if (no_rek >= 1000000000 && no_rek <= 9999999999)
                                {
                                    int nominal1;
                                    nominal1 >= 1;
                                    nominal1 <= 1500000;
                                    cout << "==================== ATM GATO ====================" << endl;
                                    cout << endl;
                                    cout << "          MASUKKAN JUMLAH NILAI TRANSFER" << endl;
                                    cout << "                YANG ANDA INGINKAN" << endl;
                                    cout << "                MINIMAL RP 10.000" << endl;
                                    cout << "              MAKSIMAL RP 1.500.000" << endl;
                                    cout << endl;
                                    cout << "MASUKKAN NOMINAL : ";
                                    cin >> nominal1;
                                    system("cls");

                                    if (nominal1 >= 10000 && nominal1 <= 1500000)
                                    {
                                        int pil611;
                                        cout << "==================== ATM GATO ====================" << endl;
                                        cout << endl;
                                        cout << "        KONFIRMASI JUMLAH NILAI TRANSFER : " << endl;
                                        cout << endl;
                                        cout << "                 RP " << nominal1 << endl;
                                        cout << endl;
                                        cout << "                                      BENAR --> 1." << endl;
                                        cout << endl;
                                        cout << "                                      SALAH --> 2." << endl;
                                        cout << endl;
                                        cout << "MASUKKAN PILIHAN ANDA : ";
                                        cin >> pil611;
                                        system("cls");

                                        switch (pil611)
                                        {
                                        case 1:
                                            int pil6111;
                                            cout << "==================== ATM GATO ====================" << endl;
                                            cout << endl;
                                            cout << "               PILIH JENIS REKENING" << endl;
                                            cout << endl;
                                            cout << "                         DARI REKENING GIRO --> 1." << endl;
                                            cout << endl;
                                            cout << "                     DARI REKENING TABUNGAN --> 2." << endl;
                                            cout << endl;
                                            cout << "MASUKKAN PILIHAN ANDA : ";
                                            cin >> pil6111;
                                            system("cls");

                                            switch (pil6111)
                                            {
                                            case 1:
                                                if (nominal1 <= saldogiro)
                                                {
                                                    saldogiro -= nominal1;
                                                    cout << "==================== ATM GATO ====================" << endl;
                                                    cout << endl;
                                                    cout << "                   HARAP TUNGGU" << endl;
                                                    cout << endl;
                                                    cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                                                    cout << endl;
                                                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                                    cout << endl;
                                                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                                    cout << endl;
                                                    cout << "==================================================" << endl;
                                                    Sleep(5000);
                                                    system("cls");
                                                    int pil6112;
                                                    cout << "==================== ATM GATO ====================" << endl;
                                                    cout << endl;
                                                    cout << "              TRANSAKSI TELAH SELESAI" << endl;
                                                    cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                                                    cout << endl;
                                                    cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                                                    cout << endl;
                                                    cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                                                    cout << endl;
                                                    cout << "MASUKKAN PILIHAN ANDA : ";
                                                    cin >> pil6112;
                                                    system("cls");

                                                    if (pil6112 == 1)
                                                    {
                                                        goto restarttransfer;
                                                    }
                                                    else if (pil6112 == 2)
                                                    {
                                                        cout << "==================== ATM GATO ====================" << endl;
                                                        cout << endl;
                                                        cout << "             TRANSAKSI TELAH SELESAI" << endl;
                                                        cout << endl;
                                                        cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                                                        cout << endl;
                                                        cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                                                        cout << endl;
                                                        cout << "==================================================" << endl;
                                                        cout << endl;
                                                        return 0;
                                                    }
                                                }
                                                else
                                                {
                                                    cout << "==================== ATM GATO ====================" << endl;
                                                    cout << endl;
                                                    cout << "                SALDO TIDAK CUKUP" << endl;
                                                    cout << endl;
                                                    cout << "                   HARAP TUNGGU" << endl;
                                                    cout << endl;
                                                    cout << "              KEMBALI KE MENU UTAMA" << endl;
                                                    cout << endl;
                                                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                                    cout << endl;
                                                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                                    cout << endl;
                                                    cout << "==================================================" << endl;
                                                    cout << endl;
                                                    Sleep(5000);
                                                    system("cls");
                                                    goto restarttransfer;
                                                }

                                            case 2:
                                                if (nominal1 <= saldotabungan)
                                                {
                                                    saldotabungan -= nominal1;
                                                    cout << "==================== ATM GATO ====================" << endl;
                                                    cout << endl;
                                                    cout << "                   HARAP TUNGGU" << endl;
                                                    cout << endl;
                                                    cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                                                    cout << endl;
                                                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                                    cout << endl;
                                                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                                    cout << endl;
                                                    cout << "==================================================" << endl;
                                                    Sleep(5000);
                                                    system("cls");
                                                    int pil6121;
                                                    cout << "==================== ATM GATO ====================" << endl;
                                                    cout << endl;
                                                    cout << "              TRANSAKSI TELAH SELESAI" << endl;
                                                    cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                                                    cout << endl;
                                                    cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                                                    cout << endl;
                                                    cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                                                    cout << endl;
                                                    cout << "MASUKKAN PILIHAN ANDA : ";
                                                    cin >> pil6121;
                                                    system("cls");

                                                    if (pil6121 == 1)
                                                    {
                                                        goto restarttransfer;
                                                    }
                                                    else if (pil6121 == 2)
                                                    {
                                                        cout << "==================== ATM GATO ====================" << endl;
                                                        cout << endl;
                                                        cout << "             TRANSAKSI TELAH SELESAI" << endl;
                                                        cout << endl;
                                                        cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                                                        cout << endl;
                                                        cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                                                        cout << endl;
                                                        cout << "==================================================" << endl;
                                                        cout << endl;
                                                        return 0;
                                                    }
                                                }
                                                else
                                                {
                                                    cout << "==================== ATM GATO ====================" << endl;
                                                    cout << endl;
                                                    cout << "                SALDO TIDAK CUKUP" << endl;
                                                    cout << endl;
                                                    cout << "                   HARAP TUNGGU" << endl;
                                                    cout << endl;
                                                    cout << "              KEMBALI KE MENU UTAMA" << endl;
                                                    cout << endl;
                                                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                                    cout << endl;
                                                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                                    cout << endl;
                                                    cout << "==================================================" << endl;
                                                    cout << endl;
                                                    Sleep(5000);
                                                    system("cls");
                                                    goto restarttransfer;
                                                }
                                            }

                                        case 2:
                                            goto restarttransfer;
                                        }
                                    }
                                    else
                                    {
                                        int percob_gagal5 = 0;
                                        const int batas_percob5 = 3;
                                        cout << "==================== ATM GATO ====================" << endl;
                                        cout << endl;
                                        cout << "           NILAI TRANSFER TIDAK SESUAI" << endl;
                                        cout << "      HARAP MASUKKAN NILAI MINIMAL RP 10.000" << endl;
                                        cout << "            DAN MAKSIMAL RP 1.500.000" << endl;
                                        cout << endl;
                                        cout << "MASUKKAN NOMINAL :";
                                        cin >> nominal1;
                                        system("cls");

                                        cout << "==================== ATM GATO ====================" << endl;
                                        cout << endl;
                                        while (percob_gagal5 < batas_percob5)
                                        {
                                            cout << "           NILAI TRANSFER TIDAK SESUAI" << endl;
                                            cout << "      HARAP MASUKKAN NILAI MINIMAL RP 10.000" << endl;
                                            cout << "            DAN MAKSIMAL RP 1.500.000" << endl;
                                            cout << endl;
                                            cout << "MASUKKAN NOMINAL :";
                                            cin >> nominal1;
                                            system("cls");

                                            if (nominal1 < 10000 || nominal1 >= 1500000)
                                            {
                                                cout << "==================== ATM GATO ====================" << endl;
                                                cout << endl;
                                                percob_gagal5++;
                                            }
                                            else if (nominal1 > 10000 && nominal1 <= 1500000)
                                            {
                                                int pil6122;
                                                cout << "==================== ATM GATO ====================" << endl;
                                                cout << endl;
                                                cout << "        KONFIRMASI JUMLAH NILAI TRANSFER : " << endl;
                                                cout << endl;
                                                cout << "                 RP " << nominal1 << endl;
                                                cout << endl;
                                                cout << "                                      BENAR --> 1." << endl;
                                                cout << endl;
                                                cout << "                                      SALAH --> 2." << endl;
                                                cout << endl;
                                                cout << "MASUKKAN PILIHAN ANDA : ";
                                                cin >> pil6122;
                                                system("cls");

                                                switch (pil6122)
                                                {
                                                case 1:
                                                    int pil61221;
                                                    cout << "==================== ATM GATO ====================" << endl;
                                                    cout << endl;
                                                    cout << "               PILIH JENIS REKENING" << endl;
                                                    cout << endl;
                                                    cout << "                         DARI REKENING GIRO --> 1." << endl;
                                                    cout << endl;
                                                    cout << "                     DARI REKENING TABUNGAN --> 2." << endl;
                                                    cout << endl;
                                                    cout << "MASUKKAN PILIHAN ANDA : ";
                                                    cin >> pil61221;
                                                    system("cls");

                                                    switch (pil61221)
                                                    {
                                                    case 1:
                                                        if (nominal1 <= saldogiro)
                                                        {
                                                            saldogiro -= nominal1;
                                                            cout << "==================== ATM GATO ====================" << endl;
                                                            cout << endl;
                                                            cout << "                   HARAP TUNGGU" << endl;
                                                            cout << endl;
                                                            cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                                                            cout << endl;
                                                            cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                                            cout << endl;
                                                            cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                                            cout << endl;
                                                            cout << "==================================================" << endl;
                                                            Sleep(5000);
                                                            system("cls");
                                                            int pil612211;
                                                            cout << "==================== ATM GATO ====================" << endl;
                                                            cout << endl;
                                                            cout << "              TRANSAKSI TELAH SELESAI" << endl;
                                                            cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                                                            cout << endl;
                                                            cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                                                            cout << endl;
                                                            cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                                                            cout << endl;
                                                            cout << "MASUKKAN PILIHAN ANDA : ";
                                                            cin >> pil612211;
                                                            system("cls");

                                                            if (pil612211 == 1)
                                                            {
                                                                goto restarttransfer;
                                                            }
                                                            else if (pil612211 == 2)
                                                            {
                                                                cout << "==================== ATM GATO ====================" << endl;
                                                                cout << endl;
                                                                cout << "             TRANSAKSI TELAH SELESAI" << endl;
                                                                cout << endl;
                                                                cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                                                                cout << endl;
                                                                cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                                                                cout << endl;
                                                                cout << "==================================================" << endl;
                                                                cout << endl;
                                                                return 0;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            cout << "==================== ATM GATO ====================" << endl;
                                                            cout << endl;
                                                            cout << "                SALDO TIDAK CUKUP" << endl;
                                                            cout << endl;
                                                            cout << "                   HARAP TUNGGU" << endl;
                                                            cout << endl;
                                                            cout << "              KEMBALI KE MENU UTAMA" << endl;
                                                            cout << endl;
                                                            cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                                            cout << endl;
                                                            cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                                            cout << endl;
                                                            cout << "==================================================" << endl;
                                                            cout << endl;
                                                            Sleep(5000);
                                                            system("cls");
                                                            goto restarttransfer;
                                                        }

                                                    case 2:
                                                        if (nominal1 <= saldotabungan)
                                                        {
                                                            saldotabungan -= nominal1;
                                                            cout << "==================== ATM GATO ====================" << endl;
                                                            cout << endl;
                                                            cout << "                   HARAP TUNGGU" << endl;
                                                            cout << endl;
                                                            cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                                                            cout << endl;
                                                            cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                                            cout << endl;
                                                            cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                                            cout << endl;
                                                            cout << "==================================================" << endl;
                                                            Sleep(5000);
                                                            system("cls");
                                                            int pil612221;
                                                            cout << "==================== ATM GATO ====================" << endl;
                                                            cout << endl;
                                                            cout << "              TRANSAKSI TELAH SELESAI" << endl;
                                                            cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                                                            cout << endl;
                                                            cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                                                            cout << endl;
                                                            cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                                                            cout << endl;
                                                            cout << "MASUKKAN PILIHAN ANDA : ";
                                                            cin >> pil612221;
                                                            system("cls");

                                                            if (pil612221 == 1)
                                                            {
                                                                goto restarttransfer;
                                                            }
                                                            else if (pil612221 == 2)
                                                            {
                                                                cout << "==================== ATM GATO ====================" << endl;
                                                                cout << endl;
                                                                cout << "             TRANSAKSI TELAH SELESAI" << endl;
                                                                cout << endl;
                                                                cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                                                                cout << endl;
                                                                cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                                                                cout << endl;
                                                                cout << "==================================================" << endl;
                                                                cout << endl;
                                                                return 0;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            cout << "==================== ATM GATO ====================" << endl;
                                                            cout << endl;
                                                            cout << "                SALDO TIDAK CUKUP" << endl;
                                                            cout << endl;
                                                            cout << "                   HARAP TUNGGU" << endl;
                                                            cout << endl;
                                                            cout << "              KEMBALI KE MENU UTAMA" << endl;
                                                            cout << endl;
                                                            cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                                            cout << endl;
                                                            cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                                            cout << endl;
                                                            cout << "==================================================" << endl;
                                                            cout << endl;
                                                            Sleep(5000);
                                                            system("cls");
                                                            goto restarttransfer;
                                                        }
                                                    }
                                                case 2:
                                                    goto restarttransfer;
                                                }
                                            }
                                            else
                                            {
                                                goto restarttransfer;
                                            }
                                        }

                                        system("cls");
                                        if (percob_gagal5 == batas_percob5)
                                        {
                                            cout << "==================== ATM GATO ====================" << endl;
                                            cout << endl;
                                            cout << "         BATAS PERCOBAAN GAGAL TERCAPAI." << endl;
                                            cout << "          SILAHKAN MULAI ULANG PROGRAM." << endl;
                                            cout << endl;
                                            cout << "==================================================" << endl;
                                            cout << endl;
                                            return 0;
                                        }
                                    };
                                }
                            }
                        }
                        else if (pil63 == 2)
                        {
                            goto restarttransfer;
                        }
                        system("cls");
                        if (percob_gagal4 == batas_percob4)
                        {
                            cout << "==================== ATM GATO ====================" << endl;
                            cout << endl;
                            cout << "         BATAS PERCOBAAN GAGAL TERCAPAI." << endl;
                            cout << "          SILAHKAN MULAI ULANG PROGRAM." << endl;
                            cout << endl;
                            cout << "==================================================" << endl;
                            cout << endl;
                            return 0;
                        }
                    }
                    else if (no_rek >= 1000000000 && no_rek <= 9999999999)
                    {
                        switch (pil63)
                        {
                        case 1:
                            int nominal1;
                            nominal1 >= 1;
                            nominal1 <= 1500000;
                            cout << "==================== ATM GATO ====================" << endl;
                            cout << endl;
                            cout << "          MASUKKAN JUMLAH NILAI TRANSFER" << endl;
                            cout << "                YANG ANDA INGINKAN" << endl;
                            cout << "                MINIMAL RP 10.000" << endl;
                            cout << "              MAKSIMAL RP 1.500.000" << endl;
                            cout << endl;
                            cout << "MASUKKAN NOMINAL : ";
                            cin >> nominal1;
                            system("cls");

                            if (nominal1 >= 10000 && nominal1 <= 1500000)
                            {
                                int pil611;
                                cout << "==================== ATM GATO ====================" << endl;
                                cout << endl;
                                cout << "        KONFIRMASI JUMLAH NILAI TRANSFER : " << endl;
                                cout << endl;
                                cout << "                 RP " << nominal1 << endl;
                                cout << endl;
                                cout << "                                      BENAR --> 1." << endl;
                                cout << endl;
                                cout << "                                      SALAH --> 2." << endl;
                                cout << endl;
                                cout << "MASUKKAN PILIHAN ANDA : ";
                                cin >> pil611;
                                system("cls");

                                switch (pil611)
                                {
                                case 1:
                                    int pil6111;
                                    cout << "==================== ATM GATO ====================" << endl;
                                    cout << endl;
                                    cout << "               PILIH JENIS REKENING" << endl;
                                    cout << endl;
                                    cout << "                         DARI REKENING GIRO --> 1." << endl;
                                    cout << endl;
                                    cout << "                     DARI REKENING TABUNGAN --> 2." << endl;
                                    cout << endl;
                                    cout << "MASUKKAN PILIHAN ANDA : ";
                                    cin >> pil6111;
                                    system("cls");

                                    switch (pil6111)
                                    {
                                    case 1:
                                        if (nominal1 <= saldogiro)
                                        {
                                            saldogiro -= nominal1;
                                            cout << "==================== ATM GATO ====================" << endl;
                                            cout << endl;
                                            cout << "                   HARAP TUNGGU" << endl;
                                            cout << endl;
                                            cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                                            cout << endl;
                                            cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                            cout << endl;
                                            cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                            cout << endl;
                                            cout << "==================================================" << endl;
                                            Sleep(5000);
                                            system("cls");
                                            int pil6112;
                                            cout << "==================== ATM GATO ====================" << endl;
                                            cout << endl;
                                            cout << "              TRANSAKSI TELAH SELESAI" << endl;
                                            cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                                            cout << endl;
                                            cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                                            cout << endl;
                                            cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                                            cout << endl;
                                            cout << "MASUKKAN PILIHAN ANDA : ";
                                            cin >> pil6112;
                                            system("cls");

                                            if (pil6112 == 1)
                                            {
                                                goto restarttransfer;
                                            }
                                            else if (pil6112 == 2)
                                            {
                                                cout << "==================== ATM GATO ====================" << endl;
                                                cout << endl;
                                                cout << "             TRANSAKSI TELAH SELESAI" << endl;
                                                cout << endl;
                                                cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                                                cout << endl;
                                                cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                                                cout << endl;
                                                cout << "==================================================" << endl;
                                                cout << endl;
                                                return 0;
                                            }
                                        }
                                        else
                                        {
                                            cout << "==================== ATM GATO ====================" << endl;
                                            cout << endl;
                                            cout << "                SALDO TIDAK CUKUP" << endl;
                                            cout << endl;
                                            cout << "                   HARAP TUNGGU" << endl;
                                            cout << endl;
                                            cout << "              KEMBALI KE MENU UTAMA" << endl;
                                            cout << endl;
                                            cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                            cout << endl;
                                            cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                            cout << endl;
                                            cout << "==================================================" << endl;
                                            cout << endl;
                                            Sleep(5000);
                                            system("cls");
                                            goto restarttransfer;
                                        }

                                    case 2:
                                        if (nominal1 <= saldotabungan)
                                        {
                                            saldotabungan -= nominal1;
                                            cout << "==================== ATM GATO ====================" << endl;
                                            cout << endl;
                                            cout << "                   HARAP TUNGGU" << endl;
                                            cout << endl;
                                            cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                                            cout << endl;
                                            cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                            cout << endl;
                                            cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                            cout << endl;
                                            cout << "==================================================" << endl;
                                            Sleep(5000);
                                            system("cls");
                                            int pil6121;
                                            cout << "==================== ATM GATO ====================" << endl;
                                            cout << endl;
                                            cout << "              TRANSAKSI TELAH SELESAI" << endl;
                                            cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                                            cout << endl;
                                            cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                                            cout << endl;
                                            cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                                            cout << endl;
                                            cout << "MASUKKAN PILIHAN ANDA : ";
                                            cin >> pil6121;
                                            system("cls");

                                            if (pil6121 == 1)
                                            {
                                                goto restarttransfer;
                                            }
                                            else if (pil6121 == 2)
                                            {
                                                cout << "==================== ATM GATO ====================" << endl;
                                                cout << endl;
                                                cout << "             TRANSAKSI TELAH SELESAI" << endl;
                                                cout << endl;
                                                cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                                                cout << endl;
                                                cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                                                cout << endl;
                                                cout << "==================================================" << endl;
                                                cout << endl;
                                                return 0;
                                            }
                                        }
                                        else
                                        {
                                            cout << "==================== ATM GATO ====================" << endl;
                                            cout << endl;
                                            cout << "                SALDO TIDAK CUKUP" << endl;
                                            cout << endl;
                                            cout << "                   HARAP TUNGGU" << endl;
                                            cout << endl;
                                            cout << "              KEMBALI KE MENU UTAMA" << endl;
                                            cout << endl;
                                            cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                            cout << endl;
                                            cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                            cout << endl;
                                            cout << "==================================================" << endl;
                                            cout << endl;
                                            Sleep(5000);
                                            system("cls");
                                            goto restarttransfer;
                                        }
                                    }

                                case 2:
                                    goto restarttransfer;
                                }
                            }
                            else
                            {
                                int percob_gagal5 = 0;
                                const int batas_percob5 = 3;
                                cout << "==================== ATM GATO ====================" << endl;
                                cout << endl;
                                cout << "            NILAI TRANSFER TIDAK SESUAI" << endl;
                                cout << "      HARAP MASUKKAN NILAI MINIMAL RP 10.000" << endl;
                                cout << "             DAN MAKSIMAL RP 1.500.000" << endl;
                                cout << endl;
                                cout << "MASUKKAN NOMINAL :";
                                cin >> nominal1;
                                system("cls");

                                cout << "==================== ATM GATO ====================" << endl;
                                cout << endl;
                                while (percob_gagal5 < batas_percob5)
                                {
                                    cout << "            NILAI TRANSFER TIDAK SESUAI" << endl;
                                    cout << "      HARAP MASUKKAN NILAI MINIMAL RP 10.000" << endl;
                                    cout << "             DAN MAKSIMAL RP 1.500.000" << endl;
                                    cout << endl;
                                    cout << "MASUKKAN NOMINAL :";
                                    cin >> nominal1;
                                    system("cls");

                                    if (nominal1 < 10000 || nominal1 >= 1500000)
                                    {
                                        cout << "==================== ATM GATO ====================" << endl;
                                        cout << endl;
                                        percob_gagal5++;
                                    }
                                    else if (nominal1 > 10000 && nominal1 <= 1500000)
                                    {
                                        int pil6122;
                                        cout << "==================== ATM GATO ====================" << endl;
                                        cout << endl;
                                        cout << "        KONFIRMASI JUMLAH NILAI TRANSFER : " << endl;
                                        cout << endl;
                                        cout << "                 RP " << nominal1 << endl;
                                        cout << endl;
                                        cout << "                                      BENAR --> 1." << endl;
                                        cout << endl;
                                        cout << "                                      SALAH --> 2." << endl;
                                        cout << endl;
                                        cout << "MASUKKAN PILIHAN ANDA : ";
                                        cin >> pil6122;
                                        system("cls");

                                        switch (pil6122)
                                        {
                                        case 1:
                                            int pil61221;
                                            cout << "==================== ATM GATO ====================" << endl;
                                            cout << endl;
                                            cout << "               PILIH JENIS REKENING" << endl;
                                            cout << endl;
                                            cout << "                         DARI REKENING GIRO --> 1." << endl;
                                            cout << endl;
                                            cout << "                     DARI REKENING TABUNGAN --> 2." << endl;
                                            cout << endl;
                                            cout << "MASUKKAN PILIHAN ANDA : ";
                                            cin >> pil61221;
                                            system("cls");

                                            switch (pil61221)
                                            {
                                            case 1:
                                                if (nominal1 <= saldogiro)
                                                {
                                                    saldogiro -= nominal1;
                                                    cout << "==================== ATM GATO ====================" << endl;
                                                    cout << endl;
                                                    cout << "                   HARAP TUNGGU" << endl;
                                                    cout << endl;
                                                    cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                                                    cout << endl;
                                                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                                    cout << endl;
                                                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                                    cout << endl;
                                                    cout << "==================================================" << endl;
                                                    Sleep(5000);
                                                    system("cls");
                                                    int pil612211;
                                                    cout << "==================== ATM GATO ====================" << endl;
                                                    cout << endl;
                                                    cout << "              TRANSAKSI TELAH SELESAI" << endl;
                                                    cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                                                    cout << endl;
                                                    cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                                                    cout << endl;
                                                    cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                                                    cout << endl;
                                                    cout << "MASUKKAN PILIHAN ANDA : ";
                                                    cin >> pil612211;
                                                    system("cls");

                                                    if (pil612211 == 1)
                                                    {
                                                        goto restarttransfer;
                                                    }
                                                    else if (pil612211 == 2)
                                                    {
                                                        cout << "==================== ATM GATO ====================" << endl;
                                                        cout << endl;
                                                        cout << "             TRANSAKSI TELAH SELESAI" << endl;
                                                        cout << endl;
                                                        cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                                                        cout << endl;
                                                        cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                                                        cout << endl;
                                                        cout << "==================================================" << endl;
                                                        cout << endl;
                                                        return 0;
                                                    }
                                                }
                                                else
                                                {
                                                    cout << "==================== ATM GATO ====================" << endl;
                                                    cout << endl;
                                                    cout << "                SALDO TIDAK CUKUP" << endl;
                                                    cout << endl;
                                                    cout << "                   HARAP TUNGGU" << endl;
                                                    cout << endl;
                                                    cout << "              KEMBALI KE MENU UTAMA" << endl;
                                                    cout << endl;
                                                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                                    cout << endl;
                                                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                                    cout << endl;
                                                    cout << "==================================================" << endl;
                                                    cout << endl;
                                                    Sleep(5000);
                                                    system("cls");
                                                    goto restarttransfer;
                                                }

                                            case 2:
                                                if (nominal1 <= saldotabungan)
                                                {
                                                    saldotabungan -= nominal1;
                                                    cout << "==================== ATM GATO ====================" << endl;
                                                    cout << endl;
                                                    cout << "                   HARAP TUNGGU" << endl;
                                                    cout << endl;
                                                    cout << "             TRANSAKSI SEDANG DIPROSES" << endl;
                                                    cout << endl;
                                                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                                    cout << endl;
                                                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                                    cout << endl;
                                                    cout << "==================================================" << endl;
                                                    Sleep(5000);
                                                    system("cls");
                                                    int pil612221;
                                                    cout << "==================== ATM GATO ====================" << endl;
                                                    cout << endl;
                                                    cout << "              TRANSAKSI TELAH SELESAI" << endl;
                                                    cout << "            PERLU TRANSAKSI YANG LAIN ?" << endl;
                                                    cout << endl;
                                                    cout << "\t\t\t    TEKAN JIKA IYA --> 1." << endl;
                                                    cout << endl;
                                                    cout << "\t\t\t  TEKAN JIKA TIDAK --> 2." << endl;
                                                    cout << endl;
                                                    cout << "MASUKKAN PILIHAN ANDA : ";
                                                    cin >> pil612221;
                                                    system("cls");

                                                    if (pil612221 == 1)
                                                    {
                                                        goto restarttransfer;
                                                    }
                                                    else if (pil612221 == 2)
                                                    {
                                                        cout << "==================== ATM GATO ====================" << endl;
                                                        cout << endl;
                                                        cout << "             TRANSAKSI TELAH SELESAI" << endl;
                                                        cout << endl;
                                                        cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                                                        cout << endl;
                                                        cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                                                        cout << endl;
                                                        cout << "==================================================" << endl;
                                                        cout << endl;
                                                        return 0;
                                                    }
                                                }
                                                else
                                                {
                                                    cout << "==================== ATM GATO ====================" << endl;
                                                    cout << endl;
                                                    cout << "                SALDO TIDAK CUKUP" << endl;
                                                    cout << endl;
                                                    cout << "                   HARAP TUNGGU" << endl;
                                                    cout << endl;
                                                    cout << "              KEMBALI KE MENU UTAMA" << endl;
                                                    cout << endl;
                                                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                                                    cout << endl;
                                                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                                                    cout << endl;
                                                    cout << "==================================================" << endl;
                                                    cout << endl;
                                                    Sleep(5000);
                                                    system("cls");
                                                    goto restarttransfer;
                                                }
                                            }
                                        case 2:
                                            goto restarttransfer;
                                        }
                                    }
                                    else
                                    {
                                        goto restarttransfer;
                                    }
                                }

                                system("cls");
                                if (percob_gagal5 == batas_percob5)
                                {
                                    cout << "==================== ATM GATO ====================" << endl;
                                    cout << endl;
                                    cout << "          BATAS PERCOBAAN GAGAL TERCAPAI." << endl;
                                    cout << "           SILAHKAN MULAI ULANG PROGRAM." << endl;
                                    cout << endl;
                                    cout << "==================================================" << endl;
                                    cout << endl;
                                    return 0;
                                }
                            }
                        }
                    }
                }

            case 2:

                int pil62;
                cout << "==================== ATM GATO ====================" << endl;
                cout << endl;
                cout << "               PILIH JENIS REKENING" << endl;
                cout << endl;
                cout << "                         DARI REKENING GIRO --> 1." << endl;
                cout << endl;
                cout << "                     DARI REKENING TABUNGAN --> 2." << endl;
                cout << endl;
                cout << "MASUKKAN PILIHAN ANDA : ";
                cin >> pil62;
                system("cls");

                switch (pil62)
                {
                case 1:
                    int pil6211;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "          INFORMASI SALDO SEDANG DIPROSES" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    Sleep(5000);
                    system("cls");

                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "               SALDO REKENING ANDA" << endl;
                    cout << endl;
                    cout << "                  RP. ";
                    displayformatsaldogiro(saldogiro);
                    cout << endl;
                    cout << endl;
                    cout << endl;
                    cout << endl;
                    cout << "                LANJUT TRANSAKSI ?       YA --> 1." << endl;
                    cout << endl;
                    cout << "                                      TIDAK --> 2." << endl;
                    cout << endl;
                    cout << "MASUKKAN PILIHAN ANDA : ";
                    cin >> pil6211;
                    system("cls");

                    switch (pil6211)
                    {
                    case 1:
                        goto restarttransfer;

                    case 2:
                        cout << "==================== ATM GATO ====================" << endl;
                        cout << endl;
                        cout << "                   HARAP TUNGGU" << endl;
                        cout << endl;
                        cout << "            PERMINTAAN SEDANG DIPROSES" << endl;
                        cout << endl;
                        cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                        cout << endl;
                        cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                        cout << endl;
                        cout << "==================================================" << endl;
                        Sleep(5000);
                        system("cls");

                        cout << "==================== ATM GATO ====================" << endl;
                        cout << endl;
                        cout << "             TRANSAKSI TELAH SELESAI" << endl;
                        cout << endl;
                        cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                        cout << endl;
                        cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                        cout << endl;
                        cout << "==================================================" << endl;
                        cout << endl;
                        return 0;
                    }
                case 2:
                    int pil6212;
                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "                   HARAP TUNGGU" << endl;
                    cout << endl;
                    cout << "          INFORMASI SALDO SEDANG DIPROSES" << endl;
                    cout << endl;
                    cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                    cout << endl;
                    cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                    cout << endl;
                    cout << "==================================================" << endl;
                    Sleep(5000);
                    system("cls");

                    cout << "==================== ATM GATO ====================" << endl;
                    cout << endl;
                    cout << "               SALDO REKENING ANDA" << endl;
                    cout << endl;
                    cout << "                  RP. ";
                    displayformatsaldotabungan(saldotabungan);
                    cout << endl;
                    cout << endl;
                    cout << endl;
                    cout << endl;
                    cout << "                LANJUT TRANSAKSI ?       YA --> 1." << endl;
                    cout << endl;
                    cout << "                                      TIDAK --> 2." << endl;
                    cout << endl;
                    cout << "MASUKKAN PILIHAN ANDA : ";
                    cin >> pil6212;
                    system("cls");

                    switch (pil6212)
                    {
                    case 1:
                        break;

                    case 2:
                        cout << "==================== ATM GATO ====================" << endl;
                        cout << endl;
                        cout << "                   HARAP TUNGGU" << endl;
                        cout << endl;
                        cout << "            PERMINTAAN SEDANG DIPROSES" << endl;
                        cout << endl;
                        cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                        cout << endl;
                        cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                        cout << endl;
                        cout << "==================================================" << endl;
                        Sleep(5000);
                        system("cls");

                        cout << "==================== ATM GATO ====================" << endl;
                        cout << endl;
                        cout << "             TRANSAKSI TELAH SELESAI" << endl;
                        cout << endl;
                        cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                        cout << endl;
                        cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                        cout << endl;
                        cout << "==================================================" << endl;
                        cout << endl;
                        return 0;
                    }
                }

            case 3:
                goto restartpenarikancepat;
            case 4:
                cout << "==================== ATM GATO ====================" << endl;
                cout << endl;
                cout << "                   HARAP TUNGGU" << endl;
                cout << endl;
                cout << "            PERMINTAAN SEDANG DIPROSES" << endl;
                cout << endl;
                cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                cout << endl;
                cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                cout << endl;
                cout << "==================================================" << endl;
                Sleep(5000);
                system("cls");

                cout << "==================== ATM GATO ====================" << endl;
                cout << endl;
                cout << "             TRANSAKSI TELAH SELESAI" << endl;
                cout << endl;
                cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
                cout << endl;
                cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
                cout << endl;
                cout << "==================================================" << endl;
                cout << endl;
                return 0;

            default:
                cout << "==================== ATM GATO ====================" << endl;
                cout << endl;
                cout << "               PILIHAN TIDAK VALID" << endl;
                cout << endl;
                cout << "                   HARAP TUNGGU" << endl;
                cout << endl;
                cout << "             SILAHKAN ULANGI PILIHAN" << endl;
                cout << endl;
                cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
                cout << endl;
                cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
                cout << endl;
                cout << "==================================================" << endl;
                Sleep(5000);
                system("cls");
                goto restarttransfer;
            }
        case 7:
            cout << "==================== ATM GATO ====================" << endl;
            cout << endl;
            cout << "                   HARAP TUNGGU" << endl;
            cout << endl;
            cout << "            PERMINTAAN SEDANG DIPROSES" << endl;
            cout << endl;
            cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
            cout << endl;
            cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
            cout << endl;
            cout << "==================================================" << endl;
            Sleep(5000);
            system("cls");

            cout << "==================== ATM GATO ====================" << endl;
            cout << endl;
            cout << "             TRANSAKSI TELAH SELESAI" << endl;
            cout << endl;
            cout << "            SILAHKAN AMBIL KARTU ANDA" << endl;
            cout << endl;
            cout << "       TERIMA KASIH TELAH PERCAYA PADA GATO" << endl;
            cout << endl;
            cout << "==================================================" << endl;
            cout << endl;
            return 0;

        default:
            cout << "==================== ATM GATO ====================" << endl;
            cout << endl;
            cout << "               PILIHAN TIDAK VALID" << endl;
            cout << endl;
            cout << "                   HARAP TUNGGU" << endl;
            cout << endl;
            cout << "             SILAHKAN ULANGI PILIHAN" << endl;
            cout << endl;
            cout << "- - - - - - - - - - - - - - - - - - - - - - - - -" << endl;
            cout << endl;
            cout << "          NIKMATI KEMUDAHAN BERTRANSAKSI\n\t         MELALUI ATM GATO" << endl;
            cout << endl;
            cout << "==================================================" << endl;
            Sleep(5000);
            system("cls");
            goto restartpenarikancepat;
        }
    } while (pil != 7);

    return 0;
}