//KELOMPOK 5 (Manajemen Peminjaman Buku Perpustakaan)
//ANGGOTA : 1. FAYZUL HAQ (203)
//          2. RAYA AHMAD SYARIF (191)
//          3. INDAH PUTRI HIMALAYA NAIBAHO (201)

#include <iostream>
#include <string>
#include <fstream>
#include <chrono>
#include <cstdlib>

using namespace std;
using namespace chrono;

// deklarasi untuk pemanggilan fungsi
int MainMenu();
int AdminMenu();
void PinjamBuku();
void TambahBuku();
void HapusBuku();
int LihatDataPeminjam();
int BackToAdmin();
int BackToMenu();

// /Di bawah ini merupakan data buku perpustakaan/
struct DataBuku
{
    string nama_buku;
    string genre;
    string penulis;
    string tahun_penerbitan;
    string lokasi;
};

// data peminjam buku
struct Peminjam
{
    string nama;
    string no_hp;
    string alamat;
    string buku;
    string tanggal_pinjam;
    string tanggal_pengembalian;
};

int main()
{
    // Untuk main menu
    MainMenu();
}

// untuk kembali ke menu utama
int BackToMenu()
{
    cout << "Tekan 'Enter' untuk kembali ke Menu Sebelumnya...";
    cin.get();
    system("cls"); // clear menu sebelumnya
    MainMenu();
}

int BackToAdmin()
{
    cout << "Tekan 'Enter' untuk kembali ke Menu sebelumnya...";
    cin.get();
    system("cls"); // clear menu sebelumnya
    AdminMenu();
}

void exitProgram() {
    cout << "Program berakhir." << std::endl;

    // Mengakhiri program dengan nilai keluaran 0 (sukses)
    exit(0);
}

void PinjamBuku()
{
    fstream file;

    file.open("data_peminjam.dat", ios::app);
    string line;

    if (file.is_open())
    {
        Peminjam peminjam;

        cout << "Masukkan nama: " << endl;
        cin.ignore();
        getline(cin, peminjam.nama);

        cout << "Masukkan nomor hp: " << endl;
        cin >> peminjam.no_hp;
        cin.ignore();

        cout << "Masukkan alamat: " << endl;

        getline(cin, peminjam.alamat);

        cout << "Masukkan judul buku: " << endl;

        getline(cin, peminjam.buku);

        // Mendapatkan waktu saat ini
        auto now = system_clock::to_time_t(system_clock::now());

        // Format tanggal (DD/MM/YYYY)
        char formatted_date[11];
        strftime(formatted_date, sizeof(formatted_date), "%d/%m/%Y", localtime(&now));
        peminjam.tanggal_pinjam = formatted_date;

        auto returnDate = system_clock::to_time_t(system_clock::from_time_t(now) + hours(7 * 24));
        strftime(formatted_date, sizeof(formatted_date), "%d/%m/%Y", localtime(&returnDate));
        peminjam.tanggal_pengembalian = formatted_date;

        file << "Nama: " << peminjam.nama << endl;
        file << "No.Hp: " << peminjam.no_hp << endl;
        file << "Alamat: " << peminjam.alamat << endl;
        file << "Judul buku: " << peminjam.buku << endl;
        file << "Tanggal peminjaman: " << peminjam.tanggal_pinjam << endl;
        file << "tanggal pengembalian :" << peminjam.tanggal_pengembalian << endl;
        file << " " << endl;
        cout << "Data anda sudah tercatat!" << endl;
        cout << "" << endl;
        cout << "peminjaman buku ini berdurasi 7 hari" << endl;
        cout << "kembalikan buku ini pada tanggal :" << '"' << peminjam.tanggal_pengembalian << '"' << endl;
        cout << "" << endl;

        file.close();
    }
    else
    {
        cout << "Tidak dapat dibuka" << endl;
    }
}

int DaftarBuku()
{
    ifstream file("data_buku.dat");
    string line;

    if (file.is_open())
    {
        cout << "DAFTAR BUKU :" << endl << endl;
        while (getline(file, line))
        {
            cout << line << endl;
        }
        file.close();
    }
    else
    {
        cout << "Tidak dapat dibuka" << endl;
    }
}

int MainMenu()
{ // pusat dari program
    int opsi;
    do
    {
        cout << "        ==== SELAMAT DATANG ====" << endl;
        cout << " ==== Perpustakaan UNESA Ketintang ====" << endl;
        cout << "                        " << endl;
        cout << "Pilih menu dibawah ini dengan menekan angka: " << endl;
        cout << "            1. Pinjam buku                 " << endl;
        cout << "            2. Daftar buku                 " << endl;
        cout << "            3. Admin Mode                  " << endl;
        cout << "            4. keluar program              " << endl;
        cout << "   " << endl;
        cout << "=============================================  " << endl;
        cout << "Masukan pilihan anda : ";
        cin >> opsi;
        system("cls"); // clear menu dari layar
        switch (opsi)
        {
        case 1:
            /* algortima pinjam buku*/
            PinjamBuku();
            BackToMenu();
            break;
        case 2:
            /* algoritma daftar buku*/
            DaftarBuku();
            cin.ignore();
            BackToMenu();
            break;
        case 3:
            AdminMenu();
            break;
        case 4:
            exitProgram();
            break;
        default:
            cout << "        Tolong pilih opsi 1-3... " << endl;
            cout << "                   | | " << endl;
            cout << "                  _| |_" << endl;
            cout << "                  \\   /" << endl;
            cout << "                   \\ / " << endl;
            cout << "                    v  " << endl;
            cout << " " << endl;
            
            MainMenu();
            break;
        }
    } while (opsi != 5);
    // loop dijalankan apabila user menginput di luar pilihan
}

int AdminMenu()
{
    // Untuk Admin Mode
    int pin_admin;
    int opsi_adminmode;
    cout << "===== ADMIN MODE =====" << endl;
    cout << "Mohon input passcode: " << endl;
    cin >> pin_admin;
    system("cls"); // clear pin
    if (pin_admin == 1234)
    {
        cout << "==== ADMIN MODE ====" << endl;
        cout << "1. Tambah buku" << endl;
        cout << "2. Lihat data peminjam" << endl;
        cout << "3. Hapus buku" << endl;
        cout << "4. Kembali ke menu utama" << endl;
        cout << "====================" << endl;
        cout << "Masukan pilihan anda : ";
        cin >> opsi_adminmode;
        cin.ignore(); // clear input buffer
        system("cls");
        switch (opsi_adminmode)
        {
        case 1:
            TambahBuku();
            BackToAdmin();
            break;
        case 2:
            LihatDataPeminjam();
            BackToAdmin();
            break;
        case 3:
            HapusBuku();
            BackToAdmin();
            break;
        case 4:
            MainMenu();
            break;
        }
    }
    else
    { // semisal input pin salah
        cout << "PIN yang anda input salah!" << endl;
        return AdminMenu();
    }
}

// fungsi old buat nambahin buku
void TambahBuku()
{

    fstream file;
    file.open("data_buku.dat", ios::app | ios::out);

    if (file.is_open())
    {
        DataBuku buku;

        do
        {
            cout << "Masukkan judul buku: " << endl;
            getline(cin, buku.nama_buku);
            if (buku.nama_buku.empty())
            {
                cout << "Nama buku tidak boleh kosong, silahkan ulangi lagi" << endl;
            }
        } while (buku.nama_buku.empty());

        do
        {
            cout << "Masukkan tahun buku: " << endl;
            getline(cin, buku.tahun_penerbitan);
            if (buku.tahun_penerbitan.empty())
            {
                cout << "Tahun buku tidak boleh kosong, silahkan ulangi lagi" << endl;
            }
        } while (buku.tahun_penerbitan.empty());

        do
        {
            cout << "Masukkan genre buku: " << endl;
            getline(cin, buku.genre);
            if (buku.genre.empty())
            {
                cout << "Genre buku tidak boleh kosong, silahkan ulangi lagi" << endl;
            }
        } while (buku.genre.empty());

        do
        {
            cout << "Masukkan nama penulis: " << endl;
            getline(cin, buku.penulis);
            if (buku.penulis.empty())
            {
                cout << "Penulis buku tidak boleh kosong, silahkan ulangi lagi" << endl;
            }
        } while (buku.penulis.empty());

        file << "Judul buku: " << buku.nama_buku << endl;
        file << "Tahun terbit: " << buku.tahun_penerbitan << endl;
        file << "Genre: " << buku.genre << endl;
        file << "Penulis: " << buku.penulis << endl;
        file << " " << endl;

        cout << "Buku baru sudah tercatat!" << endl;

        file.close();
    }
    else
    {
        cout << "Tidak dapat membuka file" << endl;
    }

    // rekursif untuk mengulang tambah buku
    char lanjut;
    cout << "Tambah buku lagi? (y/n)" << endl;
    cin >> lanjut;
    cin.ignore(); // fix bug judul kosong
    if (lanjut == 'y' || lanjut == 'Y')
    {
        system("cls");
        return TambahBuku();
    }
    else
    {
        system("cls");
        AdminMenu(); // kembali ke menu admin
    }
}

void HapusBuku()
{
    string judulBuku;
    cout << "Masukkan judul buku yang ingin dihapus: ";
    getline(cin, judulBuku);

    ifstream inputFile("data_buku.dat");
    ofstream tempFile("temp.dat");

    string line;
    bool bukuDitemukan = false;

    while (getline(inputFile, line))
    {
        // Mencari baris yang berisi judul buku yang akan dihapus
        if (line.find("Judul buku: " + judulBuku) != string::npos)
        {
            bukuDitemukan = true;

            // Menghapus informasi buku (judul, tahun, genre, penulis)
            for (int i = 0; i < 4; ++i)
            {
                getline(inputFile, line); // Mengabaikan baris informasi buku
            }

            continue; // Melanjutkan ke buku berikutnya setelah menghapus informasi
        }

        tempFile << line << endl;
    }

    inputFile.close();
    tempFile.close();

    remove("data_buku.dat");
    rename("temp.dat", "data_buku.dat");

    if (bukuDitemukan)
    {
        cout << "Buku dengan judul '" << judulBuku << "' telah dihapus." << endl;
    }
    else
    {
        cout << "Buku dengan judul '" << judulBuku << "' tidak ditemukan." << endl;
    }
}


int LihatDataPeminjam()
{
    ifstream file("data_peminjam.dat");
    string line;

    if (file.is_open())
    {
        while (getline(file, line))
        {
            cout << line << endl;
        }
        file.close();
    }
    else
    {
        cout << "Tidak dapat dibuka" << endl;
    }
}
