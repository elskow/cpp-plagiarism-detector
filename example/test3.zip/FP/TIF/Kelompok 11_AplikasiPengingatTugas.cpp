#include <iostream>
#include <string>
using namespace std;

// Struct untuk menyimpan informasi tugas
struct Tugas {
    string nama;
    string deskripsi;
    bool selesai;
};

// Fungsi untuk menampilkan informasi tugas
void tampilkanInfoTugas(Tugas tugas) {
    cout << "Nama Tugas: " << tugas.nama << endl;
    cout << "Deskripsi: " << tugas.deskripsi << endl;
    cout << "Status: " << (tugas.selesai ? "Selesai" : "Belum Selesai") << endl;
}

int main() {
    // Operator input dan output
    cout << "Selamat datang di Aplikasi Manajemen Tugas" << endl;

    const int MAX_TUGAS = 10;
    Tugas daftarTugas[MAX_TUGAS];
    int jumlahTugas = 0;

    // Menu utama
    int pilihan;
    do {
        cout << "\nMenu:\n";
        cout << "1. Tambah Tugas\n";
        cout << "2. Tampilkan Semua Tugas\n";
        cout << "3. Tandai Tugas Selesai\n";
        cout << "0. Keluar\n";
        cout << "Pilihan Anda: ";
        cin >> pilihan;

        switch (pilihan) {
            case 1:
                // Tambah Tugas
                if (jumlahTugas < MAX_TUGAS) {
                    cout << "Masukkan nama tugas: ";
                    cin.ignore();  // Membersihkan buffer
                    getline(cin, daftarTugas[jumlahTugas].nama);

                    cout << "Masukkan deskripsi tugas: ";
                    getline(cin, daftarTugas[jumlahTugas].deskripsi);

                    daftarTugas[jumlahTugas].selesai = false;

                    ++jumlahTugas;
                } else {
                    cout << "Maaf, sudah mencapai batas maksimum tugas." << endl;
                }
                break;

            case 2:
                // Tampilkan Semua Tugas
                if (jumlahTugas > 0) {
                    cout << "\nDaftar Tugas:\n";
                    for (int i = 0; i < jumlahTugas; ++i) {
                        cout << "\nTugas ke-" << i + 1 << ":\n";
                        tampilkanInfoTugas(daftarTugas[i]);
                    }
                } else {
                    cout << "Belum ada tugas." << endl;
                }
                break;

            case 3:
                // Tandai Tugas Selesai
                int nomorTugas;
                cout << "Masukkan nomor tugas yang selesai: ";
                cin >> nomorTugas;

                if (nomorTugas > 0 && nomorTugas <= jumlahTugas) {
                    daftarTugas[nomorTugas - 1].selesai = true;
                    cout << "Tugas '" << daftarTugas[nomorTugas - 1].nama << "' telah ditandai selesai." << endl;
                } else {
                    cout << "Nomor tugas tidak valid." << endl;
                }
                break;

            case 0:
                // Keluar
                cout << "Terima kasih! Sampai jumpa." << endl;
                break;

            default:
                cout << "Pilihan tidak valid. Silakan coba lagi." << endl;
                break;
        }

    } while (pilihan != 0);

    return 0;
}

