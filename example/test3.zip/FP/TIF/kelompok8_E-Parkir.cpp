#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <iomanip>

using namespace std;

// Struct untuk data sepeda
struct Sepeda
{
    string tipe;
    string merk;
};

// tarifParkir divariabelkan
int tarifParkir = 0;

// fungsi untuk tiket
int generateKodeKarcis()
{
    srand(time(0));
    return rand() % 10000 + 1000;
}

// fungsi untuk tipe motor
int hitungTarifParkir(const string &tipeSepeda)
{
    if (tipeSepeda == "Matic")
    {
        return 2000;
    }
    else if (tipeSepeda == "Kopling")
    {
        return 3000;
    }
    else if (tipeSepeda == "Manual")
    {
        return 2000;
    }
    else
    {
        return 0;
    }
}

// mengecek tiket
bool cekKodeKarcis(const string &namaFile, int kodeKarcis)
{
    ifstream file(namaFile);
    string line;
    while (getline(file, line))
    {
        size_t found = line.find("Kode Karcis: " + to_string(kodeKarcis));
        if (found != string::npos)
        {
            file.close();
            return true;
        }
    }
    file.close();
    return false;
}

// mengecek fungsi sudah masuk array apabelum
bool cekMerkSepeda(const string &merk, const string *arrayMerk, int panjangArray)
{
    for (int i = 0; i < panjangArray; ++i)
    {
        if (merk == arrayMerk[i])
        {
            return true;
        }
    }
    return false;
}

// menyimpan data pengendara
void simpanDataPengendara(const string &namaFile, const string &data)
{
    ofstream file(namaFile, ios::app);
    if (file.is_open())
    {
        file << data << endl;
        file.close();
    }
    else
    {
        cout << "Failed to open the file for data storage." << endl;
    }
}

// mengambil data pengendara dari file base
string ambilDataPengendara(const string &namaFile, int kodeKarcis)
{
    ifstream file(namaFile);
    string line;
    while (getline(file, line))
    {
        size_t found = line.find("Kode Karcis: " + to_string(kodeKarcis));
        if (found != string::npos)
        {
            file.close();
            return line;
        }
    }
    file.close();
    return "";
}

// informasi pengendara
void tampilkanInformasiPengendara(const string &dataPengendara)
{
    size_t posTipe = dataPengendara.find("Tipe Sepeda: ");
    size_t posMerk = dataPengendara.find(", Merk: ");
    size_t posTarif = dataPengendara.find(", Tarif Parkir: Rp. ");
    size_t posKode = dataPengendara.find(", Kode Karcis: ");

    if (posTipe != string::npos && posMerk != string::npos && posTarif != string::npos && posKode != string::npos)
    {
        cout << "\nInformasi Lengkap:" << endl;
        cout << "Tipe Sepeda  : " << dataPengendara.substr(posTipe + 13, posMerk - posTipe - 13) << endl;
        cout << "Merk Sepeda  : " << dataPengendara.substr(posMerk + 8, posTarif - posMerk - 8) << endl;
        cout << "Tarif Parkir : Rp." << tarifParkir << endl;
        cout << "Kode Karcis  : " << dataPengendara.substr(posKode + 15) << endl;
    }
    else
    {
        cout << "Gagal memformat informasi pengendara." << endl;
    }
}

int main()
{
    int pilihanAwal;
    int kodeKarcis;
    Sepeda sepeda;
    system("cls");
    cout << "=================================\n";
    cout << "SELAMAT DATANG DI E-PARKIR SEPEDA" << endl;
    cout << "=================================";

    do
    {
        cout << "\nPilihan: \n1. Masuk Parkiran\n2. Keluar Parkiran\n0. Keluar Program\nPilih: ";
        cin >> pilihanAwal;

        if (pilihanAwal == 1)
        {
            system("cls");
            //  masuk parkiran

            string Matic[] = {
                "Beat",
                "Scoopy",
                "Vario",
                "NMAX",
                "PCX",
                "Aerox",
                "ADV",
                "Mio"
            };
            string Kopling[] = {
                "CBR",
                "Gl Max",
                "V-IXION",
                "Megapro",
                "Ninja",
                "CRF",
                "KLX",
                "RX King"
            };
            string Manual[] = {
                "Astrea",
                "Jupiter",
                "Supra-X",
                "Shogun",
                "Revo",
                "Smash",
                "Vega",
                "Kharisma"
            };
            string *pointerMerk;

            // tipe sepeda dari pengendara
            string tipeSepeda;
            cout << "\nPilih tipe sepeda:\n- Matic \n- Kopling \n- Manual\n";
            cout << "Pilih: ";
            cin >> tipeSepeda;

            //  array merk sepeda berdasarkan tipe
            system("cls");
            if (tipeSepeda == "Matic")
            {
                cout << "1. Beat\n2. Scoopy\n3. Vario\n4. NMAX \n5. PCX\n6. Aerox\n7. ADV\n8. Mio";
                pointerMerk = Matic;
            }
            else if (tipeSepeda == "Kopling")
            {
                cout << "1. CBR\n2. Gl Max\n3. V-IXION\n4. Megapro\n5. Ninja\n6. CRF\n7. KLX\n8. RX-King";
                pointerMerk = Kopling;
            }
            else if (tipeSepeda == "Manual")
            {
                cout << "1. Astrea\n2. Jupiter\n3. Supra X\n4. Shogun \n5. Revo\n6. Smash\n7. Vega\n8. Kharisma";
                pointerMerk = Manual;
            }
            else
            {
                cout << "Tipe sepeda tidak valid." << endl;
                continue; // kembali ke awal loop
            }

            // merk sepeda dari pengendara
            string merkSepeda;
            bool merkValid = false;

            do
            {
                cout << "\nPilih merk sepeda atau masukkan secara manual (ketik 'manual'): ";
                cin >> merkSepeda;
                system("cls");

                if (merkSepeda == "manual")
                {
                    cout << "Masukkan Merk Sepeda: ";
                    cin >> merkSepeda;

                    // Check if the entered manual brand is valid
                    if (cekMerkSepeda(merkSepeda, pointerMerk, sizeof(Manual) / sizeof(Manual[0])) || tipeSepeda == "Manual")
                    {
                        merkValid = true;
                    }
                    else
                    {
                        cout << "Merk tidak valid, silahkan pilih merk yang sesuai atau masukkan secara manual." << endl;
                        continue;
                    }
                }
                else if (cekMerkSepeda(merkSepeda, pointerMerk, sizeof(Manual) / sizeof(Manual[0])) || tipeSepeda == "Manual")
                {
                    merkValid = true;
                }
                else
                {
                    cout << "Merk tidak valid, silahkan pilih merk yang sesuai atau masukkan secara manual." << endl;
                    continue;
                }

            } while (!merkValid);

            // simpan data sepeda ke dalam struct
            sepeda.tipe = tipeSepeda;
            sepeda.merk = merkSepeda;

            // hitung tarif parkir
            tarifParkir = hitungTarifParkir(tipeSepeda);

            // kode karcis secara acak
            kodeKarcis = generateKodeKarcis();

            // informasi sepeda dan karcis
            cout << "================================================";
            cout << "\n         Informasi Sepeda dan Karcis:" << endl;
            cout << "================================================" << endl;
            cout << "Tipe Sepeda  : " << sepeda.tipe << endl;
            cout << "Merk Sepeda  : " << sepeda.merk << endl;
            cout << "Tarif Parkir : Rp. " << tarifParkir << endl;
            cout << "Kode Karcis  : " << kodeKarcis << endl;
            cout << "================================================" <<;

            // Proceed to generate the ticket only if the brand is valid
            if (merkValid)
            {
                // simpan data pengendara ke dalam file
                string dataPengendara = "Tipe Sepeda: " + sepeda.tipe + ", Merk: " + sepeda.merk +
                                        ", Tarif Parkir: Rp. " + to_string(tarifParkir) +
                                        ", Kode Karcis: " + to_string(kodeKarcis);
                simpanDataPengendara("data_pengendara.txt", dataPengendara);
                cout << "Data pengendara berhasil disimpan." << endl;
            }
            else
            {
                cout << "Data pengendara tidak valid. Pembuatan karcis dibatalkan." << endl;
            }
        }
        else if (pilihanAwal == 2)
        {
            // keluar parkiran
            // kode karcis dan uang
            int inputKodeKarcis;
            double uang;
            system("cls");
            cout << "Masukkan Kode Karcis: ";
            cin >> inputKodeKarcis;

            // cek tiket
            if (cekKodeKarcis("data_pengendara.txt", inputKodeKarcis))
            {
                cout << "Kode Karcis valid. Lanjut ke Opsi Pembayaran." << endl;

                string dataPengendara = ambilDataPengendara("data_pengendara.txt", inputKodeKarcis);

                if (!dataPengendara.empty())
                {

                    size_t posTarif = dataPengendara.find(", Tarif Parkir: Rp. ");
                    if (posTarif != string::npos)
                    {
                        tarifParkir = stoi(dataPengendara.substr(posTarif + 20)); // Convert the substring to int
                    }

                    tampilkanInformasiPengendara(dataPengendara);

                    // jumlah uang
                    cout << "Masukkan jumlah uang: ";
                    cin >> uang;

                    // cek uang
                    if (uang == tarifParkir)
                    {
                        cout << "Uang Anda Pas. Terima kasih:)" << endl;
                    }
                    else if (uang > tarifParkir)
                    {
                        int kembalian = uang - tarifParkir;
                        cout << "Uang Anda Lebih. Kembalian: Rp. " << kembalian << ". Terima kasih:)" << endl;
                    }
                    else
                    {
                        int kurang = tarifParkir - uang;
                        cout << "Uang Anda Kurang Rp." << kurang << " Tidak bisa keluar dari parkiran. Silakan menuju ATM terdekat." << endl;
                    }
                }
                else
                {
                    cout << "Gagal mendapatkan informasi pengendara dari file." << endl;
                }
            }
            else
            {
                cout << "Kode Karcis tidak valid. Proses keluar parkiran gagal, Silahkan cek kembali Kode Karcis anda." << endl;
            }
        }
        else if (pilihanAwal != 0)
        {
            cout << "Pilihan tidak valid." << endl;
        }
    } while (pilihanAwal != 0);

    return 0;
}
