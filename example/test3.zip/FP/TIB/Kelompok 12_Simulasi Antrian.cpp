#include <iostream>
#include <queue>

int main() {
    std::queue<int> antrian;

    // Menambahkan elemen ke antrian
    antrian.push(5);
    antrian.push(10);
    antrian.push(15);
    antrian.push(20);

    std::cout << "Jumlah antrian saat ini: " << antrian.size() << std::endl;

    // Mengakses elemen pertama di antrian
    std::cout << "Elemen pertama: " << antrian.front() << std::endl;

    // Menghapus elemen pertama dari antrian
    antrian.pop();
    std::cout << "Setelah menghapus, jumlah antrian: " << antrian.size() << std::endl;
    
    return 0;
}