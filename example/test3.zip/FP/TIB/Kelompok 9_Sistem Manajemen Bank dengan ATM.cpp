#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>

using namespace std;

/*  Sistem Manajemen Bank dengan ATM menggunakan C++
    Anggota kelompok 9 TI'B 2023:
    23051204048 Abdul Rohman Maulidhi
    23051204053 Ahmad Fahmi Fawwaz
    23051204058 Hikmah Aprilia
*/

struct BankAccount {
    int account_number;
    string name;
    char gender;
    string NIK;
    string address;
    string born;
    long balance;
    int pin;
};

void menubank(){
        cout << "==========================================" << endl;
        cout << "|               MENU BANK:               |" << endl;
        cout << "|           Pilihan Pengguna :           |" << endl;
        cout << "------------------------------------------" << endl;
        cout << "|1. Informasi Bank                       |" << endl;
        cout << "|2. Pengguna Baru                        |" << endl;
        cout << "|3. Transaksi Pengguna (Login)           |" << endl;
        cout << "|4. Keluar                               |" << endl;
        cout << "==========================================" << endl;
}

void InfoBank() {

    cout << "=============================================================" << endl;
    cout << "|                                                           |" << endl;
    cout << "|                   INFORMASI BANK UNESA                    |" << endl;
    cout << "|                                                           |" << endl;
    cout << "=============================================================" << endl;
    cout << "| Selamat datang di Bank UNESA!                             |" << endl;
    cout << "|                                                           |" << endl;
    cout << "| Kami adalah bank yang berkomitmen memberikan layanan      |" << endl;
    cout << "| terbaik kepada nasabah.                                   |" << endl;
    cout << "|                                                           |" << endl;
    cout << "| Sebagai bagian dari Universitas Negeri Surabaya,          |" << endl;
    cout << "| kami berfokus pada pelayanan dan produk keuangan inovatif.|" << endl;
    cout << "|                                                           |" << endl;
    cout << "| Kami menawarkan berbagai layanan, mulai dari              |" << endl;
    cout << "| akun tabungan, deposito, hingga transfer.                 |" << endl;
    cout << "|                                                           |" << endl;
    cout << "| Kami juga bermitra dengan berbagai institusi untuk        |" << endl;
    cout << "| institusi untuk memberikan layanan yang lebih baik        |" << endl;
    cout << "| dan lebih luas.                                           |" << endl;
    cout << "|                                                           |" << endl;
    cout << "| Terima kasih telah memilih Bank UNESA sebagai mitra       |" << endl;
    cout << "| keuangan Anda.                                            |" << endl;
    cout << "=============================================================" << endl;
}

void PetunjukRegistrasi() {
    
    cout << "==========================================" << endl;
    cout << "|           PETUNJUK REGISTRASI          |" << endl;
    cout << "==========================================" << endl;
    cout << "|1. Setiap nasabah harus memiliki satu   |" << endl;
    cout << "|   akun dengan nomor akun unik          |" << endl;
    cout << "|   dengan format 111xxxxxxxx.           |" << endl;
    cout << "|2. Saldo awal minimum untuk membuka     |" << endl;
    cout << "|   akun adalah Rp.50000                 |" << endl;
    cout << "|3. Terdapat data tidak boleh mengandung |" << endl;
    cout << "|   spasi( ), gunakan underscore(_)      |" << endl;
    cout << "|   sebagai alternatif.                  |" << endl;
    cout << "|4. Pastikan untuk memberikan informasi  |" << endl;
    cout << "|   pribadi yang benar dan akurat.       |" << endl;
    cout << "|5. Kami tidak menanggung kerugian       |" << endl;
    cout << "|   akibat informasi yang tidak benar.   |" << endl;
    cout << "|6. Hubungi layanan pelanggan kami       |" << endl;
    cout << "|   untuk bantuan lebih lanjut.          |" << endl;
    cout << "|   email: bankunesa@unesa.ac.id         |" << endl;
    cout << "|   telepon: 031 111xxxxx                |" << endl;
    cout << "==========================================" << endl;
}

void AkunBaru() {
    BankAccount account;
    cout << "----------------------------------------------------" << endl;
    cout << "|       Masukkan nama lengkap (sesuai KTP)         |" << endl;
    cout << "----------------------------------------------------" << endl;
    cout << "Nama lengkap anda (Tidak boleh mengandung spasi, gunakan underscore(_) sebagai spasi): ";
    cin.ignore();
    getline(cin, account.name);
    cout << "------------------------------------------" << endl;
    cout << "|        Jenis kelamin (L/P)             |" << endl;
    cout << "------------------------------------------" << endl;
    cout << "Jenis kelamin anda (L/P): ";
    cin >> account.gender;
    cout << "-------------------------------------------------------" << endl;
    cout << "|     Masukkan NIK (16 digit sesuai KTP/KK)           |" << endl;
    cout << "-------------------------------------------------------" << endl;\
    cout << "NIK anda: ";
    cin.ignore();
    getline(cin, account.NIK);
    cout << "------------------------------------------" << endl;
    cout << "|    Masukkan alamat (sesuai KTP)        |" << endl;
    cout << "------------------------------------------" << endl;
    cout << "Alamat anda (Tidak boleh mengandung spasi, gunakan underscore(_) sebagai spasi): ";
    cin.ignore();
    getline(cin, account.address);
    cout << "--------------------------------------------------" << endl;
    cout << "|     Tanggal lahir (format: dd/mm/yyyy)         |" << endl;
    cout << "--------------------------------------------------" << endl;
    cout << "Tanggal lahir anda: ";
    cin.ignore();
    getline(cin, account.born);
    cout << "--------------------------------------------------------------" << endl;
    cout << "|     Saldo awal untuk membuka rekening (minimal Rp.50000)    |" << endl;
    cout << "--------------------------------------------------------------" << endl;
    cout << "Rp.";
    cin >> account.balance;

            if (account.balance >= 50000){
                cout << "--------------------------------------------------------------------" << endl;
                cout << "|     Buat Nomor akun anda (10 digit dengan kode bank 111xxxxxxx)  |" << endl;
                cout << "|            x adalah angka random yang diisi pengguna             |" << endl;
                cout << "--------------------------------------------------------------------" << endl;
                int account_number_s;
                cout << "Nomor akun anda (format: 111xxxxxxx): ";
                cin >> account_number_s;
                cout << endl;

                    //menghitung jumlah karakter dalam int
                    int f = 0;
                    while (account_number_s > 0){
                    account_number_s /= 10;
                    f++;}

            if (f = 10)
                {
                cout << endl;
                cout << "Konfirmasi nomor akun anda kembali: ";
                cin >> account.account_number;
                cout << "--------------------------------------------------------------------" << endl;
                cout << "|                     HARAP DIINGAT DENGAN BAIK!                   |"<< endl;
                cout << "--------------------------------------------------------------------" << endl;
                cout << "|     Buat PIN anda (PIN harus berupa angka sebanyak 6 digit)      |" << endl;
                cout << "--------------------------------------------------------------------" << endl;
                int pin_s;
                cout << "PIN anda: ";
                cin >> pin_s;
                cout << endl;
                
                    //menghitung jumlah karakter dalam int
                    int j = 0;
                    while (pin_s > 0){
                    pin_s /= 10;
                    j++;}

            if (j = 6){
                    cout << "Konfirmasi pin anda kembali: ";
                    cin >> account.pin;
                    cout << endl;
                    cout << "------------------------------------------" << endl;
                    cout << "|       HARAP DIINGAT DENGAN BAIK!       |" << endl;
                    cout << "------------------------------------------" << endl;
                    cout << "|     NO AKUN ANDA: " << account.account_number << "|" << endl;
                    cout << "------------------------------------------" << endl;
                    cout << "------------------------------------------" << endl;
                    cout << "|     PIN ANDA: " << account.pin << "|" << endl;
                    cout << "------------------------------------------" << endl;
                
    

    ofstream file("file.txt", ios::app);
    file << account.account_number << " " << account.name << " " << account.gender << " "
         << account.NIK << " " << account.address << " " << account.born << " " << account.balance << " " << account.pin << endl;
    file.close();

    cout << "------------------------------------------" << endl;
    cout << "|         Akun anda berhasil Dibuat      |" << endl;
    cout << "------------------------------------------" << endl;
    cout << "Anda dapat mengecek data akun dan mengubah data akun pada menu 'Transaksi Pengguna' " << endl;
    system("pause");

        }else{
            cout << "Mohon maaf PIN anda harus 6 digit" << endl;
            cout << "Pembuatan akun dibatalkan" << endl;
            system("pause");
        }
            }else{
                cout << "Mohon Maaf nomer akun anda harus 10 digit dan sesuai format" << endl;
                cout << "Pembuatan akun dibatalkan" << endl;
                system("pause");
            }

                }else{
                    cout << "Mohon Maaf saldo anda tidak Mencukupi" << endl;
                    cout << "Pembuatan akun dibatalkan" << endl;
                    system("pause");
                }
}

//verifikasi pin
bool verifyPIN(int entered_pin, int expected_pin) {
    return entered_pin == expected_pin;  
}

bool Login(BankAccount& account) {
    int entered_account_number, entered_pin;

    cout << "------------------------------------------" << endl;
    cout << "|   Masukkan nomor akun (10 digit)       |" << endl;
    cout << "------------------------------------------" << endl;
    cout << " Nomor akun anda: ";
    cin >> entered_account_number;
    cout << "------------------------------------------" << endl;
    cout << "|           Masukkan PIN anda            |" << endl;
    cout << "------------------------------------------" << endl;
    cout << " PIN anda: ";
    cin >> entered_pin;

    ifstream file("file.txt");
    while (file >> account.account_number >> account.name >> account.gender >> 
    account.NIK >> account.address >> account.born >> account.balance >> account.pin) {
        if (account.account_number == entered_account_number && verifyPIN(entered_pin, account.pin)) {
            file.close();
            return true;
            system("pause");
        }
    }
    file.close();
    cout << "--------------------------------------------------------------------" << endl;
    cout << "|                           Login gagal.                           |" << endl;
    cout << "--------------------------------------------------------------------" << endl;

    cout << "--------------------------------------------------------------------" << endl;
    cout << "|                    Nomor akun atau PIN salah                     |" << endl;
    cout << "--------------------------------------------------------------------" << endl;
    system("pause");
    return false;
}

void SubmenuTransaksi() {
    cout << "============================================" << endl;
    cout << "|          SUB MENU TRANSAKSI              |" << endl;
    cout << "--------------------------------------------" << endl;

        string menu[] = {
        "Deposit",
        "Penarikan",
        "Transfer",
        "Hapus akun",
        "Cek saldo dan data akun",
        "Perubahan data",
        "Keluar"
    };

    // Menampilkan menu menggunakan for loop
    cout << "|Pilihan pengguna:                         |" << endl;
    for (int i = 0; i < sizeof(menu) / sizeof(menu[0]); ++i) {
        cout << "|" << i + 1 << ". " << menu[i];
        // Menambahkan spasi agar format tetap rapi
        for (int j = 0; j < 38 - menu[i].length(); ++j) {
            cout << " ";
        }
        cout << "|" << endl;
    }
    cout << "==========================================" << endl;
}

void Setoran(BankAccount& account) {
    float amount;
    cout << "--------------------------------------------------------------" << endl;
    cout << "|         Masukkan jumlah tunai yang akan anda setor         |" << endl;
    cout << "--------------------------------------------------------------" << endl;
    cout << "Rp.";
    cin >> amount;

    account.balance += amount;

    ifstream file("file.txt");
    ofstream temp("temp.txt");

    BankAccount current_account;
    while (file >> current_account.account_number >> current_account.name >> current_account.gender >>
           current_account.NIK >> current_account.address >> current_account.born >> current_account.balance >> current_account.pin) {
        if (current_account.account_number == account.account_number) {
            current_account.balance = account.balance;
        }
        temp << current_account.account_number << " " << current_account.name << " " << current_account.gender << " "
             << current_account.NIK << " " << current_account.address << " " << current_account.born << " " << current_account.balance << " " << current_account.pin << endl;
    }

    file.close();
    temp.close();

    remove("file.txt");
    rename("temp.txt", "file.txt");

    cout << "--------------------------------------------------------------" << endl;
    cout << "|                      Setoran Berhasil                      |" << endl;
    cout << "--------------------------------------------------------------" << endl;
    cout << "--------------------------------------------------------------" << endl;
    cout << "|     Sisa saldo anda Rp." << account.balance <<"  |" << endl;
    cout << "--------------------------------------------------------------" << endl;
}

void Penarikan(BankAccount& account) {
    float amount;
    cout << "--------------------------------------------------------------" << endl;
    cout << "|          Masukkan jumlah tunai yang ingin ditarik          |" << endl;
    cout << "--------------------------------------------------------------" << endl;
    cout << "Rp.";
    cin >> amount;

    if (account.balance >= amount) {
        account.balance -= amount;

        ifstream file("file.txt");
        ofstream temp("temp.txt");

        BankAccount current_account;
        while (file >> current_account.account_number >> current_account.name >> current_account.gender >>
           current_account.NIK >> current_account.address >> current_account.born >> current_account.balance >> current_account.pin) {
            if (current_account.account_number == account.account_number) {
                current_account.balance = account.balance;
            }
            temp << current_account.account_number << " " << current_account.name << " " << current_account.gender << " "
             << current_account.NIK << " " << current_account.address << " " << current_account.born << " " << current_account.balance << " " << current_account.pin << endl;
        }

        file.close();
        temp.close();

        remove("file.txt");
        rename("temp.txt", "file.txt");

    cout << "--------------------------------------------------------------" << endl;
    cout << "|                     Penarikan Berhasil                     |" << endl;
    cout << "--------------------------------------------------------------" << endl;
    cout << "--------------------------------------------------------------" << endl;
    cout << "|     Sisa saldo anda Rp." << account.balance <<"  |" << endl;
    cout << "--------------------------------------------------------------" << endl;
    } else {
    cout << "--------------------------------------------------------------" << endl;
    cout << "|       Saldo tidak mencukupi untuk melakukan penarikan      |" << endl;
    cout << "--------------------------------------------------------------" << endl;
    }
}

void Transfer(BankAccount& account) {
    int to_account;
    float amount;

    cout << "--------------------------------------------------------------" << endl;
    cout << "|             Masukkan akun penerima (10 digit)              |" << endl;
    cout << "--------------------------------------------------------------" << endl;
    cin >> to_account;
    cout << "--------------------------------------------------------------" << endl;
    cout << "|          Masukkan jumlah yang akan anda transfer           |" << endl;
    cout << "--------------------------------------------------------------" << endl;
    cout << "Rp.";
    cin >> amount;

    if (account.balance >= amount) {
        account.balance -= amount;

        ifstream file("file.txt");
        ofstream temp("temp.txt");

        BankAccount current_account;
        while (file >> current_account.account_number >> current_account.name >> current_account.gender >>
           current_account.NIK >> current_account.address >> current_account.born >> current_account.balance >> current_account.pin) {
            if (current_account.account_number == account.account_number) {
                current_account.balance = account.balance;
            } else if (current_account.account_number == to_account) {
                current_account.balance += amount;
            }
            temp << current_account.account_number << " " << current_account.name << " " << current_account.gender << " "
             << current_account.NIK << " " << current_account.address << " " << current_account.born << " " << current_account.balance << " " << current_account.pin << endl;
        }

        file.close();
        temp.close();

        remove("file.txt");
        rename("temp.txt", "file.txt");

    cout << "--------------------------------------------------------------" << endl;
    cout << "|                    Transfer Berhasil                       |" << endl;
    cout << "--------------------------------------------------------------" << endl;
    cout << "--------------------------------------------------------------" << endl;
    cout << "|     Sisa saldo anda Rp." << account.balance <<"  |" << endl;
    cout << "--------------------------------------------------------------" << endl;
    } else {
    cout << "--------------------------------------------------------------" << endl;
    cout << "|     Saldo anda tidak mencukupi untuk melakukan transfer    |" << endl;
    cout << "--------------------------------------------------------------" << endl;
    }
}

void HapusAkun(BankAccount& account) {
    ifstream file("file.txt");
    ofstream temp("temp.txt");

    BankAccount current_account;
    while (file >> current_account.account_number >> current_account.name >> current_account.gender >>
           current_account.NIK >> current_account.address >> current_account.born >> current_account.balance >> current_account.pin) {
        if (current_account.account_number != account.account_number) {
            temp << current_account.account_number << " " << current_account.name << " " << current_account.gender << " "
             << current_account.NIK << " " << current_account.address << " " << current_account.born << " " << current_account.balance << " " << current_account.pin << endl;
        }
    }

    file.close();
    temp.close();

    remove("file.txt");
    rename("temp.txt", "file.txt");

    cout << "--------------------------------------------------------------" << endl;
    cout << "|                 Akun anda berhasil dihapus                 |" << endl;
    cout << "--------------------------------------------------------------" << endl;
}

void UpdateInfo(BankAccount& account) {
    int pilihan_update;

    cout << "==========================================" << endl;
    cout << "|       MENU PERUBAHAN DATA AKUN         |" << endl;
    cout << "------------------------------------------" << endl;
    cout << "|Pilihan pengguna:                       |" << endl;
    cout << "|1. Nama                                 |" << endl;
    cout << "|2. Jenis Kelamin                        |" << endl;
    cout << "|3. NIK                                  |" << endl;
    cout << "|4. Alamat                               |" << endl;
    cout << "|5. Tanggal Lahir                        |" << endl;
    cout << "|6. PIN                                  |" << endl;
    cout << "|7. Kembali ke Submenu Transaksi         |" << endl;
    cout << "==========================================" << endl;

    cout << "Pilihan pengguna: ";
    cin >> pilihan_update;

    switch (pilihan_update) {
        case 1:
            cout << "Masukkan nama baru: ";
            cin.ignore();
            getline(cin, account.name);
            break;
        case 2:
            cout << "Masukkan jenis kelamin baru (L/P): ";
            cin >> account.gender;
            break;
        case 3:
            cout << "Masukkan NIK baru (16 digit sesuai KTP/KK): ";
            cin >> account.NIK;
            break;
        case 4:
            cout << "Masukkan alamat baru: ";
            cin.ignore();
            getline(cin, account.address);
            break;
        case 5:
            cout << "Masukkan tanggal lahir baru (format: dd/mm/yyyy): ";
            cin.ignore();
            getline(cin, account.born);
            break;
        case 6:
            cout << "Masukkan PIN baru (harus berupa angka sebanyak 6 digit): ";
            cin >> account.pin;
            break;
        case 7:
            // Kembali ke submenu transaksi
            return;
        default:
            cout << "Pilihan tidak valid." << endl;
            return;
    }

    ifstream file("file.txt");
    ofstream temp("temp.txt");

    BankAccount current_account;
    while (file >> current_account.account_number >> current_account.name >> current_account.gender >>
           current_account.NIK >> current_account.address >> current_account.born >> current_account.balance >> current_account.pin) {
        if (current_account.account_number == account.account_number) {
            current_account = account;  // Update informasi akun
        }
        temp << current_account.account_number << " " << current_account.name << " " << current_account.gender << " "
             << current_account.NIK << " " << current_account.address << " " << current_account.born << " " << current_account.balance << " " << current_account.pin << endl;
    }

    file.close();
    temp.close();

    remove("file.txt");
    rename("temp.txt", "file.txt");

    cout << "------------------------------------------" << endl;
    cout << "|     Informasi akun berhasil diperbarui |" << endl;
    cout << "------------------------------------------" << endl;
}

void InfoAkun(const BankAccount& account) {
    cout << "===============================================================" << endl;
    cout << "Nomor akun: " << account.account_number << endl;
    cout << "--------------------------------------------------------------" << endl;
    cout << "Nama: " << account.name << endl;
    cout << "--------------------------------------------------------------" << endl;
    cout << "NIK: " << account.NIK  << endl;
    cout << "--------------------------------------------------------------" << endl;
    cout << "Jenis kelamin: " << account.gender << endl;
    cout << "--------------------------------------------------------------" << endl;
    cout << "Alamat: " << account.address  << endl;
    cout << "--------------------------------------------------------------" << endl;
    cout << "Tanggal lahir : " << account.born  << endl;
    cout << "--------------------------------------------------------------" << endl;
    cout << "Saldo anda Rp." <<  account.balance << endl;
    cout << "===============================================================" << endl;
}


int main() {
    int pilihan;
    BankAccount current_account;

    do {
        system("cls");
        cout << "==========================================" << endl;
        cout << "|                                        |" << endl;
        cout << "|            SELAMAT DATANG DI           |" << endl;
        cout << "|               BANK UNESA               |" << endl;
        cout << "|                                        |" << endl;
        cout << "==========================================" << endl;
        menubank();
        cout << "Pilihan pengguna: ";
        cin >> pilihan;

        switch (pilihan) {
            case 1:
                // Case 1: Informasi Bank
                InfoBank();
                system("pause");
                break;

            case 2:
                // Case 2: Pengguna Baru
                int pilihan_submenu;
                cout << "==========================================" << endl;
                cout << "|          SUB MENU REGISTRASI           |" << endl;
                cout << "------------------------------------------" << endl;
                cout << "|Pilihan pengguna:                       |" << endl;
                cout << "|1. Petunjuk Registrasi                  |" << endl;
                cout << "|2. Registrasi                           |" << endl;
                cout << "==========================================" << endl;
                cout << "Pilihan pengguna: ";
                cin >> pilihan_submenu;

                switch (pilihan_submenu) {
                    case 1:
                        // Case 2.1: Petunjuk membuat akun
                        PetunjukRegistrasi();
                        system("pause");
                        break;

                    case 2:
                        // Case 2.2: Membuat akun baru
                        cout << "Apakah Anda ingin membuat akun baru? (y/n): ";
                        char pilihan_akunbaru;
                        cin >> pilihan_akunbaru;

                        if (pilihan_akunbaru == 'y') {
                            AkunBaru();
                        } else {
                            cout << "Pembuatan akun dibatalkan." << endl;
                        }
                        break;

                    default:
                        cout << "Pilihan submenu tidak valid." << endl;
                }
                break;

            case 3:
                // Kasus 3: Transaksi Pengguna
                if (Login(current_account)) {
                    int pilihan_pengguna;
                    do {
                        system("cls");
                        SubmenuTransaksi();
                        cin >> pilihan_pengguna;

                        switch (pilihan_pengguna) {
                            case 1:
                                // Case 3.1: Deposit
                                char pilihan_deposit;
                                cout << "Apakah Anda ingin melakukan setoran? (y/n): ";
                                cin >> pilihan_deposit;

                                if ( pilihan_deposit == 'y') {
                                    Setoran(current_account);
                                    system("pause");
                                } else {
                                    cout << "Setoran dibatalkan." << endl;
                                }
                                break;

                            case 2:
                                // Case 3.2: Penarikan
                                char pilihan_penarikan;
                                cout << "Apakah Anda ingin melakukan penarikan? (y/n): ";
                                cin >> pilihan_penarikan;

                                if ( pilihan_penarikan == 'y') {
                                    Penarikan(current_account);
                                    system("pause");
                                } else {
                                    cout << "Penarikan dibatalkan." << endl;
                                }
                                break;

                            case 3:
                                // Case 3.3: Transfer
                                char pilihan_transfer;
                                cout << "Apakah Anda ingin melakukan transfer? (y/n): ";
                                cin >> pilihan_transfer;

                                if (pilihan_transfer == 'y') {
                                    Transfer(current_account);
                                    system("pause");
                                } else {
                                    cout << "Transfer dibatalkan." << endl;
                                }
                                break;

                            case 4:
                                // Case 3.4: Hapus akun
                                char pilihan_hapusakun;
                                cout << "Apakah Anda yakin ingin menghapus akun? (y/n): ";
                                cin >> pilihan_hapusakun;

                                if (pilihan_hapusakun == 'y') {
                                    HapusAkun(current_account);
                                    system("pause");
                                } else {
                                    cout << "Penghapusan akun dibatalkan." << endl;
                                }
                                break;

                            case 5:
                                // Case 3.5: cek saldo
                                InfoAkun(current_account);
                                system("pause");
                                break;

                            case 6:
                                // Case 3.6: Perubahan data pada akun
                                UpdateInfo(current_account);
                                system("pause");
                                break;

                            case 7:
                                //keluar
                                break;

                            default:
                                cout << "Pilihan submenu tidak valid." << endl;
                        }
                    } while (pilihan_pengguna != 7);
                }
                break;

            case 4:
                // Kasus 4: Keluar
                cout << "Anda telah keluar" << endl;
                break;

            default:
                cout << "Pilihan tidak valid." << endl;
        }

    } while (pilihan != 4);

    return 0;
}