#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "C:\g++\json.hpp" // Include the nlohmann/json library

using namespace std;
using json = nlohmann::json;

struct Patient {
    string nama;
    int usia;
    string kelamin;
    string gejala;
    int hariRawat;
    string ruangType;
    string dokterType;
};

vector<Patient*> patients;

void addPatient() {
    Patient* newPatient = new Patient;
    cout <<"Masukkan nama pasien      :";
    cin.ignore();
    getline(cin, newPatient -> nama);
    cout <<"Masukkan usia pasien      :";
    cin >> newPatient -> usia ;
    cout << "Masukkan jenis kelamin    :";
    cin.ignore();
    getline(cin, newPatient -> kelamin) ;
    
    cout << "Masukkan Diagnosa Pasien  :";
    getline(cin, newPatient -> gejala );

    cout << "Berapa hari dirawat       :";
    cin >> newPatient -> hariRawat;

    cout << "----------------------" << endl;
    cout << "|       Ruangan      |" << endl;
    cout << "======================" << endl;
    cout << "|1. Kamar Mawar      |" << endl;
    cout << "|2. Kamar Melati     |" << endl;
    cout << "|3. Kamar Bugenvil   |" << endl;
    cout << "|4. Kamar VIP        |" << endl;
    cout << "----------------------" << endl;
    cout << "Pilih Jenis Ruangan :";
    cin.ignore();
    getline(cin, newPatient ->ruangType);

    
    cout << "Dokter"<< endl;
    cout << "========================================" << endl;
    cout << " | 1. Dokter Spesialis Anak           |" << endl;
    cout << " | 2. Dokter Spesialis Penyakit Dalam |" << endl;
    cout << " | 3. Dokter Spesialis THT            |" << endl;
    cout << " | 4. Dokter Spesialis Bedah          |" << endl;
    cout << " | 5. Dokter Spesialis Kandungan      |" << endl;
    cout << " | 6. Dokter Spesialis Saraf          |" << endl;
    cout << " | 7. Dokter Spesialis Kulit & Kelamin|" << endl;
    cout << " | 8. Dokter Umum                     |" << endl;
    cout << "=======================================" << endl;
    cout << endl;
    cout << "-------------------------------" << endl;
    cout << "Masukkan Pilihan Anda [1 - 8]: ";
    getline(cin, newPatient ->dokterType);
    cout << "-------------------------------" << endl;
    cout << endl;

    patients.push_back(newPatient);
    cout << "-----------------------------" << endl;
    cout << "|Pasien Berhasil diTambahkan|" << endl;
    cout << "-----------------------------" << endl;
}

void displayPatients() {
    if (patients.empty()) {
        cout << "|======================|" << endl;
        cout << "|Tidak Ada Data Pasien |" << endl;
        cout << "|======================|" << endl;
        return;
    }

    int totalbiaya = 0;
    cout << "=== Daftar Pasien dan Biaya Pasien Yang Harus Dibayar ===" << endl;
    for (const auto& patient : patients) {
        int biayaruang = 250000;
        if (patient -> ruangType == "Mawar") {
            biayaruang = 500000;
        } else if( patient -> ruangType == "Melati") {
            biayaruang = 750000;
        } else if (patient -> ruangType == "Bugenvil") {
            biayaruang = 850000;
        } else if (patient -> ruangType == "VIP") {
            biayaruang = 1000000;
        }

    
        int biayadokter = 0; 
        if (patient ->dokterType == "1") {
            biayadokter = 150000;
        } else if (patient -> dokterType == "2"){
            biayadokter = 200000;
        } else if (patient -> dokterType == "3") {
            biayadokter = 100000;
        } else if (patient -> dokterType == "4") {
            biayadokter = 300000;
        } else if (patient -> dokterType == "5") {
            biayadokter = 500000;
        } else if (patient -> dokterType == "6") {
            biayadokter = 300000;
        } else if (patient -> dokterType == "7") {
            biayadokter = 250000;
        } else if (patient -> dokterType == "8") {
            biayadokter = 270000;
        }

        int totalbiayapasien = (biayaruang * patient->hariRawat) + biayadokter;
        totalbiaya += totalbiayapasien;

        cout << "---------------------------------------" << endl;
        cout << "Nama: " << patient->nama << endl;
        cout << "Usia: " << patient->usia << endl;
        cout << "Jenis Kelamin: " << patient->kelamin << endl;
        cout << "Diagnosa: " << patient->gejala << endl;
        cout << "Hari Dirawat: " << patient->hariRawat << " hari" << endl;
        cout << "Jenis Ruangan: " << patient->ruangType << " (Biaya: " << biayaruang << "/hari)" << endl;
        cout << "Jenis Dokter: " << patient->dokterType << " (Biaya: " << biayadokter << ")" << endl;
        cout << "Biaya Total: " << totalbiayapasien << endl;
        cout << "---------------------------------------" << endl;
    }
    cout << "----------------------------------------------------------" << endl;
    cout << "Total Biaya Keseluruhan Semua Pasien :" << totalbiaya << endl;
    cout << "----------------------------------------------------------" << endl;
}

void removePatient() {
    if (patients.empty()) {
        cout << "|=====================================|" << endl;
        cout << "|Tidak ada data pasien untuk dihapus  |" << endl;
        cout << "|=====================================|" << endl;
        return;
    }

    int index;
    cout << "=================================================" << endl;
    cout << " Masukkan nomor pasien yang ingin dihapus (1 - " << patients.size() << "): ";
    cin >> index;
    cout << "=================================================" << endl;

    if (index >= 1 && index <= patients.size()) {
        patients.erase(patients.begin() + index - 1);
        cout << "------------------------------" << endl;
        cout << "|Data pasien berhasil dihapus|" << endl;
        cout << "------------------------------" << endl;
    } else {
        cout << "--------------------------------------------------------------" << endl;
        cout << "|Nomor pasien tidak valid. Tidak ada data pasien yang dihapus|" << endl;
        cout << "--------------------------------------------------------------" << endl;
    }
}

// Simpan data pasien ke file JSON
void savePatientsToJson() {
    json patientsJson;

    for (const auto& patient : patients) {
        json patientJson;
        patientJson["nama"] = patient->nama;
        patientJson["usia"] = patient->usia;
        patientJson["kelamin"] = patient->kelamin;
        patientJson["gejala"] = patient->gejala;
        patientJson["hariRawat"] = patient->hariRawat;
        patientJson["ruangType"] = patient->ruangType;
        patientJson["dokterType"] = patient->dokterType;

        patientsJson.push_back(patientJson);
    }

    ofstream file("patients.json");
    if (file.is_open()) {
        file << patientsJson.dump(4); // Menulis data JSON ke file
        file.close();
    } else {
        cout << "--------------------------------------" << endl;
        cout << "|Gagal membuka file untuk penyimpanan|" << endl;
        cout << "--------------------------------------" << endl;
    }
}

// Memuat data pasien dari file JSON
void loadPatientsFromJson() {
    ifstream file("patients.json");
    if (file.is_open()) {
        json patientsJson;
        file >> patientsJson;

        for (const auto& patientJson : patientsJson) {
            Patient* newPatient = new Patient;
            newPatient->nama = patientJson["nama"];
            newPatient->usia = patientJson["usia"];
            newPatient->kelamin = patientJson["kelamin"];
            newPatient->gejala = patientJson["gejala"];
            newPatient->hariRawat = patientJson["hariRawat"];
            newPatient->ruangType = patientJson["ruangType"];
            newPatient->dokterType = patientJson["dokterType"];

            patients.push_back(newPatient);
        }

        file.close();
    } else {
        cout << "Gagal membuka file untuk memuat data." << endl;
    }
}

int main() {
    loadPatientsFromJson(); // Memuat data pasien saat program dimulai

    int choice;
    do {
        cout << "|============= Manajemen Rumah Sakit ==========|" << endl;
        cout << "|1. Tambah Pasien                              |" << endl;
        cout << "|2. Lihat Data Pasien dan Biaya                |" << endl;
        cout << "|3. Hapus Data Pasien                          |" << endl;
        cout << "|4. Keluar                                     |" << endl;
        cout << "|==============================================|" << endl;
        cout << "Pilih tindakan: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "=========== Tambah Pasien ===========" << endl;
                addPatient();
                break;
            case 2:
                cout << "============== Lihat Data Pasien dan Biaya =============" << endl;
                displayPatients();
                break;
            case 3:
                cout << "========= Hapus Data Pasien =========" << endl;
                removePatient();
                break;
            case 4:
                cout << "Menyimpan data dan keluar..." << endl;
                break;
            default:
                cout << "Pilihan tidak valid." << endl;
                break;
        }

        cout << endl;
    } while (choice != 4);

    savePatientsToJson(); // Menyimpan data pasien saat program ditutup

    // Membersihkan memori yang dialokasikan untuk setiap pasien sebelum keluar
    for (const auto& patient : patients) {
        delete patient;
    }
    patients.clear();

    return 0;
}
