#include <iostream>
#include <stdlib.h>
#include <vector>
#include <set>
#include <climits>
#include <unordered_map>
#include <algorithm>

using namespace std;

class Map {
public:
    unordered_map<char, vector<pair<char, int>>> adjList;

    void Tempat(char dari, char ke, int jarak) {
        adjList[dari].push_back(make_pair(ke, jarak));
        adjList[ke].push_back(make_pair(dari, jarak));
    }

    void Djikstra(char start, char end) {
        unordered_map<char, int> Jarak;
        unordered_map<char, char> induk;
        unordered_map<char, int> totalJarak;
        set<pair<int, char>> pq;

        for (auto& puncak : adjList) {
            Jarak[puncak.first] = INT_MAX;
            induk[puncak.first] = ' ';
            totalJarak[puncak.first] = INT_MAX;
        }

        Jarak[start] = 0;
        totalJarak[start] = 0;
        pq.insert(make_pair(0, start));

        while (!pq.empty()) {
            char u = pq.begin()->second;
            pq.erase(pq.begin());

            for (auto& tetangga : adjList[u]) {
                char v = tetangga.first;
                int jarak = tetangga.second;

                if (Jarak[u] + jarak < Jarak[v]) {
                    pq.erase(make_pair(Jarak[v], v));
                    Jarak[v] = Jarak[u] + jarak;
                    induk[v] = u;
                    pq.insert(make_pair(Jarak[v], v));

                    totalJarak[v] = totalJarak[u] + jarak;
                }
            }
        }

        SortirRuteTerpendek(start, end, induk, totalJarak);
    }

    void SortirRuteTerpendek(char start, char end, unordered_map<char, char>& induk, unordered_map<char, int>& totalJarak) {
        vector<char> path;
        char current = end;

        cout << "Menampilkan rute terpendek dari " << start << " ke " << end << '\n' << "Rute \t    : ";
        while (current != ' ') {
            path.push_back(current);
            current = induk[current];
        }

        reverse(path.begin(), path.end());

        for (char puncak : path) {
            cout << puncak;
            if (puncak != end) {
                cout << " -> ";
            }
        }

        cout << "\nTotal jarak : " << totalJarak[end] << "\n";
    }
};

int main() {
    char ulangi;

    do {
        Map map;
        map.Tempat('A', 'B', 5);
        map.Tempat('A', 'C', 7);
        map.Tempat('B', 'C', 8);
        map.Tempat('B', 'D', 9);
        map.Tempat('B', 'E', 8);
        map.Tempat('C', 'E', 15);
        map.Tempat('C', 'F', 10);
        map.Tempat('D', 'E', 5);
        map.Tempat('D', 'J', 11);
        map.Tempat('E', 'G', 12);
        map.Tempat('E', 'J', 3);
        map.Tempat('F', 'G', 21);
        map.Tempat('F', 'H', 5);
        map.Tempat('G', 'H', 20);
        map.Tempat('G', 'I', 4);
        map.Tempat('H', 'I', 31);
        map.Tempat('I', 'J', 5);

        char start, end;
        cout << "Masukkan tempat asal \t: ";
        cin >> start;
        cout << "Masukkan tempat tujuan \t: ";
        cin >> end;

        map.Djikstra(start, end);

        cout << "Apakah ingin mencari rute lagi ? (Y/n) : ";
        cin >> ulangi;

        if (ulangi == 'y' || ulangi == 'Y') {
            system("cls");
        }

    } while (ulangi == 'y' || ulangi == 'Y');

    return 0;
}