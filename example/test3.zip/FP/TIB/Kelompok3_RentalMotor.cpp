#include <iostream>
#include <string>
#include <fstream>
#include <limits>
using namespace std;

struct motor {
    string nama;
    long long int nik;
    string jenis_motor;
    int lamasewa;
    int nomor;
    int menu_awal;
    string menu_lanjut;
    int indeks;
    int hargasewa;
    int ulang;
};
const int jml_motor = 27;
int hargaharian[jml_motor] = {17000, 20000, 22000, 25000, 27000, 28000, 30000, 33000,
                                  33000, 35000, 37000, 40000, 43000, 45000, 18000, 20000,
                                  20000, 30000, 35000, 35000, 20000, 23000, 25000, 35000,
                                  38000, 50000, 70000};
int hargamingguan[jml_motor] = {102000, 120000, 132000, 150000, 162000, 168000, 180000,
                                    198000, 198000, 210000, 222000, 240000, 258000, 270000,
                                    108000, 120000, 120000, 180000, 210000, 210000, 120000,
                                    138000, 150000, 210000, 228000, 300000, 420000};
string daftarmotor[jml_motor] = {"HONDA REVO X CW", "HONDA SUPRA 125 CW", "HONDA SUPRA 125 SW",
                                    "HONDA GENIO CBS Plus", "HONDA SCOOPY Sporty", "HONDA SCOOPY Fashion",
                                    "HONDA VARIO 125 CBS Plus", "HONDA VARIO 150 Sporty", "HONDA VARIO 150 Exlusive",
                                    "HONDA PCX 150 CBS", "HONDA GTR 150 Sporty", "HONDA SONIC 150 R STD",
                                    "HONDA CB 150 VERZA SW", "HONDA CB 150 STD", "SUZUKI SMASH Titan",
                                    "SUZUKI SHOGUN AXELO STD", "SUZUKI SHOGUN AXELO-FL125",
                                    "SUZUKI SATRIA F150", "SUZUKI GSX S", "SUZUKI GSX R ABS", "YAMAHA MIO M3",
                                    "YAMAHA FINO 125", "YAMAHA LEXI 125", "YAMAHA NMAX 155 C/ABS",
                                    "YAMAHA AEROX 155 C", "YAMAHA RX KING 135", "KAWASAKI ZX-25R"};
int stok_motor_awal[jml_motor] = {2, 11, 10, 4, 3, 2, 7, 4, 6, 9, 12, 13, 11, 2, 3, 5, 7, 4, 6, 9, 9, 12, 8, 10, 5, 5, 3};
int hitungharga(int harga, int lamasewa) {
    return harga * lamasewa;
}
void tampilpolawal(motor* data) {
    system("cls");
        cout << "\n============================== RENTAL RAJA MOTOR ==============================" << endl;
        cout << "\nSelamat datang kami dari crew Rental Raja Motor menyediakan sewa motor dengan sistem";
        cout << "\nharian dan mingguan dengan harga yang sangat terjangkau, sangat cocok untuk anak kos";
        cout << "\ndan bisa dipastikan sangat amanah dan bisa dipercaya. Jangan ragu jangan bimbang";
        cout << "\nkarena Rental Raja Motor adalah penyewaan terbaik di surabaya dan sekitarnya.";
        cout << "\n1. Sewa Motor";
        cout << "\n2. Stok motor";
        cout << "\n3. Mencari Data";
        cout << "\n4. Keluar";
        cout << "\nPilihan = ";
        cin >> data->menu_awal;
}
void tampil_total(int harga, int lamasewa, string jenissewa) {
    int total = hitungharga(harga, lamasewa);
    cout << "Total harga\t= " << total << endl;
}
void tampil_awal() {
    cout << "          ~ Daftar Harga Rental Motor PT.K3 GAYABEBAS 2024 ~            " << endl;
    cout << " _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ " << endl;
    cout << "|                                                                       |" << endl;
    cout << "|  Type Motor                  Harga sewa/hari     Harga sewa/minggu    |" << endl;
    cout << "|                                                                       |" << endl;
    cout << "|  HONDA REVO X CW               Rp. 17.000           Rp. 102.000       |" << endl;
    cout << "|  HONDA SUPRA 125 CW            Rp. 20.000           Rp. 120.000       |" << endl;
    cout << "|  HONDA SUPRA 125 SW            Rp. 22.000           Rp. 132.000       |" << endl;
    cout << "|  HONDA GENIO CBS Plus          Rp. 25.000           Rp. 150.000       |" << endl;
    cout << "|  HONDA SCOOPY Sporty           Rp. 27.000           Rp. 162.000       |" << endl;
    cout << "|  HONDA SCOOPY Fashion          Rp. 28.000           Rp. 168.000       |" << endl;
    cout << "|  HONDA VARIO 125 CBS Plus      Rp. 30.000           Rp. 180.000       |" << endl;
    cout << "|  HONDA VARIO 150 Sporty        Rp. 33.000           Rp. 198.000       |" << endl;
    cout << "|  HONDA VARIO 150 Exlusive      Rp. 33.000           Rp. 198.000       |" << endl;
    cout << "|  HONDA PCX 150 CBS             Rp. 35.000           Rp. 210.000       |" << endl;
    cout << "|  HONDA GTR 150 Sporty          Rp. 37.000           Rp. 222.000       |" << endl;
    cout << "|  HONDA SONIC 150 R STD         Rp. 40.000           Rp. 240.000       |" << endl;
    cout << "|  HONDA CB 150 VERZA SW         Rp. 43.000           Rp. 258.000       |" << endl;
    cout << "|  HONDA CB 150 STD              Rp. 45.000           Rp. 270.000       |" << endl;
    cout << "|  SUZUKI SMASH Titan            Rp. 18.000           Rp. 108.000       |" << endl;
    cout << "|  SUZUKI SHOGUN AXELO STD       Rp. 20.000           Rp. 120.000       |" << endl;
    cout << "|  SUZUKI SHOGUN AXELO-FL125     Rp. 20.000           Rp. 120.000       |" << endl;
    cout << "|  SUZUKI SATRIA F150            Rp. 30.000           Rp. 180.000       |" << endl;
    cout << "|  SUZUKI GSX S                  Rp. 35.000           Rp. 210.000       |" << endl;
    cout << "|  SUZUKI GSX R ABS              Rp. 35.000           Rp. 210.000       |" << endl;
    cout << "|  YAMAHA MIO M3                 Rp. 20.000           Rp. 120.000       |" << endl;
    cout << "|  YAMAHA FINO 125               Rp. 23.000           Rp. 138.000       |" << endl;
    cout << "|  YAMAHA LEXI 125               Rp. 25.000           Rp. 150.000       |" << endl;
    cout << "|  YAMAHA NMAX 155 C/ABS         Rp. 35.000           Rp. 210.000       |" << endl;
    cout << "|  YAMAHA AEROX 155 C            Rp. 38.000           Rp. 228.000       |" << endl;
    cout << "|  YAMAHA RX KING 135            Rp. 50.000           Rp. 300.000       |" << endl;
    cout << "|  KAWASAKI ZX-25R               Rp. 70.000           Rp. 420.000       |" << endl;
    cout << "|_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _|" << endl;
    cout << endl;
    cout << "Ketik (lanjut) untuk mengisi data penyewaan : ";
}
void tampilkandaftarmotor() {
    cout << "\n[Daftar Motor yang Tersedia]" << endl;
    for (int i = 0; i < jml_motor; i++) {
        cout << i + 1 << ". " << daftarmotor[i] << endl;
    }
}
void pil1(motor* data) {
    while (true) {
                system("cls");
                tampil_awal();
                cin >> data->menu_lanjut;
                if (data->menu_lanjut == "lanjut") {
                    system("cls");
                    cout << "[Silahkan mengisi data jika anda ingin menyewa motor]" << endl << endl;
                    cout << "Nama Peminjam = ";
                    cin.ignore();
                    getline(cin, data->nama);
                    cout << "\nNIK Peminjam = ";
                    while (true) {
                        while (!(cin >> data->nik) || cin.fail()) {
                            cin.clear();
                            cin.ignore(numeric_limits<streamsize>::max(), '\n');
                            cout << "Masukkan NIK yang valid: ";
                        }
                        if (to_string(data->nik).length() == 16) {
                            break;
                        } else {
                            cout << "Masukkan NIK dengan benar, Silakan coba lagi!!" << endl;
                        }
                    }
                    tampilkandaftarmotor();
                    cout << "Pilihan = ";
                    while (true) {
                        cin >> data->nomor;
                        if (data->nomor > jml_motor || data->nomor <= 0) {
                            cout << "Masukkan angka dengan benar!!" << endl;
                            cout << "Pilihan = ";
                        } else {
                            data->jenis_motor = daftarmotor[data->nomor - 1];
                            cout << "\n[Pilih Sistem Persewaan]" << endl;
                            cout << "1. Harian" << endl;
                            cout << "2. Mingguan" << endl;
                            while (true) {
                            cout << "Pilihan (1/2) = ";
                            cin >> data->lamasewa;
                            switch (data->lamasewa) {
                                case 1 :
                                    while (true) {
                                        cout << "\nBerapa hari anda ingin menyewa motor : ";
                                        cin >> data->lamasewa;
                                        if (data->lamasewa > 0) {
                                            break;
                                        }
                                        cout << "Waktu sewa harus lebih dari 0 hari. Silakan coba lagi.";
                                    }
                                    data->indeks = data->nomor - 1;
                                    if (data->indeks >= 0 && data->indeks < jml_motor) {
                                        data->hargasewa = hargaharian[data->indeks];
                                        system("cls");
                                        cout << "=============== NOTA PEMINJAMAN ===============" << endl;
                                        cout << "===============================================" << endl;
                                        cout << "Nama Peminjam\t: " << data->nama << endl;
                                        cout << "NIK Peminjam\t: " << data->nik << endl;
                                        cout << "Jenis Motor\t: " << data->jenis_motor << endl;
                                        cout << "Lama Sewa\t: " << data->lamasewa << " hari" << endl;
                                        cout << "Harga per-hari\t: Rp. " << data->hargasewa << endl;
                                        cout << "----------------------------------------------" << endl;
                                        tampil_total(data->hargasewa, data->lamasewa, "harian");
                                        cout << "===============================================" << endl;
                                        if (stok_motor_awal[data->indeks] > 0) {
                                                stok_motor_awal[data->indeks]--;
                                        cout << "Anda telah menyewa motor " << daftarmotor[data->indeks] << ". Stok berkurang 1 unit." << endl;
                                        } else {
                                        cout << "Stok motor " << daftarmotor[data->indeks] << " sudah habis." << endl;
                                        }
                                        ofstream outfile("DataPeminjam.txt", ios::app);
                                        outfile << "================== PEMINJAM ==================" << endl;
                                        outfile << "===============================================" << endl;
                                        outfile << "Nama Peminjam\t: " << data->nama << endl;
                                        outfile << "NIK Peminjam\t: " << data->nik << endl;
                                        outfile << "Jenis Motor\t: " << data->jenis_motor << endl;
                                        outfile << "Total Bayar\t: Rp. " << hitungharga(data->hargasewa, data->lamasewa) << endl;
                                        outfile << "\n===============================================" << endl << endl;
                                        outfile.close();
                                        cout << endl;
                                        cout << "1. revisi jml penyewaan(1.harian/2.mingguan)" << endl;
                                        cout << "2. Kembali ke menu utama" << endl;
                                        cout << "Pilihan = "; cin >> data->ulang;
                                        if (data->ulang == 2) {
                                            system("cls");
                                            cout << "Anda telah keluar dari program.";
                                            return;
                                        } else if (data->ulang != 1) {
                                            cout << "Masukkan angka dengan benar!!" << endl;
                                            cout << "Pilihan = "; cin >> data->ulang;
                                        }
                                    }
                                    break;
                                case 2 :
                                    while (true) {
                                        cout << "\nBerapa minggu anda ingin menyewa motor : ";
                                        cin >> data->lamasewa;
                                        if (data->lamasewa > 0) {
                                            break;
                                        }
                                        cout << "Waktu sewa harus lebih dari 0 minggu. Silakan coba lagi." << endl;
                                    }
                                    data->indeks = data->nomor - 1;
                                    if (data->indeks >= 0 && data->indeks < jml_motor) {
                                        data->hargasewa = hargamingguan[data->indeks];
                                        system("cls");
                                        cout << "=============== NOTA PEMINJAMAN ===============" << endl;
                                        cout << "===============================================" << endl;
                                        cout << "Nama Peminjam\t: " << data->nama << endl;
                                        cout << "NIK Peminjam\t: " << data->nik << endl;
                                        cout << "Jenis Motor\t: " << data->jenis_motor << endl;
                                        cout << "Lama Sewa\t: " << data->lamasewa << " minggu" << endl;
                                        cout << "Harga per-minggu: Rp. " << data->hargasewa << endl;
                                        cout << "----------------------------------------------" << endl;
                                        tampil_total(data->hargasewa, data->lamasewa, "mingguan");
                                        cout << "===============================================" << endl;
                                        if (stok_motor_awal[data->indeks] > 0) {
                                                stok_motor_awal[data->indeks]--;
                                        cout << "Anda telah menyewa motor " << daftarmotor[data->indeks] << ". Stok berkurang 1 unit." << endl;
                                        } else {
                                        cout << "Stok motor " << daftarmotor[data->indeks] << " sudah habis." << endl;
                                        }
                                        ofstream outfile("DataPeminjam.txt", ios::app);
                                        outfile << "================== PEMINJAM ==================" << endl;
                                        outfile << "===============================================" << endl;
                                        outfile << "Nama Peminjam\t: " << data->nama << endl;
                                        outfile << "NIK Peminjam\t: " << data->nik << endl;
                                        outfile << "Jenis Motor\t: " << data->jenis_motor << endl;
                                        outfile << "Total Bayar\t: Rp. " << hitungharga(data->hargasewa, data->lamasewa) << endl;
                                        outfile << "\n===============================================" << endl << endl;
                                        outfile.close();
                                        cout << endl;
                                        cout << "1. revisi jml penyewaan(1.harian/2.mingguan)" << endl;
                                        cout << "2. Kembali ke menu utama" << endl;
                                        cout << "Pilihan = "; cin >> data->ulang;
                                        if (data->ulang == 2) {
                                            system("cls");
                                            cout << "Anda telah keluar dari program.";
                                            return;
                                        } else if (data->ulang != 1) {
                                            cout << "Masukkan angka dengan benar!!" << endl;
                                            cout << "Pilihan = "; cin >> data->ulang;
                                        }
                                    }
                                    break;
                                default :
                                    cout << "Masukkan angka dengan benar!!" << endl;
                                    break;   
                            }
                        }
                    }
                }   
            }
        }
}
void pil2(motor* data) {
    int pilihan;
    while (true) {
        system("cls");
        cout << "\n============================== STOK MOTOR ==============================" << endl;
        cout << "\n1. Tampilkan Stok Motor";
        cout << "\n2. Reset Stok Motor";
        cout << "\n3. Kembali ke Menu Utama";
        cout << "\nPilihan = ";
        cin >> pilihan;
        switch (pilihan) {
            case 1:
                system("cls");
                cout << "\n[Stok Motor Tersedia]" << endl;
                for (int i = 0; i < jml_motor; i++) {
                    cout << i + 1 << ". " << daftarmotor[i] << " (" << "Stok: " << stok_motor_awal[i] << " unit)" << endl;
                }
                if (data->menu_awal == 1) {
                    cout << "Pilihan motor yang akan disewa (nomor): ";
                    int pilihan_motor;
                    cin >> pilihan_motor;
                    if (pilihan_motor >= 1 && pilihan_motor <= jml_motor) {
                        int indeks_motor = pilihan_motor - 1;
                        if (stok_motor_awal[indeks_motor] > 0) {
                            stok_motor_awal[indeks_motor]--;
                            cout << "Stok motor " << daftarmotor[indeks_motor] << " dikurangi menjadi " << stok_motor_awal[indeks_motor] << " unit." << endl;
                            cout << "Anda telah menyewa motor " << daftarmotor[indeks_motor] << ". Stok berkurang 1 unit." << endl;
                        } else {
                            cout << "Stok motor " << daftarmotor[indeks_motor] << " sudah habis." << endl;
                        }
                    } else {
                        cout << "Nomor motor tidak valid." << endl;
                    }
                }
                break;
            case 2:
                for (int i = 0; i < jml_motor; i++) {
        stok_motor_awal[i] = stok_motor_awal[jml_motor];
    }
                system("cls");
                cout << "\nStok Motor telah di-reset ke nilai awal." << endl;
                break;
            case 3:
                return;
            default:
                cout << "Pilihan tidak valid. Silakan coba lagi." << endl;
                break;
        }
        cout << "1. Kembali ke-awal" << endl;
        cout << "2. Keluar" << endl;
        cout << "Pilihan = "; cin >> data->ulang;
        if (data->ulang == 2) {
            system("cls");
            cout << "Anda telah keluar dari program.";
            return;
        } else if (data->ulang != 1) {
            cout << "Masukkan angka dengan benar!!" << endl;
            cout << "Pilihan = "; cin >> data->ulang;
        }
    }
}
void pil3(motor* data) {
    system("cls");
    string line;
    string nama_cari;
    cout << "Masukkan Nama Peminjam yang ingin dicari: ";
    cin.ignore();
    getline(cin, nama_cari);
    ifstream infile("DataPeminjam.txt");
    if (infile.is_open()) {
        bool found = false;
        while (getline(infile, line)) {
            if (line.find("Nama Peminjam\t: " + nama_cari) != string::npos) {
                found = true;
                cout << "\nData Peminjam Ditemukan:" << endl;
                cout << "===============================" << endl;
                cout << line << endl;
                getline(infile, line);
                cout << line << endl;
                getline(infile, line);
                cout << line << endl;
                getline(infile, line);
                cout << line << endl;
                cout << "===============================" << endl;
                break;
            }
        }
        if (!found) {
            cout << "\nData Peminjam dengan Nama " << nama_cari << " tidak ditemukan." << endl;
        }
        infile.close();
    } else {
        cout << "File tidak dapat dibuka. Pastikan file DataPeminjam.txt ada." << endl;
    }
    cout << "\nTekan Enter untuk kembali ke Menu Utama...";
    cin.ignore();
    cin.get();
}

int main() {
    motor* data = new motor;
    while (true) {
        tampilpolawal(data);
        if (data->menu_awal == 1) {
            pil1(data);
        } else if (data->menu_awal == 2) {
            pil2(data);
        } else if (data->menu_awal == 3) {
            pil3(data);
        } else if (data->menu_awal == 4) {
            system("cls");
            cout << "Anda telah keluar dari program.";
            break;
        }
    }
    delete data;
    return 0;
}