#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>

using namespace std;

class Buku {
    string judul;
    string penulis;
    int tahun_terbit;
    bool dipinjam;
    string peminjam;

public:
    Buku(string judul, string penulis, int tahun_terbit) {
        this->judul = judul;
        this->penulis = penulis;
        this->tahun_terbit = tahun_terbit;
        this->dipinjam = false;
        this->peminjam = "";
    }

    string getJudul() {
        return judul;
    }

    string getPeminjam() {
        return peminjam;
    }

    bool isDipinjam() {
        return dipinjam;
    }

    void pinjam(string peminjam) {
        if (dipinjam) {
            cout << "Buku sudah dipinjam." << endl;
        } else {
            dipinjam = true;
            this->peminjam = peminjam;
            cout << "Buku berhasil dipinjam." << endl;
        }
    }

    void kembalikan() {
        if (dipinjam) {
            dipinjam = false;
            this->peminjam = "";
            cout << "Buku berhasil dikembalikan." << endl;
        } else {
            cout << "Buku tidak dipinjam." << endl;
        }
    }

    void info() {
        cout << "Judul: " << judul << ", Penulis: " << penulis << ", Tahun Terbit: " << tahun_terbit;
        if (dipinjam) {
            cout << ", Status: Dipinjam oleh " << peminjam << endl;
        } else {
            cout << ", Status: Tersedia" << endl;
        }
    }

    string serialize() {
        return judul + "," + penulis + "," + to_string(tahun_terbit) + "," + (dipinjam ? "1" : "0") + "," + peminjam + "\n";
    }
};

class Perpustakaan {
    vector<Buku> daftar_buku;

public:
    int tambahBuku(Buku buku) {
        daftar_buku.push_back(buku);
    }

    void hapusBuku(string judul) {
        for (int i = 0; i < daftar_buku.size(); i++) {
            if (daftar_buku[i].getJudul() == judul) {
                daftar_buku.erase(daftar_buku.begin() + i);
                break;
            }
        }
    }

    void cariBuku(string judul) {
        for (Buku& buku : daftar_buku) {
            if (buku.getJudul() == judul) {
                buku.info();
                return;
            }
        }
        cout << "Buku tidak ditemukan." << endl;
    }

    void pinjamBuku(string judul, string peminjam) {
        for (Buku& buku : daftar_buku) {
            if (buku.getJudul() == judul) {
                buku.pinjam(peminjam);
                return;
            }
        }
        cout << "Buku tidak ditemukan." << endl;
    }

    void kembalikanBuku(string judul) {
        for (Buku& buku : daftar_buku) {
            if (buku.getJudul() == judul) {
                buku.kembalikan();
                return;
            }
        }
        cout << "Buku tidak ditemukan." << endl;
    }

    void tampilkanBuku() {
        for (Buku buku : daftar_buku) {
            buku.info();
        }
    }

    void simpanBukuKeFile(string namaFile) {
        ofstream file(namaFile);
        for (Buku buku : daftar_buku) {
            file << buku.serialize();
        }
        file.close();
    }

    void bacaBukuDariFile(string namaFile) {
        ifstream file(namaFile);
        string judul, penulis, tahun_terbit_str, dipinjam_str, peminjam;
        while (getline(file, judul, ',') && getline(file, penulis, ',') && getline(file, tahun_terbit_str, ',') && getline(file, dipinjam_str, ',') && getline(file, peminjam)) {
            int tahun_terbit = stoi(tahun_terbit_str);
            bool dipinjam = dipinjam_str == "1";
            Buku buku(judul, penulis, tahun_terbit);
            if (dipinjam) {
                buku.pinjam(peminjam);
            }
            tambahBuku(buku);
        }
        file.close();
    }

    void simpanPeminjamKeFile(string namaFile) {
        ofstream file(namaFile);
        for (Buku buku : daftar_buku) {
            if (buku.isDipinjam()) {
                file << buku.getPeminjam() << "," << buku.getJudul() << "\n";
            }
        }
        file.close();
    }

};

int main() {
    Perpustakaan perpus;

    int pilihan;
    do {
        cout << "======================================\n";
        cout << "=============My Mini Library==========\n";
        cout << "======================================\n\n";
        cout << "1. Tambah Buku\n2. Hapus Buku\n3. Cari Buku\n4. Pinjam Buku\n5. Kembalikan Buku\n6. Tampilkan Semua Buku\n7. My eBook\n8. Baca eBook\n9. Tambah Daftar Buku dari File\n10. Simpan Daftar Peminjam ke File\n0. Keluar\nPilih opsi: ";
        cin >> pilihan;
        cin.ignore();

        if (pilihan == 1) {
            string judul, penulis;
            int tahun_terbit;
            cout << "Masukkan judul buku: ";
            getline(cin, judul);
            cout << "Masukkan penulis buku: ";
            getline(cin, penulis);
            cout << "Masukkan tahun terbit buku: ";
            cin >> tahun_terbit;
            cin.ignore();
            perpus.tambahBuku(Buku(judul, penulis, tahun_terbit));
        } else if (pilihan == 2) {
            string judul;
            cout << "Masukkan judul buku yang ingin dihapus: ";
            getline(cin, judul);
            perpus.hapusBuku(judul);
        } else if (pilihan == 3) {
            string judul;
            cout << "Masukkan judul buku yang ingin dicari: ";
            getline(cin, judul);
            perpus.cariBuku(judul);
        } else if (pilihan == 4) {
            string judul, peminjam;
            cout << "Masukkan judul buku yang ingin dipinjam: ";
            getline(cin, judul);
            cout << "Masukkan nama peminjam: ";
            getline(cin, peminjam);
            perpus.pinjamBuku(judul, peminjam);
        } else if (pilihan == 5) {
            string judul;
            cout << "Masukkan judul buku yang ingin dikembalikan: ";
            getline(cin, judul);
            perpus.kembalikanBuku(judul);
        } else if (pilihan == 6) {
            perpus.tampilkanBuku();
        } else if (pilihan == 7) {
            string namaFile;
            cout << "Masukkan nama file: ";
            getline(cin, namaFile);
            perpus.simpanBukuKeFile(namaFile);
        } else if (pilihan == 8) {
            string namaFile;
            cout << "Masukkan nama file: ";
            getline(cin, namaFile);
            perpus.bacaBukuDariFile(namaFile);
        } else if (pilihan == 9) {
            string namaFile;
            cout << "Masukkan nama file: ";
            getline(cin, namaFile);
            perpus.bacaBukuDariFile(namaFile);
        } else if (pilihan == 10) {
            string namaFile;
            cout << "Masukkan nama file: ";
            getline(cin, namaFile);
            perpus.simpanPeminjamKeFile(namaFile);
        }
    } while (pilihan != 0);

    return 0;
}
