#include <iostream>
#include <windows.h>
#include <time.h>
#include <conio.h>
#include <cstdlib>

using namespace std;

int menu() {
    int choice;
    system("cls");
    cout << endl << endl;
    cout << "    =========SMART BAND========" << endl;
    cout << "    || 1. Clock              ||\n";
    cout << "    || 2. Monitoring Kalori  ||\n";
    cout << "    || 3. Deteksi Heart rate ||\n";
    cout << "    || 4. Stopwatch          ||\n";
    cout << "    || 5. Alarm              ||\n";
    cout << "    || 6. Exit               ||\n";
    cout << "    ==========================" << endl;
    cout << "    =>";
    cin >> choice;
    
    return choice;
}

void waktu() {
    system("cls");
    cout << "Tekan apa saja untuk kembali ke menu." << endl;
    int sec_prev = 0;
    while (1) {
        if (_kbhit()) {
            break;
        }

        int detik, menit, jam;

        //menyimpan total detik
        time_t total_detik = time(0);

        //mendapatkan nilai detik, menit, jam
        struct tm* ct = localtime(&total_detik);

        detik = ct->tm_sec;
        menit = ct->tm_min;
        jam = ct->tm_hour;

        //menampilkan hasil
        if (detik == sec_prev + 1 || (sec_prev == 59 && detik == 0)) {
            system("CLS");
            cout << "\n\n";
            cout << "   ====CLOCK====\n";
            cout << "  |" << jam << " : " << menit << " : " << detik << "|" << endl;
            cout << "   =============\n";
        }
        sec_prev = detik; //untuk menyimpan detik sebelumnya
    }
    cout << endl;
    cout << " Tekan apa saja untuk kembali ke menu utama." << endl;
    system("pause");
    system("cls");
    menu();
}

void monitoring() {
    system("cls");
    int jarak, langkah;
    double kalori;

    cout << "  langkah  : ";
    cin >> langkah;
    jarak = langkah / 3;
    kalori = jarak * 80 / 1000;
    cout << "   Meter   : " << jarak << " m " << endl;
    cout << "   kalori  : " << kalori << " cal " << endl;
    cout << "   Tekan untuk kembali ke menu utama." << endl;
    system("pause");
    system("cls");
    menu();
}

void heart_rate() {
    system("cls");
    int detak;
    char telp;
    cout << "  Deteksi heart rate\n ";
    cout << "   kencangkan band.. \n\n";
    cout << " Tekan apa saja untuk mulai\n";
    system("pause");
    for (int i = 60; i <= 100; i++) {
        cout << endl << " scanning . . . " << i << "%" << endl;
        system("cls");
    }
    detak = 40 + rand() % 200;
    cout << "\n\n" << "   Detak jantung anda : " << detak << " BPM " << endl;
    switch (detak) {
    case 0 ... 59:
        cout << "     => Detak jantung anda terlalu rendah. mohon segera istirahat. " << endl << endl;
        cout << "        Telepon dokter spesialis jantung ? (y/n) \n";
        cin >> telp;
        if ((telp == 'y') || (telp == 'y')) {
            cout << "Telepon dokter dan mengirim riwayat kesehatan...";
        }
        else if ((telp == 'n') || (telp == 'N')) {
            // do nothing
        }
        break;
    case 60 ... 100:
        cout << "    => Dalam kondisi normal." << endl;
        break;
    case 101 ... 999:
        cout << "    => Detak jantung anda terlalu tinggi.mohon segera istirahat. " << endl << endl;
        cout << "       Telepon dokter spesialis jantung ? (y/n) \n";
        cin >> telp;
        if ((telp == 'y') || (telp == 'y')) {
            cout << "\tTelepon dokter dan mengirim riwayat kesehatan...";
        }
        else if ((telp == 'n') || (telp == 'N')) {
            // do nothing
        }
        break;
    }
    cout << endl;
    cout << " Tekan untuk kembali ke menu utama." << endl;
    system("pause");
    system("cls");
    menu();
}

void stopwatch() {
    system("cls");
    int Jam = 0, Menit = 0, Detik = 0;
    cout << "               Stopwatch" << endl;
    cout << "             HH : MM : SS" << endl;
    cout << "              " << Jam << " : " << Menit << " : " << Detik << endl << endl;
    cout << "          Tekan untuk memulai\n" << endl;
    getch();

    while (!kbhit()) {
        Detik++;
        Sleep(1000);

        if (Detik > 59) {
            Menit++;
            Detik = 0;
        }
        if (Menit > 59) {
            Jam++;
            Menit = 0;
        }
        system("cls");
        cout << "          Stopwatch" << endl;
        cout << "         " << Jam << " : " << Menit << " : " << Detik << endl << endl;
        cout << "     Tekan apa saja untuk pause" << endl;
    }
    getch();

    cout << "       Waktu setelah pause" << endl;
    cout << "            " << Jam << " : " << Menit << " : " << Detik << endl << endl;
    getch();

    cout << "Tekan untuk kembali ke menu utama" << endl;
    system("pause");
    system("cls");
    menu();
}

void alarm() {
    system("cls");

    int j = 0, m = 0, d = 0, j1 = 0, m1 = 0, d1 = 0;

    cout << "Tekan Waktu di format JJ:MM:DD\n\n";
    cin >> j >> m >> d;

    cout << "Set Alarm di JJ:MM:DD\n\n";
    cin >> j1 >> m1 >> d1;

    if (j < 24 && m < 60 && d < 60) {
        for (int hour = j; hour < 24; hour++) {
            for (int minute = m; minute < 60; minute++) {
                for (int second = d; second < 60; second++) {
                    // Menghapus data layar yang ada
                    system("CLS");
                    cout << hour << " : " << minute << " : " << second;
                    // Kondisi ini digunakan untuk mengecek AM & PM
                    if (hour < 12) {
                        cout << " AM";
                    } else {
                        cout << " PM";
                    }

                    if (hour == j1 && minute == m1 && second == d1) {
                        for (int i = 0; i < 10; i++) {
                            Beep(1000, 500);
                            Sleep(500);
                        }
                        cout << endl;
                        cout << "Tekan enter untuk kembali ke menu utama." << endl;
                        cin.ignore(); // Membersihkan buffer input sebelum membaca karakter tambahan
                        cin.get();    // Menunggu pengguna menekan Enter
                        return;       // Keluar dari fungsi alarm setelah selesai
                    }

                    // Ini tidak akan menghentikan perulangan selama 1 detik
                    Sleep(1000);
                }
                d = 0;
            }
            m = 0;
        }
        j = 0;
    } else {
        cout << "Masukkan format waktu yang benar di JJ:MM:DD\n";
        system("pause");
        // Kembali ke menu utama atau sesuaikan dengan kebutuhan anda
    }
}


int main() {
    int choice;
    while(1) {
        choice = menu(); // Ambil pilihan dari menu
        switch (choice) {
            case 1:
                waktu();
                break;
            case 2:
                monitoring();
                break;
            case 3:
                heart_rate();
                break;
            case 4:
                stopwatch();
                break;
            case 5:
                alarm();
                break;
            case 6:
                exit(0);
                break;
            default:
                cout << endl;
                cout << "Pilihan tidak ditemukan." << endl;
                system("pause");
                break;
        }
        system("cls");
    }

    // Program akan keluar setelah memilih opsi 6 (Exit)
    return 0;
}
