#include <iostream>
#include <string>
using namespace std;

struct Kategori {
    int dewasa;
    int anak;
};

void beliTiket(Kategori* kategori) {
    int pilihan;
    char lagi;
    do {
        int jenisTKT;
        float jumlahTKT, totalTKT, bayar;
        string jenisTXT;

        cout << "==========================================================\n";
        cout << "\t             Pembelian Tiket\n";
        cout << "==========================================================\n";
        cout << " Keterangan\n";
        cout << " 1. Tiket Dewasa     : Rp. 35.000\n";
        cout << " 2. Tiket Anak-anak  : Rp. 20.000\n";
        cout << "==========================================================\n";
        cout << " Input Pembelian Tiket\n";
        cout << " Jenis Tiket (1-2)  : "; cin >> jenisTKT;
        cout << " Jumlah Tiket       : "; cin >> jumlahTKT;
        cout << "\n========================================================\n";

        if (jenisTKT == 1) {
            totalTKT = jumlahTKT * kategori->dewasa;
            jenisTXT = "Dewasa";
        } else if (jenisTKT == 2) {
            totalTKT = jumlahTKT * kategori->anak;
            jenisTXT = "Anak-anak";
        } else {
            cout << "Angka Yang Anda Input Salah\n\n";
            beliTiket(kategori); 
            return;
        }

        cout << "Jenis Tiket  : " << jenisTXT << endl;
        cout << "Jumlah Tiket : " << jumlahTKT << endl;
        cout << "                                       \n";
        cout << "Total Bayar  : Rp. " << totalTKT << endl;
        cout << "Uang Anda    : Rp. "; cin >> bayar;
        cout << "Kembalian    : Rp. " << bayar - totalTKT << endl << endl;

        cout << "Ingin Membeli Tiket Lagi? [Y/T]: ";
        cin >> lagi;
    } while (lagi == 'Y' || lagi == 'y');
}
 
void cekKursi() {
    int KursiTerisi, kursiksong;
    cout << "======================================================================\n";
    cout << "\t                   Cek Sisa Kursi\n";
    cout << "======================================================================\n";
    cout << "Keterangan \n";
    cout << "Jumlah Kursi Yang ada Di Bioskop XXI UNESA sebanyak 50 kursi\n";
    cout << "----------------------------------------------------------------------\n";
    cout << "Input Jumlah Kursi Yang Ingin Dipesan\n";

    cout << "Jumlah Pemesanan Kursi  : ";
    cin >> KursiTerisi;
    kursiksong = 50 - KursiTerisi;

    cout << "\n Sisa Kursi : " << kursiksong << endl;
    cout << "======================================================================\n\n";
}

void laporanPenjualan() {
    int tiketAnak[2], tiketDewasa[2], total[2];

    cout << "========================================================================\n";
    cout << "\t               Input Laporan Penjualan Tiket\n";
    cout << "------------------------------------------------------------------------\n";

    for (int angka = 0; angka < 2; angka++) {
        cout << "Input Data Penjualan " << angka + 1 << endl;
        cout << "Anak-anak    : "; cin >> tiketAnak[angka];
        cout << "Dewasa       : "; cin >> tiketDewasa[angka];
        cout << endl;
    }

    for (int angka = 0; angka < 2; angka++) {
        total[angka] = tiketAnak[angka] + tiketDewasa[angka];
    }

    cout << "====================================================================\n";
    cout << "\t           Input Laporan Penjualan Tiket\n";
    cout << "====================================================================\n";
    cout << "|   Tiket   |    Anak-anak    |    Dewasa    |   Total Penjualan   |\n";
    cout << "--------------------------------------------------------------------\n";

    for (int angka = 0; angka < 2; angka++) {
        cout << "|    " << angka + 1 << "               " << tiketAnak[angka] << "                " << tiketDewasa[angka] << "                " << total[angka] << "           |\n";
    }
}

int main() {
    Kategori kategori;
    kategori.dewasa = 35000;
    kategori.anak = 20000;

    int pilihan;
    do {
        cout << "----------------------------------------------------------\n";
        cout << "\t                Bioskop XXI UNESA\n";
        cout << "         JL. A. Yani Surabaya, Kec. ketintank\n";
        cout << "==========================================================\n";
        cout << "                      DAFTAR MENU\n";
        cout << "---------------------------------------\n";
        cout << "| 1. Pembelian Tiket                  |\n";
        cout << "| 2. Cek Sisa Kursi                   |\n";
        cout << "| 3. Laporan Penjualan Tiket          |\n";
        cout << "| 4. Keluar                           |\n";
        cout << "---------------------------------------\n";
        cout << "==========================================================\n\n";
        cout << " Masukkan Pilihan Anda (1-4): "; cin >> pilihan;

        switch (pilihan) {
            case 1:
                beliTiket(&kategori);
                break;
            case 2:
                cekKursi();
                break;
            case 3:
                laporanPenjualan();
                break;
            default:
                if (pilihan != 4)
                    cout << "Pilihan tidak valid! Masukkan angka 1-4.\n";
        }
    } while (pilihan != 4);

    return 0;
}
