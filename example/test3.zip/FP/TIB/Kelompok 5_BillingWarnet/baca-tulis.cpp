#include <iostream>
#include <fstream>
#include <set>
#include "json.hpp"
#include <iomanip>
#include <ctime>
#include <stdlib.h>

using namespace std;
using json = nlohmann::json;

struct User {
    int id;
    string username;
    string password;
    set<string> userPasswords;
};

json bukaFile(const string& namaFile) {
    ifstream file(namaFile);

    if (!file.is_open()) {
        cout << "File tidak ditemukan." << endl;
        return json();
    }

    json data;
    file >> data;

    file.close();
    return data;
}

void bacaFile(const json& data) {
    cout << "Isi file komputer.json:" << endl;
    for (const auto& komputer : data["komputer"]) {
        cout << "ID: " << komputer["id"] << ", Username: " << komputer["username"]
             << ", Password: " << komputer["password"] << ", Kredit Billing: " << komputer["kreditBilling"] << endl;
    }
}

void tulisKreditBilling(const string& namaFile, int id, int kreditBillingBaru) {
    json data = bukaFile(namaFile);

    bool akunDitemukan = false;

    for (auto& komputer : data["komputer"]) {
        if (komputer["id"] == id) {
            komputer["kreditBilling"] = kreditBillingBaru;
            akunDitemukan = true;
            break;
        }
    }

    if (akunDitemukan) {
        ofstream file(namaFile);
        file << setw(2) << data;
        file.close();
        cout << "Kredit Billing untuk akun dengan ID " << id << " berhasil diperbarui." << endl;
    } else {
        cout << "Akun dengan ID " << id << " tidak ditemukan." << endl;
    }
}

bool login(const string& namaFile, const string& username, const string& password, set<string>& userPasswords) {
    json data = bukaFile(namaFile);

    for (const auto& komputer : data["komputer"]) {
        string userpass = komputer["username"].get<string>() + ":" + komputer["password"].get<string>();
        if (!userPasswords.count(userpass) && komputer["username"] == username && komputer["password"] == password) {
            cout << "Login berhasil untuk akun dengan ID " << komputer["id"] << endl;
            userPasswords.insert(userpass);
            return true;
        }
    }

    cout << "Username atau password salah. Login gagal." << endl;
    return false;
}

void billingTimer(clock_t& lastUpdateTime, const string& namaFile, set<string>& userPasswords) {
    const int billingInterval = 5;  // seconds
    const int billingDecrease = 1000;

    while (true) {
        clock_t currentTime = clock();
        double elapsedTime = (currentTime - lastUpdateTime) / (double)CLOCKS_PER_SEC;

        if (elapsedTime >= billingInterval) {
            lastUpdateTime = currentTime;

            json data = bukaFile(namaFile);
            for (auto& komputer : data["komputer"]) {
                int currentBilling = komputer["kreditBilling"];
                if (currentBilling > 0) {
                    komputer["kreditBilling"] = max(0, currentBilling - billingDecrease);
                    system("cls");
                    bacaFile(data);
                }
            }

            ofstream file(namaFile);
            file << setw(2) << data;
            file.close();
        }
    }
}

int main() {
    const string namaFile = "komputer.json";

    json data = bukaFile(namaFile);
    if (!data.empty()) {
        bacaFile(data);

        // Initialize lastUpdateTime
        clock_t lastUpdateTime = clock();

        vector<User> users;

        while (true) {
            int choice;
            cout << "Menu Utama:" << endl;
            cout << "1. Login" << endl;
            cout << "2. Exit" << endl;
            cout << "Pilih: ";
            cin >> choice;

            if (choice == 1) {
                string username, password;
                cout << "Masukkan Username: ";
                cin >> username;

                cout << "Masukkan Password: ";
                cin >> password;

                User newUser;
                bool berhasilLogin = false;

                for (const auto& komputer : data["komputer"]) {
                    if (komputer["username"] == username && komputer["password"] == password) {
                        newUser.id = komputer["id"];
                        newUser.username = username;
                        newUser.password = password;
                        berhasilLogin = true;
                        break;
                    }
                }

                if (berhasilLogin) {
                    users.push_back(newUser);
                    cout << "Login berhasil untuk akun dengan ID " << newUser.id << endl;

                    // Operasi Billing
                    int kreditBillingBaru;

                    cout << "Masukkan Kredit Billing baru: ";
                    cin >> kreditBillingBaru;

                    tulisKreditBilling(namaFile, newUser.id, kreditBillingBaru);

                    data = bukaFile(namaFile);
                    bacaFile(data);
                } else {
                    cout << "Login gagal. Username atau password salah." << endl;
                }
            } else if (choice == 2) {
                break;
            } else {
                cout << "Pilihan tidak valid. Silakan coba lagi." << endl;
            }
        }

        // Run the billing timer for each user
        for (auto& user : users) {
            billingTimer(lastUpdateTime, namaFile, user.userPasswords);
        }
    }

    return 0;
}
