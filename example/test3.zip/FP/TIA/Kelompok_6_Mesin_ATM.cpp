#include <iostream>
#include <string>
using namespace std;

struct akun
{
    string username;
    string password;
    string password_awal;
} akun1;

char home='y';
char repeat_instructions = 'y';

//fungsi untuk ganti passsword
void gantipass(string& pass, string& pass_awal) 
{
    cout<<"===============================================\n";
    string password_confirm, new_password;
    cout<<"Masukan password lama :";
    cin>>password_confirm;

    //konfirmasi pass
    if (password_confirm==pass)
    {
        cout<<"Masukan password baru : ";
        cin>>new_password;
        cout<<"Password berhasil diperbarui\n";
        pass_awal=new_password;
        repeat_instructions='n';
        home='y';
    }
    else
    {
        //pass invalid
        cout<<"Password invalid. Pastikan password anda benar\n";
        cout<<"=================================================\n";
        repeat_instructions='n';
    }
}

int main() {
    cout << "=============================" << endl; 
    cout << "===== Program Mesin ATM =====" << endl; 
    cout << "======= Bank Nusantara ======" << endl; 
    cout << "=============================" << endl; 

    akun1.username, akun1.password, akun1.password_awal = "12345"; 
    int saldo = 100000;
    while (home == 'y')
    {
      cout << "\n"; 
      cout << "===== Login =====" << endl; 
      cout << "\n"; 
      cout << "Masukkan Username :"; 
      cin >> akun1.username; 
      cout << "Masukkan Password :"; 
      cin >> akun1.password; 

      if (akun1.username == "Kelompok6" && akun1.password == akun1.password_awal)
      {
        char repeat_instructions = 'y';
        int opsi;
        while (repeat_instructions == 'y')
        {
            cout << "\n"; 
            cout << "==== Selamat Datang di Bank Nusantara ====" << endl; 
            cout << "1. Periksa Saldo" << endl; 
            cout << "2. Tarik Saldo" << endl; 
            cout << "3. Isi Saldo" << endl; 
            cout << "4. Ganti password" << endl; 
            cout << "5. Keluar" << endl; 
            cout << "Silahkan memilih instruksi (1-5) :"; 
            cin >> opsi; 

            switch (opsi)
            {
                case 1: 
                {
                    cout << "====================================" << endl; 
                    cout << "Saldo anda sebesar" << saldo << " $ " << endl;

                    cout << "Apakah anda ingin mengulangi instruksi (y/n) :";
                    cin >> repeat_instructions;
                    cout << "====================================" << endl;

                    if (repeat_instructions != 'y')
                    {
                        cout << "\n"; 
                        cout << "Apakah anda ingin mengulang program? (y/n) :"; 
                        cin >> home; 
                    }
                    break; 
                }

                case 2: 
                {
                    cout << "=======================\n"; 
                    int minus; 
                    int *p=&minus;
                    cout << "Masukkan Nominal :"; 
                    cin >> *p; 
                    if (*p < saldo)
                    {
                        saldo -= *p; 
                        cout << "Tarik saldo berhasil" << endl; 
                        cout << "Saldo anda tersisa : " << saldo << "$" << endl; 
                    }
                    else 
                    {
                        cout << "Saldo anda tidak cukup. Sisa saldo anda" << saldo << "$" << endl; 
                    }
                    
                    cout << "Apakah anda ingin mengulangi instruksi? (y/n) :"; 
                    cin >> repeat_instructions; 
                    cout << "=============================================" << endl; 

                    if (repeat_instructions != 'y')
                    {
                        cout << "\n"; 
                        cout << "Apakah ingin mengulangi program? (y/n) :"; 
                        cin >> home; 
                    }
                    break; 
                }

                case 3:
                {
                    cout << "================================" << endl; 
                    int plus;
                    int *q=&plus;
                    cout << "Masukkan nominal :"; 
                    if (cin >> *q)
                    {
                        saldo += *q; 
                        cout << "Isi saldo berhasil" << endl; 
                        cout << "Saldo anda tersisa :" << saldo << "$" << endl; 
                    }
                    else 
                    {
                        cout << "Input tidak valid. Harap masukkan angka." << endl;                  
                    }

                    cout << "Apakah anda ingin mengulangi instruksi? (y/n)" << endl; 
                    cin >> repeat_instructions; 
                    cout << "=============================================" << endl; 

                    if (repeat_instructions != 'y')
                    {
                        cout << "\n"; 
                        cout << "Apakah anda ingin mengulangi program? (y/n) :"; 
                        cin >> home; 
                    }
                    break;    
                }

                case 4: 
                {
                    gantipass(akun1.password, akun1.password_awal);
                    break; 
                }

                case 5:
                {
                    repeat_instructions = 'n'; 
                    cout << "\n"; 
                    cout << "Apakah anda ingin mengulangi program? (y/n) :"; 
                    cin >> home; 
                    break; 
                }

                default:
                {
                    cout << "Instruksi tidak valid. Silahkan pilih 1-5 :" << endl; 
                }
                }    
            }
            cout << "==================================" << endl; 
        }
        else
        {
            cout << "Login gagal, pastikan username dan password benar!" << endl; 
        } 
    }
}