#include <iostream>
#include <string>
#include <iomanip>
#include <algorithm>
#include <ctime>
using namespace std;

struct Buku
{
    string kode;
    string judul;
    string penulis;
    int tahunTerbit;
    int stok; // Tambahkan variabel stok
    string status;
};

struct Pengunjung
{
    int NIM;
    string nama;
    string prodi;
    string alamat;
    int umur;
    string meminjamBuku[3]; // Maksimal peminjaman buku
    int jumlahPinjam;
};

struct Tanggal
{
    int DD, MM, YYYY;
} pinjam, pengembalian;

// Fungsi untuk menampilkan daftar buku
void daftarBuku(const Buku dataBuku[], int jumlahBuku)
{
    system("color 0A");
    cout << "===================================================================================" << endl;
    cout << "                              DAFTAR BUKU YANG TERSEDIA                        " << endl;
    cout << "===================================================================================" << endl;
    cout << "|  KODE BUKU  | |      JUDUL BUKU      | |   PENULIS    | | TAHUN TERBIT | | STOK |" << endl;
    cout << "-----------------------------------------------------------------------------------" << endl;

    for (int i = 0; i < jumlahBuku; ++i)
    {
        cout << "| " << setw(11) << left << dataBuku[i].kode << " | | " << setw(20) << left << dataBuku[i].judul
             << " | | " << setw(12) << left << dataBuku[i].penulis << " | | " << setw(12) << left << dataBuku[i].tahunTerbit
             << " | | " << setw(4) << left << dataBuku[i].stok << " |" << endl;
    }

    cout << "----------------------------------------------------------------------------------" << endl;
}

// Fungsi untuk validasi tanggal
bool tanggalBuku(const Tanggal &tanggal)
{
    // Implementasi validasi tanggal (misalnya, validasi sederhana)
    return tanggal.DD >= 1 && tanggal.DD <= 31 &&
           tanggal.MM >= 1 && tanggal.MM <= 12 &&
           tanggal.YYYY >= 1900;
}

int main()
{
    const int jumlahPengunjung = 3;
    Pengunjung dataPengunjung[3] = {
        {123, "Ajeng", "S1 Teknik Informatika", "Aceh", 0},
        {456, "Budi", "S1 Sistem Informasi", "Bandung", 0},
        {789, "Caca", "S1 Pendidikan Teknologi Informasi", "Cirebon", 0}};

    const int jumlahBuku = 5;
    Buku dataBuku[5] = {
        {"ab1", "Coding", "John", 2015, 5},
        {"bc2", "Programmer", "Sharla", 2022, 3},
        {"cd3", "Bahasa C++", "Doni", 2013, 2},
        {"de4", "Hacker", "Shania", 2021, 1},
        {"ef5", "Web Developer", "cyntia", 2019, 4}};

    string inputKodeBuku;
    int NIMPengunjungTerdaftar[] = {0};
    int totalPengunjung = 0;

    while (true)
    {
        system("cls");
        system("color 8F");

        cout << "========================================" << endl;
        cout << "          SELAMAT DATANG DI             " << endl;
        cout << "       PERPUSTAKAAN INFORMATIKA         " << endl;
        cout << "      UNIVERSITAS NEGERI SURABAYA        " << endl;
        cout << "========================================" << endl;

        int inputNIM;
        cout << "Masukkan NIM anda (0 untuk keluar) : ";
        cin >> inputNIM;

        if (inputNIM == 0)
        {
            break;
        }

        bool found = false;
        for (int i = 0; i < jumlahPengunjung; ++i)
        {
            if (inputNIM == dataPengunjung[i].NIM)
            {
                cout << "   NIM \t\t\t: " << dataPengunjung[i].NIM << endl;
                cout << "   Nama \t\t: " << dataPengunjung[i].nama << endl;
                cout << "   Prodi \t\t: " << dataPengunjung[i].prodi << endl;
                cout << "   Alamat \t\t: " << dataPengunjung[i].alamat << endl;

                if (find(NIMPengunjungTerdaftar, NIMPengunjungTerdaftar + totalPengunjung, inputNIM) == NIMPengunjungTerdaftar + totalPengunjung)
                {
                    totalPengunjung++;
                    NIMPengunjungTerdaftar[totalPengunjung - 1] = inputNIM;
                }

                cout << "   Total Pengunjung \t: " << totalPengunjung << endl;
                found = true;

                cout << "==========================================" << endl;

                int pilihanMeminjam;
                cout << "   Opsi" << endl;
                cout << "   1. Pinjam buku \n   2. Pengembalian buku \n   3. Hanya membaca" << endl;
                cout << "Pilih salah satu (1/2/3): ";
                cin >> pilihanMeminjam;
                system("cls");

                int j;
                int jumlahPinjam;
                string pilihanYakin;
                switch (pilihanMeminjam)
                {
                case 1:
                {
                    system("color 5D");
                    daftarBuku(dataBuku, jumlahBuku);

                    if (dataPengunjung[i].jumlahPinjam < 3)
                    {
                        cout << "Masukkan kode buku : ";
                        cin >> inputKodeBuku;
                        cout << "===========================================" << endl;

                        bool bukuDitemukan = false;
                        for (int j = 0; j < jumlahBuku; ++j)
                        {
                            if (inputKodeBuku == dataBuku[j].kode)
                            {
                                bukuDitemukan = true;

                                if (dataBuku[j].stok > 0)
                                {
                                    cout << "   Kode Buku     : " << inputKodeBuku << endl;
                                    cout << "   Judul Buku    : " << dataBuku[j].judul << endl;
                                    cout << "   Nama Penulis  : " << dataBuku[j].penulis << endl;
                                    cout << "   Tahun Terbit  : " << dataBuku[j].tahunTerbit << endl;

                                    cout << "Apakah anda yakin? (ya/tidak) : ";
                                    cin >> pilihanYakin;
                                    if (pilihanYakin == "ya")
                                    {
                                        dataBuku[j].status = "dipinjam";
                                        dataPengunjung[i].meminjamBuku[dataPengunjung[i].jumlahPinjam] = inputKodeBuku;
                                        dataPengunjung[i].jumlahPinjam++;

                                        dataBuku[j].stok--;

                                        cout << "Masukkan tanggal peminjaman (DD MM YYYY): ";
                                        cin >> pinjam.DD >> pinjam.MM >> pinjam.YYYY;

                                        const int batasWaktu = 7;
                                        time_t t = time(nullptr);
                                        tm *now = localtime(&t);
                                        now->tm_year = pinjam.YYYY - 1900;
                                        now->tm_mon = pinjam.MM - 1;
                                        now->tm_mday = pinjam.DD + batasWaktu;

                                        mktime(now);

                                        pengembalian = {now->tm_mday, now->tm_mon + 1, now->tm_year + 1900};
                                        system("cls");

                                        system("color 0D");
                                        cout << "==========================================" << endl;
                                        cout << "Kode Buku \t\t: " << inputKodeBuku << endl;
                                        cout << "Judul Buku   \t\t: " << dataBuku[j].judul << endl;
                                        cout << "Nama Penulis \t\t: " << dataBuku[j].penulis << endl;
                                        cout << "Tahun Terbit \t\t: " << dataBuku[j].tahunTerbit << endl;
                                        cout << "Tanggal Peminjaman   \t: " << pinjam.DD << " " << pinjam.MM << " " << pinjam.YYYY << endl;
                                        cout << "Tanggal Pengembalian \t: " << pengembalian.DD << " " << pengembalian.MM << " " << pengembalian.YYYY << endl;
                                        cout << "\n=========================================="<< endl;
                                        cout << "\tSELAMAT! Anda berhasil meminjam buku ini" << endl;
                                        cout << "\t  Jangan lupa kembalikan tepat waktu" << endl;
                                        cout << "\t\tHave a nice day!" << endl;
                                    }
                                }
                                else if (inputKodeBuku == dataBuku[j].kode && dataBuku[j].stok == 0)
                                {
                                    cout << "Maaf, buku ini sudah dipinjam sebelumnya." << endl;
                                }
                                break;
                            }
                        }

                        if (!bukuDitemukan)
                        {
                            cout << "Maaf, buku dengan kode tersebut tidak ditemukan." << endl;
                        }
                    }
                    else
                    {
                        cout << "Maaf, Anda sudah meminjam 3 buku. Harap kembalikan buku sebelumnya untuk melakukan peminjaman baru." << endl;
                    }
                    break;
                }

                case 2:
                {
                    system("color 07");
                    cout << "==========================================" << endl;
                    cout << "Masukkan kode buku yang dikembalikan: ";
                    cin >> inputKodeBuku;

                    // Cari buku yang akan dikembalikan
                    bool bukuDitemukan = false;
                    for (j = 0; j < jumlahBuku; ++j)
                    {
                        if (inputKodeBuku == dataPengunjung[i].meminjamBuku[j])
                        {
                            // Hapus buku dari daftar peminjaman pengunjung
                            dataPengunjung[i].meminjamBuku[j] = "";
                            dataBuku[j].stok++; // Tambahkan stok buku karena ada pengembalian

                            cout << "Kode Buku \t\t: " << inputKodeBuku << endl;
                            cout << "Judul Buku   \t\t: " << dataBuku[j].judul << endl;
                            cout << "Nama Penulis \t\t: " << dataBuku[j].penulis << endl;
                            cout << "Tahun Terbit \t\t: " << dataBuku[j].tahunTerbit << endl;
                            cout << "Tanggal Peminjaman   \t: " << pinjam.DD << " " << pinjam.MM << " " << pinjam.YYYY << endl;
                            cout << "Tanggal Pengembalian \t: " << pengembalian.DD << " " << pengembalian.MM << " " << pengembalian.YYYY << endl;
                            cout << "Apakah anda yakin ingin mengembalikan buku ini? (ya/tidak): ";
                            cin >> pilihanYakin;
                            if (pilihanYakin == "ya")
                            {
                                cout << "\n"
                                     << "\tAnda berhasil mengembalikan buku ini" << endl;
                            }
                            bukuDitemukan = true;
                        }
                        break;
                    }
                    if (!bukuDitemukan)
                    {
                        cout << "\tAnda belum meminjam buku ini" << endl;
                    }
                    break;
                }
                case 3:
                {
                    system("color 0E");
                    cout << "\tHave fun in library " << endl;
                    break;
                }
                default:
                {
                    cerr << "Error: Pilihan tidak valid." << endl;
                    break;
                }
                }
            }
        }

        if (!found)
        {
            cerr << "Error: Data tidak ditemukan untuk NIM " << inputNIM << "." << endl;
        }

        cout << "==========================================" << endl;
        cout << "Tekan Enter untuk melanjutkan...";
        cin.ignore();
        cin.get();
    }

    cout << "Terima kasih telah berkunjung!" << endl;
    return 0;
}