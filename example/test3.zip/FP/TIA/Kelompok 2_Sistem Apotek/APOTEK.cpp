#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

struct Obat {
    int kode;
    string nama;
    int stok;
    int hargaSatuan;
};

// DEKLARASI FUNGSI
void bacaFile();
void menu();
void penjualan();
void dataBarang();
void reStokDanTambahObatBaru();
void laporan();
void simpanData();

// VARIABEL GLOBAL
const int MAX_BARANG = 100;
Obat inventory[MAX_BARANG];
Obat hasilPenjualan[MAX_BARANG];

int main (){

    bacaFile();
           
    // MASUK PILIHAN MENU
    int pilihanMenu;
    do {
        menu();

        cout << " Masukkan Pilihan Menu : ";
        cin >> pilihanMenu;

        switch (pilihanMenu){
        case 1:
            // PENJUALAN
            penjualan();
            break;
        case 2:
            // INVENTORY
            dataBarang() ;
            break;
        case 3:
            // RE-STOK
            reStokDanTambahObatBaru();
            break;
        case 4:
            // LAPORAN
            laporan();
            break;
        case 5:
            // SIMPAN DATA DAN KELUAR PROGRAM
            simpanData();
            return 0;
        default:
            cout << "## Pilihan Menu Tidak Tersedia ##\n";
        }
    
    } while (pilihanMenu !=5);

    return 0;
}


// FUNGSI-FUNGSI

void bacaFile(){
    ifstream file("stok.txt");
    
    if (file.is_open()) {
        string baris;
        int i = 0;

        while (getline(file, baris) && i < MAX_BARANG) {
            stringstream ss(baris);
            string temp;

            getline(ss, temp, ';');
            inventory[i].kode = stoi(temp);

            getline(ss, temp, ';');
            inventory[i].nama = temp;

            getline(ss, temp, ';');
            inventory[i].stok = stoi(temp);

            getline(ss, temp, ';');
            inventory[i].hargaSatuan = stoi(temp);

            i++;
        }
        file.close();
    }
}

void menu(){
    cout << endl ;
    cout << " ======================== " << endl;
    cout << "     APOTEK SEHAT JAYA    " << endl;
    cout << " ======================== " << endl;
    cout << " --------- MENU --------- " << endl;
    cout << " 1. Penjualan\n";
    cout << " 2. Inventory\n";
    cout << " 3. Re-Stok\n";
    cout << " 4. Laporan\n";
    cout << " 5. Keluar\n";
}

void penjualan() {
    cout << endl;
    cout << " ------ PENJUALAN ------ " << endl;

    int kodeObat, terjual;
    bool obatDitemukan = false;
    cout << "Kode Obat: ";
    cin >> kodeObat;
    cout << "Terjual: ";
    cin >> terjual;

    for (int j = 0; j < MAX_BARANG; j++) {
        if (inventory[j].kode == kodeObat) {
            obatDitemukan = true;

            if (inventory[j].stok < terjual) {
                cout << "## Sisa Stok " << inventory[j].nama << " Tidak Cukup ##" << endl;
            } else {
                // CARI INDEKS KOSONG PERTAMA UNTUK DIISI
                int k = 0;
                while (hasilPenjualan[k].kode != 0 && k < 1000) {
                    k++;
                }

                if (k >= 1000) {
                    cout << "## BATAS MAXIMAL PENJUALAN ##" << endl;
                    return;
                }

                hasilPenjualan[k].kode = inventory[j].kode;
                hasilPenjualan[k].nama = inventory[j].nama;
                hasilPenjualan[k].stok = terjual;
                inventory[j].stok -= terjual;

                hasilPenjualan[k].hargaSatuan = inventory[j].hargaSatuan;
                cout << "=> Obat " << inventory[j].nama << " terjual " << terjual << endl;
            }
            break;
        }
    }

    if (!obatDitemukan) {
        cout << "## Kode Obat yang anda masukkan tidak ada dalam inventory ##" << endl;
    }
}


void dataBarang(){
    cout << endl;
    cout << " ------ INVENTORY ------ " << endl;

    for (int i = 0; i < MAX_BARANG; i++)
    {
        if (inventory[i].kode != 0)
        {
        cout << "Kode Obat : " << inventory[i].kode << " || ";
        cout << "Sisa Stok : " << inventory[i].stok << " || " ;
        cout << "Harga Satuan : " << inventory[i].hargaSatuan << " || " ;
        cout << "Nama Obat : " << inventory[i].nama ;
        cout << endl ;
        }   
    }
}

void reStokDanTambahObatBaru() {
    cout << endl;
    cout << " ------ RE-STOK ATAU TAMBAH OBAT BARU ------ " << endl;

    int pilihan;
    cout << "Pilih 1 untuk re-stok, 2 untuk tambah obat baru: ";
    cin >> pilihan;

    if (pilihan == 1) {
        int kode, tambah;
        cout << "Masukkan kode obat yang ingin ditambah stoknya: ";
        cin >> kode;
        cout << "Masukkan jumlah stok yang ingin ditambah: ";
        cin >> tambah;

        for (int i = 0; i < MAX_BARANG; i++) {
            if (inventory[i].kode == kode) {
                inventory[i].stok += tambah;
                cout << "=> Stok obat " << inventory[i].nama << " sekarang adalah " << inventory[i].stok << endl;
                return;
            }
        }
        cout << "## Obat dengan kode " << kode << " tidak ditemukan ##" << endl;
    } else if (pilihan == 2) {
        string nama;
        int stok, hargaSatuan;
        int kode = 0;

        // MENCARI KODE OBAT TERAKHIR DI INVENTORY
        for (int i = 0; i < MAX_BARANG; i++) {
            if (inventory[i].kode > kode) {
                kode = inventory[i].kode;
            }
        }

        kode++;

        cout << "Masukkan nama obat baru: ";
        cin.ignore();
        getline(cin, nama);
        cout << "Masukkan jumlah stok obat baru: ";
        cin >> stok;
        cout << "Masukkan harga satuan obat baru: ";
        cin >> hargaSatuan;



        for (int i = 0; i < MAX_BARANG; i++) {
            if (inventory[i].kode == 0) {
                inventory[i].kode = kode;
                inventory[i].nama = nama;
                inventory[i].stok = stok;
                inventory[i].hargaSatuan = hargaSatuan;
                cout << "=> Obat baru " << nama << " dengan kode " << kode << " telah ditambahkan." << endl;
                return;
            }
        }
        cout << "## Gudang sudah penuh, tidak bisa menambah obat baru ##" << endl;
    } else {
        cout << "## Pilihan tidak valid ##" << endl;
        return;
    }
}


void laporan() {
    cout << endl;
    cout << "   LAPORAN APOTEK SEHAT JAYA   " << endl;
    cout << " ============================= " << endl;
    cout << " -- HASIL PENJUALAN HARI INI -- " << endl;
        
    int totalHarga ;
    int totalPendapatan = 0;
        
        for (int i = 0; i < MAX_BARANG; i++){
            if (hasilPenjualan[i].kode != 0){
                cout << "Kode Obat : " << hasilPenjualan[i].kode << " || ";
                cout << "Nama Obat : " << hasilPenjualan[i].nama << " || "  ;
                cout << "Terjual : " << hasilPenjualan[i].stok ;
                cout << endl ;
                
                totalHarga = hasilPenjualan[i].stok * hasilPenjualan[i].hargaSatuan;
                totalPendapatan = totalPendapatan + totalHarga;
            }   
        }
    cout << "=> Total Pendapatan Hari Ini adalah Rp " << totalPendapatan;
    cout << endl ;
}

void simpanData() {
    ofstream file("stok.txt");
    
    if (file.is_open()) {
        for (int i = 0; i < MAX_BARANG; i++) {
            if (inventory[i].kode != 0) {
                file << inventory[i].kode << ";" << inventory[i].nama << ";" << inventory[i].stok << ";" << inventory[i].hargaSatuan << "\n";
            }
        }
        file.close();
    }
}



