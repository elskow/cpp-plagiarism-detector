#include <iostream>                        
#include <fstream>
#include <iomanip>                      
using namespace std;

void getData();
void calculate();
void showData();
void table();

struct dataSiswa {
    int no;
    string nim;
    char nama[20];
    int mat[5], bin[5], bing[5], ipa[5], ips[5];
    float matTotal, binTotal, bingTotal, ipaTotal, ipsTotal;
    float avg;
    char grade;
} mhs;

void getData () {
    cout << "No.Urut : ";
    cin >> mhs.no;
    cout << "NIM : ";
    cin >> mhs.nim;
    cout << "Nama : ";
    cin.ignore();
    cin.getline(mhs.nama, 20);
    cout << "\nNilai Matematika : " << endl;
    for (int i=0; i<5; i++) {
        cout << "\tNilai ke-" << i+1 << " : ";
        cin >> mhs.mat[i];
    }
    cout << "\nNilai Bahasa Indonesia : " << endl;
    for (int i=0; i<5; i++) {
        cout << "\tNilai ke-" << i+1 << " : ";
        cin >> mhs.bin[i];
    }
    cout << "\nNilai Bahasa Inggris : " << endl;
    for (int i=0; i<5; i++) {
        cout << "\tNilai ke-" << i+1 << " : ";
        cin >> mhs.bing[i];
    }
    cout << "\nNilai IPA : " << endl;
    for (int i=0; i<5; i++) {
        cout << "\tNilai ke-" << i+1 << " : ";
        cin >> mhs.ipa[i];
    }
    cout << "\nNilai IPS : " << endl;
    for (int i=0; i<5; i++) {
        cout << "\tNilai ke-" << i+1 << " : ";
        cin >> mhs.ips[i];
    }
    calculate();
}

void calculate () {
    mhs.matTotal=0;
    for (int i=0; i<5; i++) {
        mhs.matTotal+=mhs.mat[i];
    }
    mhs.matTotal/=5;
    mhs.binTotal=0;
    for (int i=0; i<5; i++) {
        mhs.binTotal+=mhs.bin[i];
    }
    mhs.binTotal/=5;
    mhs.bingTotal=0;
    for (int i=0; i<5; i++) {
        mhs.bingTotal+=mhs.bing[i];
    }
    mhs.bingTotal/=5;
    mhs.ipaTotal=0;
    for (int i=0; i<5; i++) {
        mhs.ipaTotal+=mhs.ipa[i];
    }
    mhs.ipaTotal/=5;
    mhs.ipsTotal=0;
    for (int i=0; i<5; i++) {
        mhs.ipsTotal+=mhs.ips[i];
    }
    mhs.ipsTotal/=5;
    mhs.avg=(mhs.matTotal+mhs.binTotal+mhs.bingTotal+mhs.ipaTotal+mhs.ipsTotal)/5;
    if (mhs.avg>=90) {
        mhs.grade = 'A';
    } else if (mhs.avg>=80) {
        mhs.grade = 'B';
    } else if (mhs.avg>=70) {
        mhs.grade = 'C';
    } else if (mhs.avg>=60) {
        mhs.grade = 'D';
    } else if (mhs.avg>=50) {
        mhs.grade = 'E';
    } else {
        mhs.grade = 'F';
    }
}

void showData () {
    cout << "NIM : " << mhs.nim;
    cout << "\nNama : " << mhs.nama;
    cout << "\nNilai Matematika : " << mhs.matTotal;
    cout << "\nNilai Bahasa Indonesia : " << mhs.binTotal;
    cout << "\nNilai Bahasa Inggris : " << mhs.bingTotal;
    cout << "\nNilai IPA : " << mhs.ipaTotal;
    cout << "\nNilai IPS : " << mhs.ipsTotal;
    cout << "\nNilai Rata-Rata : " << mhs.avg;
    cout << "\nGrade : " << mhs.grade << endl;
}

void table () {
    cout << left << setw(15) << mhs.nim << left << setw(20) << mhs.nama << left << setw(6) << mhs.matTotal << left << setw(6) << mhs.binTotal << left << setw(6) << mhs.bingTotal << left << setw(6) << mhs.ipaTotal << left << setw(6) << mhs.ipsTotal << left << setw(10) << mhs.avg << left << setw(5) << mhs.grade << endl;
}

void entryMenu();
void createData();
void searchData(int);
void modifyData(int);
void deleteData(int);
void resultMenu();
void classResult();

int main () {
    char opt;
    do {
        system ("cls");
        cout << "\n\n\tMAIN MENU";
        cout << "\n\n\t01.Entry Menu";
        cout << "\n\n\t02.Result Menu";
        cout << "\n\n\t03.Exit Aplication";
        cout << "\n\n\tSelect your option (1-3) ";
        cin >> opt;
        switch (opt) {
        case '1' : entryMenu();
            break;
        case '2' : resultMenu();
            break;
        case '3' :
            break;
        default  : cout << "\a";
        }
    } while (opt!='3');
    return 0;
}

void createData () {
    ofstream file;
    file.open("data.dat", ios::binary|ios::app);
    getData();
    if (!file) {
        cout << "File tidak dapat dibuka!!!\n";
    } else {
        file.write(reinterpret_cast<char *> (&mhs), sizeof(dataSiswa));
        file.close();
    }
    cout << "Data Telah Disimpan . . . \n" << endl;
    system("pause");
}

void searchData (int n) {
    ifstream file;
    file.open("data.dat", ios::binary|ios::app);
    if (!file) {
        cout << "File tidak dapat dibuka!!!\n";
        system("pause");
        return;
    }
    bool X=false;
    while (file.read(reinterpret_cast<char *> (&mhs), sizeof(dataSiswa))) {
        if (n==mhs.no) {
            showData();
            X=true;
        }
    }
    file.close();
    if (X==false)
        cout << "\n\tData tidak ditemukan\n";
    system("pause");
}

void modifyData (int n) {
    bool found=false;
    fstream file;
    file.open("data.dat", ios::binary|ios::in|ios::out);
    if (!file) {
        cout << "File tidak dapat dibuka!!!\n";
        system("pause");
        return;
    }
    while (!file.eof() && found==false) {
        file.read(reinterpret_cast<char *> (&mhs), sizeof(dataSiswa));
        if(n==mhs.no) {
            showData();
            cout << "\nMasukkan Data yang Baru : \n";
            getData();
            int pos=(-1)*static_cast<int>(sizeof(mhs));
            file.seekp(pos, ios::cur);
            file.write(reinterpret_cast<char *> (&mhs), sizeof(dataSiswa));
            cout << "\n\tData diperbarui . . . \n";
            found = true;
        }
    }
    file.close();
    if (found==false) {
        cout << "\n\tData tidak ditemukan!!!\n";
        system("pause");
    }
}

void deleteData (int n) {
    int pos, X=0;

    ifstream dataFile;
    dataFile.open("data.dat", ios::binary);
    if (!dataFile) {
        cout << "File tidak ditemukan!!!\n";
        system("pause");
        return;
    }
    ofstream tempFile;
    tempFile.open("temp.dat", ios::out|ios::binary);
    dataFile.seekg(0,ios::beg);
    while (!dataFile.eof()) {
        dataFile.read(reinterpret_cast<char *> (&mhs), sizeof (dataSiswa));
        if (dataFile) {
            if (n==mhs.no) {
                X=1;
            } else {
                tempFile.write(reinterpret_cast<char *> (&mhs), sizeof(dataSiswa));
            }
        }
    }
    tempFile.close();
    dataFile.close();
    remove("data.dat");
    rename("temp.dat","data.dat");

    if (X==1) {
        cout << "\n\tData telah dihapus. . .\n";
        system("pause");
    } else {
        cout << "\n\tData tidak ditemukan. . .\n";
        system("pause");
    }
}

void classResult () {
    ifstream file;
    file.open("data.dat", ios::binary);
    if(!file) {
        cout << "File tidak dapat dibuka!!!\n";
        system("pause");
        return;
    }
    cout << "\n\n\t\tSEMUA HASIL MAHASISWA\n\n";
    cout << "================================================================================\n";
    cout << "    NIM             Nama           MAT   BIN   BING  IPA   IPS   RATA    Grade\n";
    cout << "================================================================================\n";
    while (file.read(reinterpret_cast<char *> (&mhs), sizeof(dataSiswa))) {
        table();
    }
    cin.ignore();
    cin.get();
    file.close();
}

void resultMenu () {
    char opt;
    int num;
    system ("cls");
    cout << "\n\n\tRESULT MENU";
    cout << "\n\n\t01.Class Result";
    cout << "\n\n\t02.Student Report";
    cout << "\n\n\t03.Back to Main Menu";
    cout << "\n\n\tSelect your option (1-3) ";
    cin >> opt;
    system ("cls");
     switch (opt) {
     case '1' : classResult(); break;
     case '2' : cout << "Masukkan No.Urut : "; cin >> num; searchData(num);
     case '3' : break;
     default: cout << "\a"; resultMenu();
     }
}

void entryMenu() {
    char opt;
    int num;
    system ("cls");
    cout << "\n\n\tENTRY MENU";
    cout << "\n\n\t01.Add Student Record";
    cout << "\n\n\t02.Search Student Record";
    cout << "\n\n\t03.Modify Student Record";
    cout << "\n\n\t04.Delete Student Record";
    cout << "\n\n\t05.Back to Main Menu";
    cout << "\n\n\tSelect Your Option (1-5) ";
    cin >> opt;
    system ("cls");
    switch (opt) {
    case '1' : createData(); break;
    case '2' : cout << "Masukkan No.Urut : "; cin >> num; searchData(num); break;
    case '3' : cout << "Masukkan No.Urut : "; cin >> num; modifyData(num); break;
    case '4' : cout << "Masukkan No.Urut : "; cin >> num; deleteData(num); break;
    case '5' : break;
    default  : cout << "\a"; entryMenu();
    }
}