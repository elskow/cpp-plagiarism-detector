#include <iostream>
#include <fstream>
#include <string>
using namespace std;

struct Karyawan {
    string nama;
    long long id;
    string jabatan;
};

bool konfirmasiLanjut() {
    int konfirmasi;
    cout << "\nTekan 1 untuk lanjut ke menu utama, atau 0 untuk keluar: ";
    cin >> konfirmasi;

    if (konfirmasi == 1) {
        return true;  // Lanjut
    } else if (konfirmasi == 0) {
        system("cls");
        cout << "\nTerima kasih!\n";
        return false;  // Keluar
    } else {
        system("cls");
        cout << "\nPilihan tidak valid. Kembali ke menu utama.\n";
        return true;  // Lanjut
    }
}

void simpanKeFile(const Karyawan[], int);
void bacaDariFile(Karyawan[], int&);
void tampilkanMenu();
void tambahKaryawan(Karyawan*&, int&, int&);
void tampilkanDaftarKaryawan(const Karyawan*, int);
void hapusKaryawan(Karyawan*&, int&, int&);
void sortingById(Karyawan*, int);
Karyawan cariKaryawanById(const Karyawan*, int, long long);
bool hapusSemuaData(string password);

int main() {
    int kapasitasKaryawan = 100;  // Kapasitas awal array dinamis
    Karyawan* daftarKaryawan = new Karyawan[kapasitasKaryawan];
    int jumlahKaryawan = 0;
    string password = "PresentationEnd";  // Ganti dengan password yang diinginkan

    bacaDariFile(daftarKaryawan, jumlahKaryawan);

    int pilihan;
    do {
        system("cls");
        tampilkanMenu();
        cout << "Pilihan Anda: ";
        cin >> pilihan;
        cin.ignore();

        switch (pilihan) {
            case 1:
                system("cls");
                tambahKaryawan(daftarKaryawan, jumlahKaryawan, kapasitasKaryawan);
                sortingById(daftarKaryawan, jumlahKaryawan);
                simpanKeFile(daftarKaryawan, jumlahKaryawan); // Simpan Setelah Tambah
                if (!konfirmasiLanjut()) {
                    pilihan = 0;
                }
                break;

            case 2:
                system("cls");
                tampilkanDaftarKaryawan(daftarKaryawan, jumlahKaryawan);
                if (!konfirmasiLanjut()) {
                    pilihan = 0;
                }
                break;

            case 3:
                system("cls");
                hapusKaryawan(daftarKaryawan, jumlahKaryawan, kapasitasKaryawan);
                sortingById(daftarKaryawan, jumlahKaryawan);
                simpanKeFile(daftarKaryawan, jumlahKaryawan); // Simpan setelah Hapus
                if (!konfirmasiLanjut()) {
                    pilihan = 0;
                }
                break;

            case 4:
                {
                    system("cls");
                    long long idCari;
                    cout << "Masukkan ID karyawan yang ingin dicari: ";
                    cin >> idCari;
                    Karyawan hasilPencarian = cariKaryawanById(daftarKaryawan, jumlahKaryawan, idCari);
                    if (hasilPencarian.id != -1) {
                        cout << "\nKaryawan ditemukan!\n";
                        cout << "ID      : " << hasilPencarian.id << "\n";
                        cout << "Nama    : " << hasilPencarian.nama << "\n";
                        cout << "Jabatan : " << hasilPencarian.jabatan << "\n";
                    } else {
                        cout << "Karyawan dengan ID " << idCari << " tidak ditemukan!\n";
                    }
                    if (!konfirmasiLanjut()) {
                        pilihan = 0;
                    }
                }
                break;
            
            case 9:
                system("cls");
                if (hapusSemuaData(password)) {
                pilihan = 0;  // Setelah fungsi dijalankan dan berhasil, program otomatis keluar
                } else {

                if (!konfirmasiLanjut()) { // Jika password salah, tampilkan konfirmasiLanjut
                pilihan = 0;
                }
    }
    break;
            case 0:
                {
                    system("cls");
                    cout << "Terima kasih!\n";
                    break;
                }

            default:
                cout << "Pilihan tidak valid. Silakan coba lagi!\n";
        }
    } while (pilihan != 0);

    delete[] daftarKaryawan; // Dealokasi memori array dinamis
    return 0;
}

void simpanKeFile(const Karyawan daftar[], int jumlah) {
    ofstream file("daftar_karyawan.txt");

    for (int i = 0; i < jumlah; ++i) {
        file << daftar[i].id << "\n" << daftar[i].nama << "\n" << daftar[i].jabatan << "\n";
    }

    file.close();
    cout << endl;
    cout << "Data karyawan berhasil disimpan ke file!\n";
}

void bacaDariFile(Karyawan daftar[], int& jumlah) {
    ifstream file("daftar_karyawan.txt");

    while (file >> daftar[jumlah].id) {
        file.ignore();
        getline(file, daftar[jumlah].nama);
        getline(file, daftar[jumlah].jabatan);
        jumlah++;
    }

    file.close();
    cout << "Data karyawan berhasil dibaca dari file!\n";
}

void tampilkanMenu() {
    cout << "\n=== Menu ===\n";
    cout << "1. Tambah Karyawan\n";
    cout << "2. Tampilkan Daftar Karyawan\n";
    cout << "3. Hapus Karyawan\n";
    cout << "4. Search by ID\n";
    cout << "9. Hapus Semua Data\n";
    cout << "0. Keluar\n";
}

void tambahKaryawan(Karyawan*& daftar, int& jumlah, int& kapasitas) {
    long long idTambah;
    cout << "Masukkan ID karyawan : ";
    cin >> idTambah;
    cin.ignore();

    int indeksUpdate = -1;
    for (int i = 0; i < jumlah; ++i) {
        if (daftar[i].id == idTambah) {
            indeksUpdate = i;
            break;
        }
    }

    if (indeksUpdate != -1) {
        for (int i = indeksUpdate; i < jumlah - 1; ++i) { // Menghapus data karyawan sebelumnya
            daftar[i] = daftar[i + 1];
        }
        jumlah--;

        if (jumlah < kapasitas) { // Tambah Update Karyawan
            cout << "Masukkan nama karyawan: ";
            getline(cin, daftar[jumlah].nama);
            daftar[jumlah].id = idTambah;
            cout << "Masukkan jabatan karyawan: ";
            getline(cin, daftar[jumlah].jabatan);
            jumlah++;
            cout << "\nData karyawan berhasil diperbarui dan disimpan!";
        } else {
            // Alokasi memori baru dengan kapasitas yang lebih besar
            kapasitas += 1;  // Tambahan kapasitas
            Karyawan* tempDaftar = new Karyawan[kapasitas];

            for (int i = 0; i < jumlah; ++i) { // Salin data dari array lama ke array baru
                tempDaftar[i] = daftar[i];
            }

            delete[] daftar; // Hapus array lama

            daftar = tempDaftar;// Gunakan array baru

            cout << "Masukkan nama karyawan: ";
            getline(cin, daftar[jumlah].nama);
            daftar[jumlah].id = idTambah;
            cout << "Masukkan jabatan karyawan: ";
            getline(cin, daftar[jumlah].jabatan);
            jumlah++;

            cout << "\n Data karyawan berhasil diperbarui dan disimpan!";
        }
    } else {
        if (jumlah < kapasitas) { // Tambah data karyawan baru
            daftar[jumlah].id = idTambah;
            cout << "Masukkan nama karyawan: ";
            getline(cin, daftar[jumlah].nama);
            cout << "Masukkan jabatan karyawan: ";
            getline(cin, daftar[jumlah].jabatan);
            jumlah++;

            cout << "\nKaryawan berhasil ditambahkan!";
        } else {
            // Alokasi memori baru dengan kapasitas yang lebih besar
            kapasitas += 1;  // Tambahan kapasitas
            Karyawan* tempDaftar = new Karyawan[kapasitas];

            for (int i = 0; i < jumlah; ++i) { // Salin data dari array lama ke array baru
                tempDaftar[i] = daftar[i];
            }

            delete[] daftar; // Hapus array lama

            daftar = tempDaftar; // Gunakan array baru

            daftar[jumlah].id = idTambah;
            cout << "Masukkan nama karyawan: ";
            getline(cin, daftar[jumlah].nama);
            cout << "Masukkan jabatan karyawan: ";
            getline(cin, daftar[jumlah].jabatan);
            jumlah++;

            cout << "\nKaryawan berhasil ditambahkan!";
        }
    }
}

void tampilkanDaftarKaryawan(const Karyawan* daftar, int jumlah) {
    if (jumlah > 0) {
        cout << "\n=== Daftar Karyawan ===\n";
        for (int i = 0; i < jumlah; ++i) {
            cout << "ID      : " << daftar[i].id << "\n";
            cout << "Nama    : " << daftar[i].nama << "\n";
            cout << "Jabatan : " << daftar[i].jabatan << "\n\n";
        }
    } else {
        cout << endl;
        cout << "Daftar karyawan kosong!\n";
    }
}

void hapusKaryawan(Karyawan*& daftar, int& jumlah, int& kapasitas) {
    if (jumlah > 0) {
        long long idHapus;
        cout << "Masukkan ID karyawan yang ingin dihapus: ";
        cin >> idHapus;

        int indeksHapus = -1;
        for (int i = 0; i < jumlah; ++i) {
            if (daftar[i].id == idHapus) {
                indeksHapus = i;
                break;
            }
        }

        if (indeksHapus != -1) {
            for (int i = indeksHapus; i < jumlah - 1; ++i) {
                daftar[i] = daftar[i + 1];
            }

            jumlah--;
            cout << "Karyawan dengan ID " << idHapus << " berhasil dihapus!\n";
        } else {
            cout << "Karyawan dengan ID " << idHapus << " tidak ditemukan!\n";
        }
    } else {
        cout << "Daftar karyawan kosong!\n";
    }
}

void sortingById(Karyawan* daftar, int jumlah) {
    for (int i = 0; i < jumlah - 1; ++i) {
        for (int j = 0; j < jumlah - i - 1; ++j) {
            if (daftar[j].id > daftar[j + 1].id) {
                swap(daftar[j], daftar[j + 1]);
            }
        }
    }
}

Karyawan cariKaryawanById(const Karyawan* daftar, int jumlah, long long idCari) {
    Karyawan hasilPencarian;
    hasilPencarian.id = -1;

    for (int i = 0; i < jumlah; ++i) {
        if (daftar[i].id == idCari) {
            hasilPencarian = daftar[i];
            break;
        }
    }

    return hasilPencarian;
}

bool hapusSemuaData(string password) { // Fungsi untuk menghapus semua data dari file
    string konfirmasiPassword;
    cout << "Masukkan password untuk konfirmasi: ";
    cin >> konfirmasiPassword;

    if (konfirmasiPassword == password) {
        ofstream file("daftar_karyawan.txt"); // Hapus semua data dari file
        file.close();
        cout << "Semua data berhasil dihapus dari file!\n";
        return true;  // Operasi berhasil
    } else {
        cout << "Password salah. Tidak dapat menghapus data.\n";
        return false;  // Operasi gagal
    }
}