#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

using namespace std;

class Mahasiswa {
private:
    string nama;
    string nim;
    float nilai;

public:
    void input() {
        while (true) {
            string line;
            cout << "Masukkan Nama Mahasiswa: ";
            getline(cin, nama);
        
            cout << "Masukkan NIM Mahasiswa: ";
            getline(cin, nim);

            cout << "Masukkan Nilai Mahasiswa: ";
            getline(cin, line);
            
            stringstream ss(line);
            ss >> nilai;

            if (ss.fail()) {
                cout << "Nilai harus berupa angka." << endl;
                continue;
            }

            break;
        }
    }


    void display() {
        cout << "Data Mahasiswa:" << endl;
        cout << "Nama: " << nama << endl;
        cout << "NIM: " << nim << endl;
        cout << "Nilai: " << nilai << endl;
    }

    bool isLulus() {
        return nilai >= 60.0;
    }

    void writeToFile(ofstream &file) {
        file << nama << "," << nim << "," << nilai << "," << (isLulus() ? "Lulus" : "Tidak Lulus") << endl;
    }
};

int main() {
    int jumlahMahasiswa;

    cout << "Masukkan Jumlah Mahasiswa: ";
    cin >> jumlahMahasiswa;

    cin.ignore();

    Mahasiswa *mahasiswaArray = new Mahasiswa[jumlahMahasiswa];

    for (int i = 0; i < jumlahMahasiswa; ++i) {
        cout << "\nMasukkan Data Mahasiswa ke-" << i + 1 << ":" << endl;
        mahasiswaArray[i].input();
    }

    ofstream outputFile("data_mahasiswa.csv");
    if (outputFile.is_open()) {
        for (int i = 0; i < jumlahMahasiswa; ++i) {
            mahasiswaArray[i].writeToFile(outputFile);
        }
        outputFile.close();
        cout << "\nData berhasil disimpan ke dalam file data_mahasiswa.csv" << endl;
    } else {
        cout << "Gagal membuka file untuk penulisan." << endl;
    }

    delete[] mahasiswaArray;

    return 0;
}