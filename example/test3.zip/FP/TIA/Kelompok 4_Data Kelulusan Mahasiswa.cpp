#include <iostream>
#include <string>

using namespace std;

// Definisi struktur untuk data mahasiswa
struct Mahasiswa {
    int NIM;
    string nama;
    string jurusan;
    float IPK;
};

// Fungsi untuk menampilkan data mahasiswa
void tampilkanMahasiswa(const Mahasiswa& mhs) {
    cout << "NIM    : " << mhs.NIM << endl;
    cout << "Nama   : " << mhs.nama << endl;
    cout << "Jurusan: " << mhs.jurusan << endl;
    cout << "IPK    : " << mhs.IPK << endl;
}

// Fungsi untuk memeriksa kelulusan berdasarkan IPK
bool cekKelulusan(float IPK) {
    return IPK >= 2.75;
}

int main() {
    // Deklarasi array untuk menyimpan data mahasiswa
    const int JUMLAH_MAHASISWA = 3;
    Mahasiswa daftarMahasiswa[JUMLAH_MAHASISWA];

    // Memasukkan data mahasiswa
for (int i = 0; i < JUMLAH_MAHASISWA; ++i) {
    cout << "Data Mahasiswa ke-" << i + 1 <<endl;
    cout << "Masukkan NIM    : ";
    cin >> daftarMahasiswa[i].NIM;
    
    cout << "Masukkan Nama   : ";
    cin.ignore(); // Membersihkan buffer
    getline(cin, daftarMahasiswa[i].nama);
    
    cout << "Masukkan Jurusan: ";
    getline(cin, daftarMahasiswa[i].jurusan);
    
    cout << "Masukkan IPK    : ";
    cin >> daftarMahasiswa[i].IPK;
    
    cout << endl;
}

    // Menampilkan data mahasiswa
    cout << "\n Data Mahasiswa " << endl;
    for (int i = 0; i < JUMLAH_MAHASISWA; ++i) {
        cout << "Data Mahasiswa ke-" << i + 1 << endl;
        tampilkanMahasiswa(daftarMahasiswa[i]);

        // Menampilkan status kelulusan
        if (cekKelulusan(daftarMahasiswa[i].IPK)) {
            cout << "Status : Lulus\n";
        } else {
            cout << "Status : Tidak Lulus\n";
        }

        cout << endl;
    }

    return 0;
}

