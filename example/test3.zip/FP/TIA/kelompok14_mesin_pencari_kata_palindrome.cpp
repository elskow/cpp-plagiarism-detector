#include <iostream>
#include <fstream>
#include <string>


using namespace std;

#define MAX_SIZE 100

// Struktur untuk menyimpan data pengguna
struct UserData {
    string words[MAX_SIZE];
    int size;
};

// Fungsi untuk membaca kata dari pengguna
void inputWords(UserData *data) {
    cout << "Masukkan jumlah kata : ";
    cin >> data->size;

    cout << "Masukkan " << data->size << " kata:\n";
    for (int i = 0; i < data->size; ++i) {
        cin >> data->words[i];
    }
}

// Fungsi untuk menampilkan kata dari array
void displayWords(UserData data) {
    cout << "Kata yang dimasukkan: ";
    for (int i = 0; i < data.size; ++i) {
        cout << data.words[i] << " ";
    }
    cout << endl;
}

// Fungsi rekursif untuk mengecek apakah suatu kata palindrome atau bukan
bool isPalindrome(string word, int start, int end) {
    if (start >= end) {
        return true;
    }
    return (word[start] == word[end]) && isPalindrome(word, start + 1, end - 1);
}

// Fungsi untuk mengecek apakah setiap kata palindrome atau tidak
void checkPalindromes(UserData data) {
    cout << "Hasil pengecekan kata palindrome:\n";
    for (int i = 0; i < data.size; ++i) {
        bool result = isPalindrome(data.words[i], 0, data.words[i].length() - 1);
        cout << data.words[i] << " adalah " << (result ? "palindrome" : "bukan palindrome") << endl;
    }
}

int main() {
    UserData userInput;

    // Meminta pengguna untuk memasukkan kata
    inputWords(&userInput);

    // Menampilkan kata-kata yang dimasukkan oleh pengguna
    displayWords(userInput);

    // Melakukan pengecekan apakah setiap kata palindrome atau bukan
    checkPalindromes(userInput);

    // Menggunakan file untuk menyimpan kata-kata
    ofstream file("words.txt");
    if (file.is_open()) {
        file << "Kata-kata yang dimasukkan:\n";
        for (int i = 0; i < userInput.size; ++i) {
            file << userInput.words[i] << " ";
        }
        file << endl;
        file.close();
        cout << "Kata-kata telah disimpan di file 'words.txt'." << endl;
    } else {
        cout << "Tidak Bisa Membuka File" << endl;
        return 1;
    }

    return 0;
}