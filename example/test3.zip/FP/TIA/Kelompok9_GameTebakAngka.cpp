// mengakses library c++ yang akan di gunakan
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <fstream>

using namespace std;

// Struktur untuk menyimpan data pemain
struct Player {
    string name;
    int attempts;
};

// Prototipe fungsi
void guessNumber(int *attempts);
void savePlayerData(const Player &player); 
void showLeaderboard();

// Fungsi utama untuk memulai game tebak angka
int main() {

    srand(time(0)); // generator nomor acak

    int choice;

    // menampilkan menu game tebak angka
    do {
        cout << "=== Game Tebak Angka ===" << endl;
        cout << "1. Mulai Permainan" << endl;
        cout << "2. Tampilkan Papan Peringkat" << endl;
        cout << "3. Keluar" << endl;
        cout << "Pilih: ";
        cin >> choice;

        switch (choice) {
            case 1:
                guessNumber(nullptr);
                break;
            case 2:
                showLeaderboard();
                break;
            case 3:
                cout << "Terima kasih telah bermain! ^_^" << endl;
                break;
            default:
                cout << "Pilihan tidak valid. Silakan coba lagi." << endl;
        }

    } while (choice != 3);

    return 0;
}

// Fungsi menebak angka
void guessNumber(int *attempts) {

    int targetNumber = rand() % 100 + 1;
    int guess;
    int currentAttempts = 0;
    const int CLOSE_THRESHOLD = 5; // batas perbedaan antara tebakan pengguna dan angka target

    cout << "Masukkan nama Anda: ";
    string playerName;
    cin.ignore();
    getline(cin, playerName);

    time_t start_time, current_time;
    time(&start_time);
    double elapsed;
    const int TIME_LIMIT = 40;

    cout << "=== Selamat Bermain ===" << endl;
    cout << "!!! WAKTU MENEBAK 40 DETIK !!! " << endl;
    
    do {
        cout << "Masukkan tebakan Anda (1-100): ";
        cin >> guess;

        if (guess < 1 || guess > 100) {
            cout << "Tebakan tidak valid. Harap masukkan angka antara 1 dan 100." << endl;
            continue; // agar kembali ke awal loop
        }

        currentAttempts++;

        int difference = abs(targetNumber - guess); // menghitung selisih absolut antara angka dari program dengan pemain

        if (difference <= CLOSE_THRESHOLD && difference > 0) {   // memeriksa perbedaan tebakan pemain dengan angka tebakan dari program
            if (difference <= 5) {
                cout << "Sedikit lagi!" << endl;
            }
        } else if (guess > targetNumber) {
            cout << "Tebakan terlalu besar. Coba lagi." << endl;
        } else if (guess < targetNumber) {
            cout << "Tebakan terlalu kecil. Coba lagi." << endl;
        } else {
            cout << "Selamat! Anda berhasil menebak angka " << targetNumber << " dalam " << currentAttempts << " percobaan " << "dalam waktu "<< elapsed << " detik" << endl;
            Player currentPlayer = {playerName, currentAttempts};
            savePlayerData(currentPlayer);
        }
        
        time(&current_time);
        elapsed = difftime(current_time, start_time);

        if (elapsed > TIME_LIMIT) {
            cout << "Waktu habis! Anda kalah. \n";
            break; // waktu habis permainan selesai
        }

    } while (guess != targetNumber);

    if (attempts != nullptr) {
        *attempts = currentAttempts;
    }
}

// Fungsi menyimpan data pemain game tebak angka ke file
void savePlayerData(const Player &player) {

    ofstream file("leaderboard.txt", ios::app); // ios::app untuk menambah isi file 

    if (file.is_open()) {
        file << player.name << " " << player.attempts << endl;
        file.close();
    } else {
        cout << "Gagal membuka file leaderboard." << endl;
    }
}

// Fungsi menampilkan papan peringkat pemain game tebak angka
void showLeaderboard() {

    ifstream file("leaderboard.txt");

    if (file.is_open()) {
        const int MAX_PLAYERS = 100;  // maks pemain
        Player players[MAX_PLAYERS];  // Array untuk menyimpan data pemain

        int totalPlayers = 0;
        // Membaca pemain ke dalam array
        while (totalPlayers < MAX_PLAYERS && file >> players[totalPlayers].name >> players[totalPlayers].attempts) {
            totalPlayers++;
        }
        file.close();

        // mengurutkan pemain game tebak angka
        for (int i = 0; i < totalPlayers - 1; ++i) {
            for (int j = 0; j < totalPlayers - i - 1; ++j) {
                if (players[j].attempts > players[j + 1].attempts) {
                    // menukar posisi pemain game tebak angka
                    Player temp = players[j];
                    players[j] = players[j + 1];
                    players[j + 1] = temp;
                }
            }
        }

        // Menampilkan papan peringkat game tebak angka
        cout << "=== Papan Peringkat ===" << endl;
        for (int i = 0; i < totalPlayers; ++i) {
            cout << i + 1 << ". " << players[i].name << ": " << players[i].attempts << " percobaan" << endl; // pemain diberikan nomor urut peringkat
        }
    } else {
        cout << "Gagal membuka file leaderboard." << endl;
    }
}