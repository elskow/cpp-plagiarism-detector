#include <iostream>
#include <string>
#include <fstream>
#include <chrono>
using namespace std;

struct Barang
{
    string kode;
    string nama;
    int harga;
};

Barang daftar_barang[100];
int jumlah_barang_terdaftar = 0;

void tambahBarang(string kode, string nama, int harga)
{
    daftar_barang[jumlah_barang_terdaftar].kode = kode;
    daftar_barang[jumlah_barang_terdaftar].nama = nama;
    daftar_barang[jumlah_barang_terdaftar].harga = harga;
    jumlah_barang_terdaftar++;
}

int cariHarga(string kode)
{
    for (int i = 0; i < jumlah_barang_terdaftar; i++)
    {
        if (daftar_barang[i].kode == kode)
        {
            return daftar_barang[i].harga;
        }
    }
    return -1;
}

string cariNama(string kode)
{
    string hasil;
    for (int i = 0; i < jumlah_barang_terdaftar; i++)
    {
        if (daftar_barang[i].kode == kode)
        {
            return daftar_barang[i].nama;
        }
    }
    return hasil;
}

int main()
{
    string kode_barang;
    string nama_barang;
    int jumlah_barang;
    int total_harga = 0;

    tambahBarang("001", "Susu", 10000);
    tambahBarang("002", "Gula", 5000);
    tambahBarang("003", "Kecap", 8000);
    tambahBarang("004", "Sabun", 5000);
    tambahBarang("005", "Minyak", 10000);
    tambahBarang("006", "Kopi", 14000);
    tambahBarang("007", "Teh", 7000);
    tambahBarang("008", "Mie Instan", 3000);
    tambahBarang("009", "Beras", 12000);
    tambahBarang("010", "Biskuit", 8000);
    tambahBarang("011", "Pasta Gigi", 10000);
    tambahBarang("012", "Shampo", 15000);
    tambahBarang("013", "Deterjen", 18000);
    tambahBarang("014", "Pembersih Lantai", 10000);
    tambahBarang("015", "Pencuci Piring", 12000);
    tambahBarang("016", "Pelembut Pakaian", 15000);
    tambahBarang("017", "Penyegar Udara", 8000);
    tambahBarang("018", "Tissue", 5000);
    tambahBarang("019", "Pembalut", 14000);
    tambahBarang("020", "Popok Bayi", 20000);
    tambahBarang("021", "Sabun Mandi", 10000);
    tambahBarang("022", "Shampo Anak", 8000);
    tambahBarang("023", "Pasta Gigi Anak", 6000);
    tambahBarang("024", "Tisu Basah", 7000);
    tambahBarang("025", "Obat Nyamuk", 12000);
    tambahBarang("026", "Pembasmi Kecoa", 15000);
    tambahBarang("027", "Pembersih Kaca", 10000);
    tambahBarang("028", "Penyegar Ruangan", 8000);
    tambahBarang("029", "Lilin", 5000);
    tambahBarang("030", "Koreksi", 3000);
    tambahBarang("031", "Rautan Pensil", 2000);
    tambahBarang("032", "Penghapus", 1000);
    tambahBarang("033", "Pensil Warna", 12000);
    tambahBarang("034", "Crayon", 10000);
    tambahBarang("035", "Plastik Pembungkus", 5000);
    tambahBarang("036", "Selotip", 6000);
    tambahBarang("037", "Gunting", 10000);
    tambahBarang("038", "Kertas HVS", 8000);
    tambahBarang("039", "Buku Tulis", 7000);
    tambahBarang("040", "Pulpen", 3000);
    tambahBarang("041", "Penggaris", 2000);
    tambahBarang("042", "Stapler", 15000);
    tambahBarang("043", "Penjepit Kertas", 5000);
    tambahBarang("044", "Map", 8000);
    tambahBarang("045", "Amplop", 7000);
    tambahBarang("046", "Baterai", 10000);
    tambahBarang("047", "Bola Lampu", 8000);
    tambahBarang("048", "Selotip Busa", 5000);
    tambahBarang("049", "Kain Lap", 6000);
    tambahBarang("050", "Ember", 12000);
    tambahBarang("051", "Sapu", 10000);
    tambahBarang("052", "Pel", 15000);
    tambahBarang("053", "Alat Pel Lantai", 20000);
    tambahBarang("054", "Lap Pel", 8000);
    tambahBarang("055", "Spons Cuci Piring", 5000);
    tambahBarang("056", "Sarung Tangan", 3000);
    tambahBarang("057", "Kantong Sampah", 2000);
    tambahBarang("058", "Tempat Sampah", 15000);
    tambahBarang("059", "Korek Api", 1000);
    tambahBarang("060", "Lilin Aromaterapi", 5000);
    tambahBarang("061", "Permen", 5000);
    tambahBarang("062", "Kacang-kacangan", 8000);
    tambahBarang("063", "Oleh-oleh", 12000);
    tambahBarang("064", "Minuman Ringan", 10000);
    tambahBarang("065", "Minuman Alkohol", 15000);
    tambahBarang("066", "Minuman Kopi", 8000);
    tambahBarang("067", "Minuman Teh", 5000);
    tambahBarang("068", "Minuman Jus", 10000);
    tambahBarang("069", "Minuman Susu", 12000);
    tambahBarang("070", "Minuman Energi", 15000);
    tambahBarang("071", "Obat-obatan", 8000);
    tambahBarang("072", "Alat Medis", 5000);
    tambahBarang("073", "Kosmetik", 10000);
    tambahBarang("074", "Parfum", 12000);
    tambahBarang("075", "Aksesoris", 15000);
    tambahBarang("076", "Pakaian", 8000);
    tambahBarang("077", "Sepatu", 5000);
    tambahBarang("078", "Tas", 10000);
    tambahBarang("079", "Jam Tangan", 12000);
    tambahBarang("080", "Kacamata", 15000);
    tambahBarang("081", "Alat Tulis Kantor", 8000);
    tambahBarang("082", "Alat Elektronik", 5000);
    tambahBarang("083", "Alat Dapur", 10000);
    tambahBarang("084", "Alat Musik", 12000);
    tambahBarang("085", "Alat Olahraga", 15000);
    tambahBarang("086", "Mainan Anak", 8000);
    tambahBarang("087", "Buku", 5000);
    tambahBarang("088", "CD/DVD", 10000);
    tambahBarang("089", "Kaset", 12000);
    tambahBarang("090", "Vinyl", 15000);
    tambahBarang("091", "Peralatan Olahraga", 8000);
    tambahBarang("092", "Peralatan Camping", 5000);
    tambahBarang("093", "Peralatan Hiking", 10000);
    tambahBarang("094", "Peralatan Travelling", 12000);
    tambahBarang("095", "Peralatan Memancing", 15000);
    tambahBarang("096", "Peralatan Berburu", 8000);
    tambahBarang("097", "Peralatan Berkebun", 5000);
    tambahBarang("098", "Peralatan Rumah Tangga", 10000);
    tambahBarang("099", "Peralatan Industri", 12000);
    tambahBarang("100", "Peralatan Pertanian", 15000);



    do
    {
        cout << "------------------------------------" << endl;
        cout << "Masukkan kode barang        : ";
        cin >> kode_barang;
        int harga_total;

        ofstream file("barang.txt",ios::app);

        int harga =cariHarga(kode_barang);
        string nama_barang = cariNama(kode_barang);

        if (harga != -1)
        {
            cout << "Masukkan jumlah barang      : ";
            cin >> jumlah_barang;
            harga_total = harga * jumlah_barang;

            cout << "Harga " << kode_barang << " sebesar " << harga << " x " << jumlah_barang << " : " << harga_total << endl;
            file << "Harga " << nama_barang << " sebesar " << harga << " x " << jumlah_barang << " : " << harga_total << endl;
            cout << " " << endl;
        }
        else
        {
            cout << "Kode barang tidak ditemukan" << endl;
        }

        file.close();

        total_harga += harga_total;

        char tambah_barang;
        cout << "Tambah barang lagi? (y/n)   : ";
        cin >> tambah_barang;
        if (tambah_barang == 'n')
        {
            break;
        }
        

    } while (true);

    cout << "------------------------------------" << endl;
    cout << "Total harga barang          : " << total_harga << endl;
    cout << "masukkan promo (y/n)        : ";

    char promo;
    char y;
    char n;
    cin >> promo;
    if (promo == 'y')
    {
        ifstream inputFile("promo.txt");
        string kode;
        string line;
        cout << "Masukkan kode               : ";
        cin >> kode;
        cout << " " << endl;
        while (getline(inputFile,line))
        {
            if (line == kode)
            {
                if (kode == "GOJEK")
                {
                    total_harga *= 0.5;
                }
                if (kode == "GRAB")
                {
                    total_harga *= 0.2;
                }
                if (kode == "SHOPEE")
                {
                    total_harga *= 0.6;
                }
                if (kode == "TOKOPEDIA")
                {
                    total_harga *= 0.7;
                }
                if (kode == "LAZADA")
                {
                    total_harga *= 0.9;
                }
                break;
            }
            
        }
        if (inputFile.eof() && line != kode)
        {
            cout << "Kode tidak ditemukan" << endl;
        }
        inputFile.close();
    }
    
    else
    {
        total_harga * 1;
    }

    cout << " " << endl;
    cout << " " << endl;

    cout << "               INDOAPRIL" << endl;
    cout << "     JL.AJA DULU SIAPA TAU JODOH" << endl;

    time_t now = time(NULL);
    char time_string[80];
    strftime(time_string, sizeof(time_string), "%d-%m-%Y %H:%M:%S", localtime(&now));
    
    cout << "         " << time_string << endl;
    cout << "------------------------------------" << endl;
    cout << "Harga";

    ifstream masuk;;
    masuk.open("barang.txt");
    string data;
    string array[100];
    while (masuk >> data)
    {
        while (!masuk.eof())
        {
            string data;
            getline(masuk, data);
            cout << data << endl;
        }
        
    }
    cout << "------------------------------------" << endl;
    masuk.close();
    cout << " " << endl;

    int bayar;
    int kembali;

    ofstream file("barang.txt",ios::trunc);
    file.close();

    cout << "Total harga barang          : " << total_harga << endl;
    cout << "Bayar                       : ";
    cin >> bayar;
    kembali=bayar-total_harga;
    cout << "Kembali                     : " << kembali << endl;
    cout << " " << endl;
    cout << "   TERIMA KASIH SUDAH BERBELANJA " << endl;
    cout << "------------------------------------" << endl;


    return 0;
}