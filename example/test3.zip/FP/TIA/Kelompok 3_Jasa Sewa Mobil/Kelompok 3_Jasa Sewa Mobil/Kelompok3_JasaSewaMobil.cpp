#include <iostream>
#include <fstream>
#include <limits>
using namespace std;

const int max_mobil = 100;
const int max_penyewa = 100;

//struktur data mobil
struct mobil{
    int id_mobil;
    string merk_mobil;
    string nama_mobil;
    int tahun_mobil;
    float biayasewa_mobil;
    bool status_mobil;
};

//struktur data penyewa
struct penyewa{
    int id_penyewa;
    string nama_penyewa;
    string nik_penyewa;
    string alamat_penyewa;
    string no_penyewa;
    int id_sewamobil;
    int lama_penyewa;
    float totalbiaya_penyewa;
};

//tampilan menu
int getoption(){
    int input;
    system("cls");
    cout << "\nProgram Jasa Sewa Mobil" << endl;
    cout << "===============================" << endl;
    cout << "Menu: " << endl;
    cout << "1. Tambah Data Mobil" << endl;
    cout << "2. Tampilkan Data Mobil" << endl;
    cout << "3. Update Data Mobil" << endl;
    cout << "4. Hapus Data Mobil" << endl;
    cout << "5. Sewa mobil" << endl;
    cout << "6. kembalikan mobil" << endl;
    cout << "7. Exit" << endl;
    cout << "Pilih menu (1-7): ";
    cin >> input;
    cin.ignore(numeric_limits<streamsize>::max(),'\n');
    return input;
}

//Fungsi untuk menginputkan data mobil
void inputdatamobil(mobil databasemobil[], int& totaldatamobil, int& autoid){
    if(totaldatamobil < max_mobil){
        mobil inputmobil;

        inputmobil.id_mobil = autoid++;

        cout << "Merk Mobil: ";
        getline(cin, inputmobil.merk_mobil);

        cout << "Nama Mobil: ";
        getline(cin, inputmobil.nama_mobil);

        cout << "Tahun Produksi Mobil: ";
        cin >> inputmobil.tahun_mobil;

        cout << "Harga Sewa: ";
        cin >> inputmobil.biayasewa_mobil;

        inputmobil.status_mobil = false;

        databasemobil[totaldatamobil++] = inputmobil;

        cout << "Mobil berhasil ditambahkan.\n";
    }else{
        cout << "Kapasitas maksimum mobil telah tercapai.\n";
    }
   

}

// Fungsi untuk menyimpan data mobil ke file
void simpandatamobil(const mobil databasemobil[], int totaldatamobil, int autoid) {
    ofstream file("tbl_mobil.txt");
    file << totaldatamobil << ' ' << autoid << '\n';
    for (int i = 0; i < totaldatamobil; ++i) {
        file << databasemobil[i].id_mobil << ' ' << databasemobil[i].merk_mobil << ' '
             << databasemobil[i].nama_mobil << ' ' << databasemobil[i].tahun_mobil << ' ' << databasemobil[i].biayasewa_mobil << ' '
             << databasemobil[i].status_mobil << '\n';
    }
    file.close();
}

// Fungsi untuk membaca data mobil dari file
void bacadatamobil(mobil databasemobil[], int& totaldatamobil, int& autoid) {
    ifstream file("tbl_mobil.txt");
    file >> totaldatamobil >> autoid;
    if (file.is_open()) {
        for (int i = 0; i < totaldatamobil; ++i) {
            file >> databasemobil[i].id_mobil >> databasemobil[i].merk_mobil
                 >> databasemobil[i].nama_mobil >> databasemobil[i].tahun_mobil >> databasemobil[i].biayasewa_mobil
                 >> databasemobil[i].status_mobil;
        }
        file.close();
    }
}

// Fungsi untuk menampilkan daftar mobil
void tampilkandatamobil(const mobil databasemobil[], int totaldatamobil) {
    if (totaldatamobil == 0) {
        cout << "Tidak ada mobil yang tersedia.\n";
        return;
    }

    cout << "Daftar Mobil:\n";
    cout << "ID\tMerk\tModel\tTahun\tHarga\tStatus\n";
    for (int i = 0; i < totaldatamobil; ++i) {
        cout << databasemobil[i].id_mobil << "\t" << databasemobil[i].merk_mobil << "\t"
             << databasemobil[i].nama_mobil << "\t" << databasemobil[i].tahun_mobil << "\t" << databasemobil[i].biayasewa_mobil;
        if (databasemobil[i].status_mobil) {
            cout << "\tDisewa";
        } else {
            cout << "\tTersedia";
        }
        cout << "\n";
    }
}

// Fungsi untuk mengupdate data mobil
void updatedatamobil(mobil databasemobil[], int totaldatamobil) {
    int id;
    cout << "Masukkan ID mobil yang akan diupdate: ";
    cin >> id;

    for (int i = 0; i < totaldatamobil; ++i) {
        if (databasemobil[i].id_mobil == id) {
            cout << "Merk mobil: ";
            cin >> databasemobil[i].merk_mobil;

            cout << "Nama mobil: ";
            cin >> databasemobil[i].nama_mobil;

            cout << "Tahun produksi Mobil: ";
            cin >> databasemobil[i].tahun_mobil;

            cout << "Harga sewa: ";
            cin >> databasemobil[i].biayasewa_mobil;

            cout << "Status mobil (1: Disewa, 0: Tersedia): ";
            cin >> databasemobil[i].status_mobil;

            cout << "Data mobil berhasil diupdate.\n";
            return;
        }
    }

    cout << "ID mobil tidak ditemukan.\n";
}

// Fungsi untuk reset id mobil
void resetIdMobilAuto(const mobil databasemobil[], int totaldatamobil, int& autoid) {
    int maxId = 0;
    for (int i = 0; i < totaldatamobil; ++i) {
        if (databasemobil[i].id_mobil > maxId) {
            maxId = databasemobil[i].id_mobil;
        }
    }

    autoid = maxId + 1;
}

// Fungsi untuk menghapus data mobil
void hapusdatamobil(mobil databasemobil[], int& totaldatamobil, int& autoid) {
    int id;
    cout << "Masukkan ID mobil yang akan dihapus: ";
    cin >> id;

    for (int i = 0; i < totaldatamobil; ++i) {
        if (databasemobil[i].id_mobil == id) {
            for (int j = i; j < totaldatamobil - 1; ++j) {
                databasemobil[j] = databasemobil[j + 1];
            }
            --totaldatamobil;

            resetIdMobilAuto(databasemobil, totaldatamobil, autoid);
            cout << "Data mobil berhasil dihapus.\n";
            return;
        }
    }

    cout << "ID mobil tidak ditemukan.\n";
}

// Fungsi untuk menyewa mobil
void inputsewamobil(mobil databasemobil[], penyewa databasepenyewa[], int totaldatamobil, int& totaldatapenyewa, int& autoidsewa) {
    
    if(totaldatapenyewa < max_penyewa){
        penyewa inputsewa;

        inputsewa.id_penyewa = autoidsewa++;

        cout << "Nama: ";
        getline(cin, inputsewa.nama_penyewa);

        cout << "Nik: ";
        getline(cin, inputsewa.nik_penyewa);

        cout << "Alamat: ";
        getline(cin, inputsewa.alamat_penyewa);

        cout << "No.Telp: ";
        getline(cin, inputsewa.no_penyewa);

        cout << "Masukkan ID mobil yang akan disewa: ";
        cin >> inputsewa.id_sewamobil;

        for (int i = 0; i < totaldatamobil; ++i) {
            if (databasemobil[i].id_mobil == inputsewa.id_sewamobil) {
                if (!databasemobil[i].status_mobil) {
                    cout << "Merk: " << databasemobil[i].merk_mobil << '\n';
                    cout << "Nama: " << databasemobil[i].nama_mobil << '\n';
                    cout << "Tahun: " << databasemobil[i].tahun_mobil << '\n';
                    cout << "Masukkan jumlah hari sewa: ";
                    cin >> inputsewa.lama_penyewa;

                    databasemobil[i].status_mobil = true;
                    inputsewa.totalbiaya_penyewa = inputsewa.lama_penyewa * databasemobil[i].biayasewa_mobil;

                    databasepenyewa[totaldatapenyewa++] = inputsewa;

                    cout << "Mobil berhasil disewa. Biaya sewa: Rp." << inputsewa.totalbiaya_penyewa <<'\n';
                } else {
                    cout << "Mobil sudah disewa.\n";
                }
                return;
            }
        }

        cout << "ID mobil tidak ditemukan.\n";
    }else{
        cout << "Kapasitas maksimum penyewa telah tercapai.\n";
    }
    
}

// Fungsi untuk menyimpan sewa ke file
void simpandatasewa(const penyewa databasepenyewa[], int totaldatapenyewa, int autoidsewa) {
    ofstream file("tbl_sewa.txt");
    file << totaldatapenyewa << ' ' << autoidsewa << '\n';
    for (int i = 0; i < totaldatapenyewa; ++i) {
        file << databasepenyewa[i].id_penyewa << ' ' << databasepenyewa[i].nama_penyewa << ' '
             << databasepenyewa[i].nik_penyewa << ' ' << databasepenyewa[i].alamat_penyewa << ' ' << databasepenyewa[i].no_penyewa << ' '
             << databasepenyewa[i].id_sewamobil << ' ' << databasepenyewa[i].lama_penyewa << ' ' << databasepenyewa[i].totalbiaya_penyewa << '\n';
    }
    file.close();
}

// Fungsi untuk membaca sewa dari file
void bacadatasewa(penyewa databasepenyewa[], int& totaldatapenyewa, int& autoidsewa) {
    ifstream file("tbl_sewa.txt");
    file >> totaldatapenyewa >> autoidsewa;
    if (file.is_open()) {
        for (int i = 0; i < totaldatapenyewa; ++i) {
            file >> databasepenyewa[i].id_penyewa >> databasepenyewa[i].nama_penyewa >> databasepenyewa[i].nik_penyewa
                 >> databasepenyewa[i].alamat_penyewa >> databasepenyewa[i].no_penyewa
                 >> databasepenyewa[i].id_sewamobil >> databasepenyewa[i].lama_penyewa >> databasepenyewa[i].totalbiaya_penyewa;
        }
        file.close();
    }
}

// Fungsi untuk mengembalikan mobil yang disewa
void kembalikanmobil(mobil databasemobil[], penyewa databasepenyewa[], int totaldatamobil, int totaldatapenyewa) {
    int id;
    cout << "Masukkan ID penyewa yang akan dikembalikan: ";
    cin >> id;

    for (int i = 0; i < totaldatapenyewa; ++i) {
        if (databasepenyewa[i].id_penyewa == id) {
            // Menampilkan informasi penyewa
            cout << "Nama: " << databasepenyewa[i].nama_penyewa << '\n';
            cout << "Nik: " << databasepenyewa[i].nik_penyewa << '\n';
            cout << "Alamat: " << databasepenyewa[i].alamat_penyewa << '\n';
            cout << "No.Telp: " << databasepenyewa[i].no_penyewa << '\n';

            for (int j = 0; j < totaldatamobil; ++j) {
                if (databasemobil[j].id_mobil == databasepenyewa[i].id_sewamobil) {
                    // Menampilkan informasi mobil
                    cout << "Merk: " << databasemobil[j].merk_mobil << '\n';
                    cout << "Nama: " << databasemobil[j].nama_mobil << '\n';

                    // Mengembalikan mobil
                    databasemobil[j].status_mobil = false;
                    cout << "Mobil berhasil dikembalikan.\n";
                    return;
                }
            }
        }
    }

    cout << "ID mobil atau penyewa tidak ditemukan.\n";
}

// Fungsi untuk reset id sewa
void resetIdsewaauto(const penyewa databasepenyewa[], int totaldatapenyewa, int& autoidsewa) {
    int maxId = 0;
    for (int i = 0; i < totaldatapenyewa; ++i) {
        if (databasepenyewa[i].id_penyewa > maxId) {
            maxId = databasepenyewa[i].id_penyewa;
        }
    }

    autoidsewa = maxId + 1;
}

// Fungsi untuk menghapus data sewa
void hapusdatasewa(penyewa databasepenyewa[], int& totaldatapenyewa, int& autoidsewa) {
    int id;
    cout << "Masukkan ID penyewa yang akan dihapus: ";
    cin >> id;

    for (int i = 0; i < totaldatapenyewa; ++i) {
        if (databasepenyewa[i].id_penyewa == id) {
            for (int j = i; j < totaldatapenyewa - 1; ++j) {
                databasepenyewa[j] = databasepenyewa[j + 1];
            }
            --totaldatapenyewa;
            resetIdsewaauto(databasepenyewa, totaldatapenyewa, autoidsewa);
            cout << "Data penyewa berhasil dihapus.\n";
            return;
        }
    }

    cout << "ID penyewa tidak ditemukan.\n";
}

int main(){

    int pilihan = getoption();
    char lanjut;

    mobil databasemobil[max_mobil];
    int totaldatamobil = 0;
    int autoid = 1;

    penyewa databasepenyewa[max_penyewa];
    int totaldatapenyewa = 0;
    int autoidsewa = 1;

    bacadatamobil(databasemobil,totaldatamobil,autoid);
    bacadatasewa(databasepenyewa,totaldatapenyewa,autoidsewa);

    enum option{create = 1, read, update, del, sewa, kembalikan, exit, finish};

    while (pilihan != finish){
        switch (pilihan){
        case create:
            cout << "Menambah data mobil" << endl;
            inputdatamobil(databasemobil,totaldatamobil,autoid);
            simpandatamobil(databasemobil,totaldatamobil,autoid);
            break;
        case read:
            cout << "Tampilkan data mobil" << endl;
            tampilkandatamobil(databasemobil,totaldatamobil);
            break;
        case update:
            cout << "Update data mobil" << endl;
            updatedatamobil(databasemobil,totaldatamobil);
            simpandatamobil(databasemobil,totaldatamobil,autoid);
            break;
        case del:
            cout << "Hapus data mobil" << endl;
            hapusdatamobil(databasemobil,totaldatamobil,autoid);
            simpandatamobil(databasemobil,totaldatamobil,autoid);
            break;
        case sewa:
            cout << "Penyewaan Mobil" << endl;
            inputsewamobil(databasemobil, databasepenyewa, totaldatamobil, totaldatapenyewa, autoidsewa);
            simpandatamobil(databasemobil, totaldatamobil, autoid);
            simpandatasewa(databasepenyewa, totaldatapenyewa, autoidsewa);
            break;
        case kembalikan:
            cout << "Kembalikan Mobil" << endl;
            kembalikanmobil(databasemobil, databasepenyewa, totaldatamobil, totaldatapenyewa);
            hapusdatasewa(databasepenyewa, totaldatapenyewa, autoidsewa);
            simpandatamobil(databasemobil, totaldatamobil, autoid);
            simpandatasewa(databasepenyewa, totaldatapenyewa, autoidsewa); 
            break;
        case exit:
            cout << "Program selesai.\n";
            return 0;
        default:
            cout << "Pilihan tidak ditemukan" << endl;
            break;
        }

        label_lanjut:

        cout << "Lanjutkan?(y/n): ";
        cin >> lanjut;

        if((lanjut == 'y') | (lanjut == 'Y')){
            pilihan = getoption();
        }else if ((lanjut == 'n') | (lanjut == 'N')){
            break;
        }else{
            goto label_lanjut;
        }

    }
    
    cout << "Program selesai" << endl;

    cin.get();
    return 0;
}

