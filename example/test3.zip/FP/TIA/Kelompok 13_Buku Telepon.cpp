#include<iostream>
#include<fstream>
#include<conio.h>
#include<stdio.h>

using namespace std;

void home();
void number_add();
void show();
void Find();
void record_delete();
void Update();

class Diary
{
    int Sr_No;
    char Name[25];
    char Phone_no[15];
    char Email[30];
    char Groupby[20];

public:
    int getSrNo() { return Sr_No; }
    void Data_store()
    {
        cout << "\n.............CREATE NEW PHONE RECORD.............\n";
        cout << "Enter serial number : ";
        cin >> Sr_No;
        cin.ignore();
        cout << "Enter Record Name   : ";
        cin.getline(Name, 25);
        cout << "Enter Mobile number : ";
        cin.getline(Phone_no, 15);
        cout << "Enter E-Mail 1. D.  : ";
        cin.getline(Email, 30);
        cout << "Enter Record Group  : ";
        cin.getline(Groupby, 20);
        cout << endl;
    }

    void Data_show()
    {
        cout << "\n...............PHONE BOOK RECORD.................\n";
        cout << "Sr. No.    : " << Sr_No << endl;
        cout << "Name       : " << Name << endl;
        cout << "Mobile No. : " << Phone_no << endl;
        cout << "Email ID   : " << Email << endl;
        cout << "Group      : " << Groupby << endl;
    }
} page;

void number_add()
{
    ofstream fout;
    fout.open("PhoneBook.dat", ios::out | ios::binary | ios::app);
    page.Data_store();
    fout.write((char*)&page, sizeof(page));
    fout.close();
    cout << "\nRecord Saved to File......\n";
}

void show()
{
    ifstream fin;
    fin.open("PhoneBook.dat", ios::in | ios::binary | ios::app);
    while (fin.read((char*)&page, sizeof(page)))
    {
        page.Data_show();
    }
    fin.close();
    cout << "\nReading of Data File Completed......\n";
}

void Find()
{
    ifstream fin;
    int n, flag = 0;

    fin.open("PhoneBook.dat", ios::in | ios::binary | ios::app);
    cout << "Enter Serial Number of Record To Display: ";

    cin >> n;

    while (!fin.eof())
    {
        fin.read((char*)&page, sizeof(page));
        if (page.getSrNo() == n)
        {
            flag = 1;
            break;
        }
    }

    if (flag == 1)
    {
        cout << "\nRecord Found:\n";
        page.Data_show();
    }
    else
    {
        cout << "\nRecord Not Found\n";
    }

    fin.close();
}

void record_delete()
{
    ifstream fin;
    ofstream fout;
    int n, flag = 0;

    fin.open("PhoneBook.dat", ios::in | ios::binary);
    fout.open("Temp.dat", ios::out | ios::binary);

    cout << "Enter Serial Number of Record To Delete: ";

    cin >> n;

    while (!fin.eof())
    {
        fin.read((char*)&page, sizeof(page));

        if (page.getSrNo() == n)
        {
            flag = 1;
        }
        else
        {
            fout.write((char*)&page, sizeof(page));
        }
    }

    if (flag == 1)
    {
        cout << "\nRecord Deleted Successfully...\n";
    }
    else
    {
        cout << "\nRecord Not Found...\n";
    }

    fin.close();
    fout.close();

    remove("PhoneBook.dat");
    rename("Temp.dat", "PhoneBook.dat");
}

void Update()
{
    fstream fio;
    int n, flag=0, pos;
    fio.open("PhoneBook.dat", ios::out|ios::binary|ios::in);

    cout<<"Enter Serial Number of Record to Modify : ";
    cin>>n;

    while(fio.read((char*)&page,sizeof(page)))
    {
        pos=fio.tellg();
        if(n==page.getSrNo())
        {
            cout<<"\nThe Following record will be modified...\n";
            page.Data_show();
            flag++;
            cout<<"\nRe-Enter the New Details.....\n";
            page.Data_store();
            fio.seekg(pos-sizeof(page));
            fio.write((char*)&page,sizeof(page));
            cout<<"\n....Data Modified Succesfully.....\n";
        }
    }
    fio.close();
    if(flag==0)
        cout<<"\nThe Record of Serial Number "<<n<<"is not in file....\n";
    cout<<"\nReading of Data File Completed.......\n";
    
}

void home()
{
    int ch;

    do
    {
        cout << "PHONE BOOK MANAGEMENT\n";
        cout << "..................................................\n\n";
        cout << ":::::::::::::::::::::::::: PROGRAM MENU :: \n";
        cout << "0. Exit\n";
        cout << "1. Save New Phone Record\n";
        cout << "2. Display All Saved Records\n";
        cout << "3. Search Specific Record\n";
        cout << "4. Delete Specific Record\n";
        cout << "5. Modify Existing Record\n";
        cout << "Enter Your Choice : ";
        cin >> ch;

        switch (ch)
        {
        case 1:
            number_add();
            break;
        case 2:
            show();
            break;
        case 3:
            Find();
            break;
        case 4:
            record_delete();
            break;
        case 5:
            Update();
            break;
        }
        getch();
    } while (ch);
}

int main()
{
    home();
    return 0;
}